package com.tms.qubeapps.qubedatacollector

import java.security.MessageDigest

/**
 * ★ FIX (baru): aturan anti-duplikat untuk antrean upload SMB (murni logika, tanpa Android agar mudah diuji).
 *
 * Konteks: tiap "Upload to PC" mengirim SELURUH daftar scan (bukan hanya yang baru). Tanpa aturan ini, setiap upload yang
 * gagal menambah file pending baru berisi data yang sama (atau daftar yang sedikit lebih panjang), sehingga antrean
 * menumpuk data itu-itu saja dan PC menerima data ganda.
 *
 * Aturan (per tujuan SMB yang sama):
 *  1. Isi sama persis dengan upload yang SUDAH BERHASIL sebelumnya (dalam 24 jam) -> tidak dimasukkan antrean.
 *  2. Isi sudah termuat di file pending yang ada (sama persis / bagiannya) -> tidak dimasukkan antrean.
 *  3. Isi baru memuat seluruh isi file pending lama (daftar bertambah) -> file pending lama dibuang, cukup yang terbaru.
 *  4. Baris yang sama berulang (scan SKU yang sama dua kali di rak yang sama) dihitung per jumlah, bukan dianggap dobel.
 */
object PendingDedupe {

    const val SENT_WINDOW_MS = 24L * 60 * 60 * 1000

    class Item(val id: String, val path: String, val counts: Map<String, Int>, val hash: String)
    class Sent(val hash: String, val ts: Long)
    enum class Kind { ADD, DUPLICATE_PENDING, ALREADY_SENT }
    class Decision(val kind: Kind, val removeIds: List<String>, val sentTs: Long = 0L)

    /** Samakan perbedaan sepele (CRLF, spasi akhir baris, baris kosong) sebelum dibandingkan. */
    fun normalize(content: String): String =
        content.replace("\r\n", "\n").replace('\r', '\n').split("\n").map { it.trimEnd() }.filter { it.isNotBlank() }.joinToString("\n")

    fun hash(norm: String): String =
        MessageDigest.getInstance("SHA-256").digest(norm.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    fun counts(norm: String): Map<String, Int> {
        val m = LinkedHashMap<String, Int>()
        if (norm.isEmpty()) return m
        for (line in norm.split("\n")) m[line] = (m[line] ?: 0) + 1
        return m
    }

    /** true bila [a] memuat semua baris [b] (dengan jumlah kemunculan yang cukup). */
    fun covers(a: Map<String, Int>, b: Map<String, Int>): Boolean {
        for ((k, v) in b) if ((a[k] ?: 0) < v) return false
        return true
    }

    /** Putuskan nasib data baru terhadap antrean yang ada dan upload sukses terakhir ke tujuan yang sama. */
    fun decide(path: String, norm: String, existing: List<Item>, lastSent: Sent?, now: Long): Decision {
        val h = hash(norm)
        if (lastSent != null && lastSent.hash == h && now - lastSent.ts in 0..SENT_WINDOW_MS)
            return Decision(Kind.ALREADY_SENT, emptyList(), lastSent.ts)
        val c = counts(norm)
        val supersede = ArrayList<String>()
        for (e in existing) {
            if (e.path != path) continue
            if (covers(e.counts, c)) return Decision(Kind.DUPLICATE_PENDING, emptyList())
            if (covers(c, e.counts)) supersede.add(e.id)
        }
        return Decision(Kind.ADD, supersede)
    }

    /**
     * Item (urut lama -> baru) yang sudah termuat di item lain pada tujuan yang sama. Untuk isi yang sama persis,
     * hanya yang terbaru dipertahankan. Dipakai untuk merapikan antrean lama yang sudah terlanjur menumpuk.
     */
    fun redundant(items: List<Item>): List<String> {
        val out = ArrayList<String>()
        items.forEachIndexed { i, a ->
            val dup = items.withIndex().any { (j, b) ->
                j != i && b.path == a.path && covers(b.counts, a.counts) && (!covers(a.counts, b.counts) || j > i)
            }
            if (dup) out.add(a.id)
        }
        return out
    }
}
