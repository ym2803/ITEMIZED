package com.tms.qubeapps.qubedatacollector

import android.content.Context
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedCount
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedCount
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedTime

/**
 * ★ FIX (baru): versi TANPA dialog dari alur Subtract/Add Qty System (QtyAdjustFlow) untuk mode Auto.
 * Mengambil file bertanggal hari ini (ddMMyyyy.xlsx/.xls/.xlsm) dari folder yang sama dengan 02.txt, membaca kolomnya
 * dengan aturan yang SAMA seperti manual, lalu menerapkannya ke Qty System. Tidak melempar error: hasilnya berupa teks
 * ringkasan untuk ditampilkan ke user. Panggil dari Dispatchers.IO, SETELAH 02.txt baru tersimpan.
 */
object QtyAutoApply {

    fun run(ctx: Context, db: AppDatabase, type: String): String {
        if (type == "OFF") return ""
        val sign = if (type == "ADD") +1 else -1
        val label = if (sign < 0) "Subtract Qty" else "Add Qty"
        val (name, grid) = try {
            QtyAdjustImporter.fetchByDate(ctx)
        } catch (e: Exception) {
            return if (e.message?.contains("not found", ignoreCase = true) == true)
                "$label: no file with today's date in the folder (skipped)"
            else "$label: failed to fetch today's file — ${e.message}"
        }
        return try {
            // Kurangi: kolom A(0) & H(7). Tambah: kolom 5(4) & 6(5) — sama persis dengan QtyAdjustFlow.
            val parsed = if (sign < 0) QtyAdjustImporter.extractFlexible(grid, 0, 7) else QtyAdjustImporter.extract(grid, 4, 5)
            if (parsed.rowsUsed == 0) return "$label: $name has no valid SKU + Qty rows (skipped)"
            val sig = "${if (sign < 0) "-" else "+"}|$name|${grid.size}|${parsed.rowsUsed}"
            val st = QtyAdjustImporter.loadStore(ctx)
            if (st.imports.contains(sig)) return "$label: $name was already imported (skipped)"
            val res = db.adjustCatalogBalance(parsed.deltas, sign, true)
            parsed.deltas.forEach { (k, v) -> if (k !in res.notFound) st.deltas[k] = (st.deltas[k] ?: 0.0) + sign * v }
            st.imports.add(sig)
            QtyAdjustImporter.saveStore(ctx, st)
            if (sign < 0) { ctx.qtySubtractUpdatedTime = System.currentTimeMillis(); ctx.qtySubtractUpdatedCount = res.found }
            else { ctx.qtyAddUpdatedTime = System.currentTimeMillis(); ctx.qtyAddUpdatedCount = res.found }
            "$label ($name): ${res.found} SKU updated" +
                (if (res.notFound.isNotEmpty()) ", ${res.notFound.size} not in catalog" else "") +
                (if (res.negative > 0) ", ${res.negative} went negative" else "")
        } catch (e: Throwable) {
            "$label: failed to apply $name — ${e.message ?: e.javaClass.simpleName}"
        }
    }
}
