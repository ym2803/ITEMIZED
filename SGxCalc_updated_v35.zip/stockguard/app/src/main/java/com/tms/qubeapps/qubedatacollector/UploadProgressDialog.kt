package com.tms.qubeapps.qubedatacollector

import android.app.Activity
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * ★ FIX (baru): dialog progres upload — progress bar + persentase selama proses kirim,
 * lalu berubah jadi status akhir SUKSES / GAGAL / TERSIMPAN DI ANTREAN dengan tombol OK.
 * Aman dipanggil dari thread mana pun (update/finish pindah ke UI thread sendiri).
 */
class UploadProgressDialog(private val act: Activity, private val title: String) {

    enum class State { SUCCESS, FAILED, QUEUED }

    private val dp = act.resources.displayMetrics.density
    private val tvStatus = TextView(act).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
    private val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = false }
    private val tvPct = TextView(act).apply { textSize = 13f; gravity = Gravity.CENTER; text = "0%" }
    private val tvMsg = TextView(act).apply { textSize = 13f; setPadding(0, (8 * dp).toInt(), 0, 0) }
    private var dlg: AlertDialog? = null

    private fun ui(block: () -> Unit) {
        act.runOnUiThread { if (!act.isFinishing && !act.isDestroyed) try { block() } catch (_: Exception) {} }
    }

    fun show(): UploadProgressDialog {
        ui {
            val box = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                val pad = (20 * dp).toInt(); setPadding(pad, (12 * dp).toInt(), pad, 0)
                addView(tvStatus); addView(bar); addView(tvPct); addView(tvMsg)
            }
            tvStatus.text = "Mengupload…"
            dlg = AlertDialog.Builder(act).setTitle(title).setView(box).setCancelable(false)
                .setPositiveButton("OK", null).create().also { d ->
                    d.show()
                    d.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false   // aktif setelah selesai
                }
        }
        return this
    }

    fun update(percent: Int, message: String) {
        ui {
            val p = percent.coerceIn(0, 100)
            bar.progress = p; tvPct.text = "$p%"; tvMsg.text = message
        }
    }

    /** [onClose] dipanggil saat user menekan OK. */
    fun finish(state: State, headline: String, detail: String, onClose: (() -> Unit)? = null) {
        ui {
            val (color, icon) = when (state) {
                State.SUCCESS -> Color.parseColor("#2E7D32") to "✔ "
                State.FAILED -> Color.parseColor("#C62828") to "✖ "
                State.QUEUED -> Color.parseColor("#E08A00") to "⏳ "
            }
            tvStatus.text = icon + headline; tvStatus.setTextColor(color)
            bar.progressTintList = ColorStateList.valueOf(color)
            if (state == State.SUCCESS) { bar.progress = 100; tvPct.text = "100%" }
            tvMsg.text = detail
            dlg?.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
                isEnabled = true
                setOnClickListener { dlg?.dismiss(); onClose?.invoke() }
            }
        }
    }

    fun dismiss() = ui { dlg?.dismiss() }
}
