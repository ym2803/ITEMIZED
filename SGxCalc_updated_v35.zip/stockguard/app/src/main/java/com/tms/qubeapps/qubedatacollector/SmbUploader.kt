package com.tms.qubeapps.qubedatacollector

import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.SmbConfig
import com.hierynomus.smbj.connection.Connection
import com.hierynomus.smbj.session.Session
import java.util.concurrent.TimeUnit
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.share.DiskShare
import jcifs.context.SingletonContext
import java.io.InputStreamReader
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * SMB upload/download menggunakan library smbj.
 *
 * Format smbPath dari Setting: smb://HOSTNAME/shareName/subfolder/
 * Contoh: smb://BACKEND/QasDev/QubeV10/BackEnd/Data
 * Juga menerima path gaya Windows Explorer yang di-copy-paste apa adanya:
 * \\BACKEND\QasDev\QubeV10\BackEnd\Data
 *
 * Parsing:
 *   host      = BACKEND
 *   shareName = QasDev
 *   subPath   = QubeV10\BackEnd\Data
 *
 * ★ FIX bug sebelumnya:
 *   - Validasi smbUrl/host/share kosong → pesan error jelas (bukan NPE generik)
 *   - try-finally eksplisit untuk pastikan connection ditutup walau error
 *
 * ★ FIX (upload/download SMB selalu gagal walau 1 jaringan & folder sudah share):
 *   1. Path gaya Windows (\\SERVER\share\folder) sekarang diterima juga —
 *      sebelumnya kalau user copy-paste path dari Windows Explorer (pakai
 *      backslash, bukan format smb://), parsing gagal total karena tidak
 *      ada karakter "/" untuk memisahkan host & share.
 *   2. smbj HANYA bisa connect pakai alamat IP atau nama yang terdaftar di
 *      DNS — TIDAK BISA resolve nama komputer Windows (NetBIOS name) seperti
 *      "BACKEND". Windows bisa connect ke nama itu karena Windows otomatis
 *      broadcast NetBIOS untuk mencari nama tsb; Android tidak. Ini penyebab
 *      paling umum kenapa SMB "selalu gagal" walau HP & server sudah satu
 *      jaringan dan folder sudah di-share dengan benar. Sekarang sebelum
 *      connect, hostname di-resolve dulu: coba IP langsung → coba DNS →
 *      fallback ke resolusi NetBIOS (lewat jcifs-ng). Kalau semua gagal,
 *      pesan error menyarankan user isi SMB Path pakai alamat IP server.
 */
object SmbUploader {

    private data class SmbParts(val host: String, val share: String, val subPath: String)

    /** ★ FIX (baru): host/IP dari sebuah SMB Path (smb://HOST/share/... atau \\\\HOST\\share). null bila kosong/tidak valid. */
    fun hostOf(smbUrl: String): String? {
        if (smbUrl.isBlank()) return null
        val stripped = smbUrl.trim().replace('\\', '/').removePrefix("smb://").removePrefix("SMB://").trimStart('/')
        return stripped.split("/").firstOrNull { it.isNotBlank() }
    }

    /** ★ FIX (baru): ganti host pada SMB Path dengan [newHost], share dan folder tetap. Path tidak valid dikembalikan apa adanya. */
    fun replaceHost(smbUrl: String, newHost: String): String {
        val p = try { parse(smbUrl) } catch (e: Exception) { return smbUrl }
        return "smb://" + newHost + "/" + p.share + (if (p.subPath.isNotEmpty()) "/" + p.subPath.replace('\\', '/') else "")
    }

    private fun parse(smbUrl: String): SmbParts {
        if (smbUrl.isBlank()) {
            throw IllegalArgumentException("SMB Path is empty. Fill it in Settings first (example: smb://SERVER/share/folder)")
        }
        // FIX: normalisasi dulu. User sering copy-paste path ala Windows Explorer
        // (\\SERVER\share\folder) yang pakai backslash, bukan format smb://.
        // Backslash diubah ke forward-slash supaya parsing di bawah konsisten
        // untuk kedua format.
        val normalized = smbUrl.trim().replace('\\', '/')
        val stripped = normalized
            .removePrefix("smb://").removePrefix("SMB://")
            .trimStart('/')   // buang sisa leading "//" dari UNC path (\\SERVER\...)
            .trimEnd('/')
        val parts = stripped.split("/").filter { it.isNotBlank() }
        val host = parts.getOrNull(0)
            ?: throw IllegalArgumentException("Invalid SMB Path: hostname not found")
        val share = parts.getOrNull(1)
            ?: throw IllegalArgumentException(
                "Invalid SMB Path: share name not found " +
                "(example: smb://HOST/SHARE/folder or \\\\HOST\\SHARE\\folder)"
            )
        val sub = parts.drop(2).joinToString("\\")
        return SmbParts(host, share, sub)
    }

    /**
     * FIX: resolusi hostname → IP sebelum connect.
     * smbj (client.connect) tidak punya resolver NetBIOS, jadi kalau SMB Path
     * diisi nama komputer (mis. "BACKEND", bukan IP), koneksi bisa selalu
     * gagal walau device sudah 1 jaringan & folder sudah di-share — karena
     * Android tidak tahu cara menerjemahkan nama itu ke alamat IP tanpa
     * bantuan resolver NetBIOS (yang otomatis ada di Windows).
     *
     * Urutan coba:
     *   1. Kalau host sudah berupa IP → langsung pakai, tidak perlu resolve apa-apa.
     *   2. Coba DNS biasa (InetAddress.getByName) — jalan kalau jaringan
     *      punya DNS server lokal / hosts file yang mengenal nama itu.
     *   3. Fallback ke resolusi NetBIOS lewat jcifs-ng (NbtAddress) — ini yang
     *      menyamai cara Windows menemukan nama komputer di LAN/WiFi yang sama.
     */
    /** Cache hostname → IP yang pernah berhasil di-resolve. */
    private val resolvedCache = ConcurrentHashMap<String, String>()

    private fun resolveHost(host: String): String {
        val ipRegex = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
        if (ipRegex.matches(host)) return host

        try {
            val addr = InetAddress.getByName(host)
            if (!addr.isLoopbackAddress) { resolvedCache[host.uppercase()] = addr.hostAddress; return addr.hostAddress }
        } catch (_: Exception) {
            // lanjut coba resolusi NetBIOS di bawah
        }
        // NetBIOS broadcast kadang hilang di WiFi: coba sampai 3x, lalu pakai IP yang pernah berhasil.
        for (i in 0 until 3) {
            try {
                val ip = SingletonContext.getInstance().nameServiceClient.getNbtByName(host).hostAddress
                resolvedCache[host.uppercase()] = ip
                return ip
            } catch (_: Exception) { }
        }
        resolvedCache[host.uppercase()]?.let { return it }

        return try {
            // FIX: jcifs-ng (beda dari jCIFS versi lama) tidak punya method static
            // NbtAddress.getByName lagi — semua lewat CIFSContext.
            // SingletonContext.getInstance() = context global default (setara
            // perilaku jCIFS lama), lalu getNameServiceClient().getNbtByName()
            // yang melakukan broadcast NetBIOS untuk cari IP dari nama komputer.
            val nbt = SingletonContext.getInstance().nameServiceClient.getNbtByName(host)
            nbt.hostAddress
        } catch (e: Exception) {
            throw Exception(
                "Unable to find server '$host' on the network (failed to resolve name to IP). " +
                "Android devices cannot always resolve Windows computer names the way Windows " +
                "can. Try entering the SMB Path using the server's IP address, e.g. smb://192.168.1.10/share/folder " +
                "(check the server IP via Command Prompt on the PC server: type 'ipconfig')."
            )
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // ★ FIX (PC tanpa password / Guest): LOGIN BERTINGKAT (auth ladder)
    //
    // MASALAH: Windows secara default MENOLAK login jaringan memakai akun yang
    // password-nya kosong (kebijakan "Limit local account use of blank
    // passwords to console logon only"). Di sisi lain, username default 'admin'
    // biasanya tidak ada di PC. Hasilnya STATUS_LOGON_FAILURE walau share-nya
    // sebenarnya terbuka untuk Guest/Everyone.
    //
    // SOLUSI: jangan menyerah di login pertama. Urutan percobaan:
    //   1. Akun yang diisi di Setting (kalau Username tidak kosong)
    //   2. Guest      → akun "Guest" bawaan Windows, password kosong
    //   3. Anonymous  → tanpa username (null session)
    // Tiap percobaan = koneksi baru (aman setelah login gagal) + langsung
    // diuji connectShare, karena login Guest bisa "berhasil" tapi share-nya
    // menolak. Cara yang terakhir berhasil diingat (cache) per server+akun,
    // jadi upload berikutnya tidak mengulang percobaan yang pasti gagal.
    // ══════════════════════════════════════════════════════════════════

    private enum class AuthKind(val label: String) {
        ACCOUNT("account"), GUEST("Guest"), ANONYMOUS("anonymous")
    }

    private data class Cred(val kind: AuthKind, val name: String, val ctx: AuthenticationContext)

    /** Cara login yang terakhir berhasil, kunci = "host|username". */
    private val lastWorkingKind = ConcurrentHashMap<String, AuthKind>()

    private fun buildCandidates(host: String, username: String, password: String, domain: String): List<Cred> {
        val list = ArrayList<Cred>(3)
        if (username.isNotBlank()) {
            list.add(Cred(AuthKind.ACCOUNT, "account '$username'",
                AuthenticationContext(username, password.toCharArray(), domain.ifBlank { null })))
        }
        list.add(Cred(AuthKind.GUEST, "Guest", AuthenticationContext.guest()))
        list.add(Cred(AuthKind.ANONYMOUS, "anonymous", AuthenticationContext.anonymous()))
        // Taruh cara yang terakhir berhasil di urutan pertama.
        val cached = lastWorkingKind["$host|$username"]
        return if (cached != null) list.sortedBy { if (it.kind == cached) 0 else 1 } else list
    }

    private fun smbConfig(): SmbConfig = SmbConfig.builder()
        .withTimeout(20, TimeUnit.SECONDS)
        .withSoTimeout(30, TimeUnit.SECONDS)
        .withSigningRequired(false)   // sesi Guest/Anonymous tidak bisa di-sign
        .build()

    /** Koneksi SMB yang sudah terbuka sampai ke share; tutup dengan close(). */
    private class OpenShare(
        val client: SMBClient, val connection: Connection,
        val session: Session, val share: DiskShare, val usedLabel: String
    ) : AutoCloseable {
        override fun close() {
            runCatching { share.close() }
            runCatching { session.close() }
            runCatching { connection.close() }
            runCatching { client.close() }
        }
    }

    /**
     * Buka koneksi → login (dengan tangga fallback di atas) → connectShare.
     * Melempar Exception dengan awalan "Authentication failed" / "Unable to access share"
     * / "Failed to connect" (awalan dipakai PendingSmbQueue.isConfigError).
     */
    private fun openShare(parts: SmbParts, username: String, password: String, domain: String): OpenShare {
        val host = parts.host
        val resolvedHost = resolveHost(host)
        val attempts = ArrayList<String>()
        var anyAuthenticated = false

        for (cred in buildCandidates(host, username, password, domain)) {
            val client = SMBClient(smbConfig())
            var connection: Connection? = null
            var session: Session? = null
            try {
                val conn: Connection = try {
                    client.connect(resolvedHost)
                } catch (e: Exception) {
                    client.close()
                    // Server tidak terjangkau = bukan masalah login; langsung berhenti.
                    throw Exception("Failed to connect to server '$host' ($resolvedHost). Make sure the device is on the same network as the server and the hostname/IP is correct. (${e.message})")
                }
                connection = conn
                val sess: Session = conn.authenticate(cred.ctx)
                session = sess
                anyAuthenticated = true
                val share = sess.connectShare(parts.share)
                if (share !is DiskShare) {
                    throw Exception("'${parts.share}' is not a folder share (it may be a printer/pipe)")
                }
                lastWorkingKind["$host|$username"] = cred.kind
                return OpenShare(client, conn, sess, share, cred.name)
            } catch (e: Exception) {
                if (e.message?.startsWith("Failed to connect") == true) throw e
                attempts.add("${cred.name} → ${shortErr(e)}")
                runCatching { session?.close() }
                runCatching { connection?.close() }
                runCatching { client.close() }
            }
        }

        val tried = attempts.joinToString("; ")
        if (anyAuthenticated) {
            // Login (mis. Guest) diterima, tapi share-nya menolak akses.
            throw Exception(
                "Unable to access share '${parts.share}'. The server accepted the login but denied access to the share " +
                "(check the share name, and that 'Everyone' or the account has Read/Write permission on BOTH the Sharing tab and the Security tab). Tried: $tried"
            )
        }
        throw Exception("Authentication failed. ${authHint(username)} Tried: $tried")
    }

    private fun shortErr(e: Exception): String {
        val m = e.message ?: e.javaClass.simpleName
        return Regex("STATUS_[A-Z_]+").find(m)?.value ?: m.take(120)
    }

    private fun authHint(username: String): String =
        "The server rejected every login method (the account${if (username.isBlank()) "" else " '$username'"}, Guest, and anonymous). " +
        "On the PC server do ONE of these: " +
        "(A) Allow Guest access: Control Panel → Network and Sharing Center → Advanced sharing settings → All Networks → turn OFF 'Password protected sharing', " +
        "run 'net user guest /active:yes' in Command Prompt (Admin), then share the folder to 'Everyone' with Read/Write. " +
        "(B) Keep using an account: it must be a REAL Windows account on that PC — Windows rejects network logins with an EMPTY password by default, " +
        "so either set a password on that account or disable the policy 'Accounts: Limit local account use of blank passwords to console logon only' (secpol.msc → Local Policies → Security Options). " +
        "(C) If the PC joined an office Domain, also fill in the Domain field in Settings.";

    /** Jalankan [block] di atas koneksi share yang sudah login, lalu tutup semuanya. */
    private inline fun <T> withShare(smbUrl: String, username: String, password: String,
                                     domain: String, block: (DiskShare, String) -> T): T {
        val parts = parse(smbUrl)
        openShare(parts, username, password, domain).use { open ->
            return block(open.share, parts.subPath)
        }
    }

    private fun writeFile(share: DiskShare, filePath: String, bytes: ByteArray) {
        val file = share.openFile(
            filePath,
            setOf(AccessMask.GENERIC_WRITE),
            null,
            setOf(SMB2ShareAccess.FILE_SHARE_WRITE),
            SMB2CreateDisposition.FILE_OVERWRITE_IF,
            null
        )
        try {
            file.outputStream.use { out -> out.write(bytes) }
        } finally {
            file.close()
        }
    }

    private fun openForRead(share: DiskShare, filePath: String, fileName: String) =
        run {
            if (!share.fileExists(filePath)) throw Exception("File '$fileName' not found on server")
            share.openFile(
                filePath,
                setOf(AccessMask.GENERIC_READ),
                null,
                setOf(SMB2ShareAccess.FILE_SHARE_READ),
                SMB2CreateDisposition.FILE_OPEN,
                null
            )
        }

    private fun joinPath(subPath: String, fileName: String) =
        if (subPath.isNotEmpty()) "$subPath\\$fileName" else fileName

    /**
     * ★ FIX (Menu 5 — Export PDF): upload file BINARY (mis. PDF) ke server SMB.
     * Menerima ByteArray mentah — tidak boleh lewat String/Charset karena akan
     * merusak isi file biner.
     */
    fun uploadBytes(smbUrl: String, username: String, password: String,
                    fileName: String, bytes: ByteArray, domain: String = "") {
        withShare(smbUrl, username, password, domain) { share, subPath ->
            writeFile(share, joinPath(subPath, fileName), bytes)
        }
    }

    /**
     * Upload string content ke file di server SMB.
     * Melempar Exception jika gagal — panggil dari Dispatchers.IO.
     */
    fun upload(smbUrl: String, username: String, password: String,
               fileName: String, content: String, domain: String = "") {
        uploadBytes(smbUrl, username, password, fileName, content.toByteArray(Charsets.UTF_8), domain)
    }

    /**
     * FIX (APK Download): download file BINARY dari SMB, return sebagai ByteArray
     * mentah — TIDAK boleh lewat Charset (akan merusak file biner).
     */
    fun downloadBytes(smbUrl: String, username: String, password: String,
                      fileName: String, domain: String = ""): ByteArray =
        withShare(smbUrl, username, password, domain) { share, subPath ->
            val file = openForRead(share, joinPath(subPath, fileName), fileName)
            try {
                file.inputStream.use { it.readBytes() }
            } finally {
                file.close()
            }
        }

    /**
     * Download file dari SMB, return sebagai String (UTF-8).
     * Baca per-chunk supaya progres (done/total byte) bisa dilaporkan;
     * total = -1 kalau ukuran file tidak bisa dibaca.
     */
    fun download(smbUrl: String, username: String, password: String,
                 fileName: String, domain: String = "",
                 onProgress: ((done: Long, total: Long) -> Unit)? = null): String =
        withShare(smbUrl, username, password, domain) { share, subPath ->
            val filePath = joinPath(subPath, fileName)
            val file = openForRead(share, filePath, fileName)
            try {
                val total = runCatching {
                    share.getFileInformation(filePath).standardInformation.endOfFile
                }.getOrDefault(-1L)
                val out = java.io.ByteArrayOutputStream(
                    if (total in 1..Int.MAX_VALUE.toLong()) total.toInt() else 64 * 1024)
                file.inputStream.use { ins ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress?.invoke(done, total)
                    }
                }
                out.toString("UTF-8")
            } finally {
                file.close()
            }
        }
}
