package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.widget.ArrayAdapter
import android.widget.Spinner
import java.util.Calendar
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

/**
 * ★ X-Ref (tahap 1) — padanan Android dari xref.py, tab "Ambil Ref":
 *   1. Buka & Login  2. Pindai Ref No  3. Ambil SKU dari Ref terpilih  + Auto (1→2→pilih→3).
 * Data masuk ke cache lokal (XRef.loadCache/saveCache). Tahap berikutnya: tab Data SKU, Excel, Stock Enquiry, Google Sheet.
 */
class XRefActivity : BaseActivity() {

    private lateinit var browser: XRefBrowser
    private lateinit var s: XRefSettings
    private var cache = mutableListOf<JSONObject>()
    private var items: List<XRef.RefItem> = emptyList()
    private var listWv: WebView? = null
    private var listUrl = ""
    private var opened = false
    private var job: Job? = null
    private var showBrowser = false

    private lateinit var tvLog: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var tvStatus: TextView
    private lateinit var prog: ProgressBar
    private lateinit var btnView: Button
    private val actionButtons = ArrayList<Button>()
    private var stock = mutableListOf<JSONObject>()
    private var settingsUnlocked = false

    // pemilih file kredensial Google (.json) untuk dialog Pengaturan
    private var credTarget: ((String) -> Unit)? = null
    private val pickCred = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val txt = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                credTarget?.invoke(txt)
            } catch (e: Exception) { Toast.makeText(this, "Gagal membaca file: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_xref)
        s = XRefSettings.load(this)
        cache = XRef.loadCache(this)
        stock = XRef.loadStock(this)

        tvLog = findViewById(R.id.tvXLog)
        logScroll = findViewById(R.id.xrLogScroll)
        tvStatus = findViewById(R.id.tvXStatus)
        prog = findViewById(R.id.xrProg)
        btnView = findViewById(R.id.btnXView)
        browser = XRefBrowser(this, findViewById<FrameLayout>(R.id.xrWebHost)) { appendLog(it) }

        findViewById<View>(R.id.btnXBack).setOnClickListener { finish() }
        listOf(R.id.btnXOpen, R.id.btnXScan, R.id.btnXFetch, R.id.btnXAuto, R.id.btnXStock).forEach { actionButtons.add(findViewById(it)) }
        findViewById<View>(R.id.btnXStock).setOnClickListener { showStockDialog() }

        findViewById<View>(R.id.btnXOpen).setOnClickListener { runJob { doOpen() } }
        findViewById<View>(R.id.btnXScan).setOnClickListener { runJob { doScan() } }
        findViewById<View>(R.id.btnXFetch).setOnClickListener { runJob { cmdFetch() } }
        findViewById<View>(R.id.btnXAuto).setOnClickListener { runJob { cmdAuto() } }
        findViewById<View>(R.id.btnXStop).setOnClickListener {
            if (job?.isActive == true) job?.cancel() else Toast.makeText(this, "Tidak ada proses berjalan", Toast.LENGTH_SHORT).show()
        }
        btnView.setOnClickListener { setBrowserVisible(!showBrowser) }

        // ── dropdown: Data ▾ / Ekspor ▾ / ⋮ ──
        findViewById<View>(R.id.btnXData).setOnClickListener { v ->
            popup(v, listOf(
                "Data SKU" to { startActivity(Intent(this, XRefGridActivity::class.java).putExtra(XRefGridActivity.EXTRA_KIND, XRefGridActivity.SKU)) },
                "Data Stock Enquiry" to { startActivity(Intent(this, XRefGridActivity::class.java).putExtra(XRefGridActivity.EXTRA_KIND, XRefGridActivity.STOCK)) }
            ))
        }
        findViewById<View>(R.id.btnXExport).setOnClickListener { v ->
            popup(v, listOf(
                "Export Excel (HP / SMB)" to { showExcelToDeviceDialog() },
                "Bagikan CSV" to { shareCsv() },
                "Google Sheet…" to { showGsheetMenu() }
            ))
        }
        findViewById<View>(R.id.btnXMore).setOnClickListener { v ->
            popup(v, listOf(
                "Pengaturan" to { openSettings() },
                "Reset proses" to { showResetDialog() },
                "Hapus cache SKU" to { confirmClearCache() }
            ))
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (showBrowser && browser.main.canGoBack()) browser.main.goBack()
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        setBrowserVisible(false)
        refreshStatus()
        appendLog("X-Ref siap. Isi Pengaturan (login & filter) lalu tekan Auto ▶, atau jalankan langkah 1 → 2 → 3.")
    }

    override fun onResume() {
        super.onResume()
        // layar Data SKU / Data Stock bisa mengubah cache: muat ulang
        cache = XRef.loadCache(this); stock = XRef.loadStock(this)
        s = XRefSettings.load(this)
        refreshStatus()
    }

    override fun onDestroy() {
        job?.cancel()
        browser.destroy()
        super.onDestroy()
    }

    // ── UI helper ────────────────────────────────────────────────────────
    private fun appendLog(m: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        tvLog.append("$t  $m\n")
        if (tvLog.length() > 24000) tvLog.text = tvLog.text.toString().takeLast(16000)
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setBrowserVisible(v: Boolean) {
        showBrowser = v
        logScroll.visibility = if (v) View.INVISIBLE else View.VISIBLE
        btnView.text = if (v) "Log" else "Browser"
    }

    private fun setBusy(on: Boolean) {
        actionButtons.forEach { it.isEnabled = !on }
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setProgress(n: Int, total: Int) {
        prog.max = if (total > 0) total else 1
        prog.progress = n
    }

    /** Menu dropdown kecil di bawah tombol [anchor]. */
    private fun popup(anchor: View, entries: List<Pair<String, () -> Unit>>) {
        val pm = android.widget.PopupMenu(this, anchor)
        entries.forEachIndexed { i, e -> pm.menu.add(0, i, i, e.first) }
        pm.setOnMenuItemClickListener { item -> entries.getOrNull(item.itemId)?.second?.invoke(); true }
        pm.show()
    }

    private fun shareCsv() {
        if (cache.isEmpty()) Toast.makeText(this, "Cache masih kosong", Toast.LENGTH_SHORT).show()
        else ShareHelper.shareTextAsFile(this, "data_sku_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".csv",
            XRef.toCsv(cache), "Bagikan Data SKU")
    }

    private fun confirmClearCache() {
        AlertDialog.Builder(this).setTitle("Hapus cache SKU?")
            .setMessage("${cache.size} baris data SKU di HP ini akan dihapus. Data di situs ERP tidak terpengaruh.")
            .setPositiveButton("Hapus") { _, _ -> cache.clear(); XRef.clearCache(this); refreshStatus(); appendLog("Cache dihapus.") }
            .setNegativeButton("Batal", null).show()
    }

    // ── ★ Reset proses: mulai dari awal ──────────────────────────────────
    private fun showResetDialog() {
        val dp = resources.displayMetrics.density
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * dp).toInt(), (8 * dp).toInt(), (20 * dp).toInt(), 0) }
        box.addView(TextView(this).apply {
            text = "Proses dihentikan dan kembali ke awal: langkah 1 (Buka) → 2 (Pindai) → 3 (Ambil), daftar Ref, progres, dan log dikosongkan."
            textSize = 13f
        })
        val cbLogout = CheckBox(this).apply { text = "Logout situs ERP (hapus sesi login di browser X-Ref)"; isChecked = true }
        val cbSku = CheckBox(this).apply { text = "Hapus juga Data SKU (${cache.size} baris)" }
        val cbStock = CheckBox(this).apply { text = "Hapus juga Data Stock (${stock.size} baris)" }
        box.addView(cbLogout); box.addView(cbSku); box.addView(cbStock)
        box.addView(TextView(this).apply {
            text = "Data SKU / Stock yang tidak dicentang tetap tersimpan. Pengaturan X-Ref tidak berubah."
            textSize = 12f; setTextColor(android.graphics.Color.parseColor("#6B7280"))
        })
        AlertDialog.Builder(this).setTitle("Reset proses X-Ref?").setView(box)
            .setPositiveButton("Reset") { _, _ -> resetProcess(cbLogout.isChecked, cbSku.isChecked, cbStock.isChecked) }
            .setNegativeButton("Batal", null).show()
    }

    private fun resetProcess(logout: Boolean, clearSku: Boolean, clearStock: Boolean) {
        job?.cancel(); job = null
        setBusy(false)
        opened = false
        items = emptyList()
        listWv = null; listUrl = ""
        browser.reset(logout)
        if (clearSku) { cache.clear(); XRef.clearCache(this) }
        if (clearStock) { stock.clear(); XRef.clearStock(this) }
        s = XRefSettings.load(this)
        tvLog.text = ""
        setProgress(0, 0)
        setBrowserVisible(false)
        refreshStatus()
        appendLog("Proses direset" + (if (logout) " (sesi login dihapus)" else "") +
            (if (clearSku) ", Data SKU dihapus" else "") + (if (clearStock) ", Data Stock dihapus" else "") +
            ". Mulai lagi dari langkah 1 (Buka) atau tekan Auto ▶.")
    }

    // ── ★ Export Excel ke penyimpanan internal HP (Download/XRef) ────────
    private fun showExcelToDeviceDialog() {
        AlertDialog.Builder(this).setTitle("Export Excel")
            .setItems(arrayOf("Simpan ke HP (Download/XRef)", "Kirim ke PC lewat SMB")) { _, d -> chooseExcelData(smb = d == 1) }
            .setNegativeButton("Batal", null).show()
    }

    private fun chooseExcelData(smb: Boolean) {
        val opts = arrayOf("Data SKU (${cache.size} baris)", "Data Stock Enquiry (${stock.size} baris)", "Keduanya")
        AlertDialog.Builder(this).setTitle(if (smb) "Kirim Excel ke PC (SMB)" else "Simpan Excel ke HP")
            .setItems(opts) { _, w ->
                val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                val snapCache: List<JSONObject> = ArrayList(cache); val snapStock: List<JSONObject> = ArrayList(stock)   // salinan: aman dari perubahan saat kirim
                val jobs = ArrayList<Triple<String, String, () -> ByteArray>>()   // label, nama file, pembuat
                val problems = ArrayList<String>()
                if (w == 0 || w == 2) { if (cache.isEmpty()) problems.add("Data SKU masih kosong") else jobs.add(Triple("Data SKU", "data_sku_$stamp.xlsx") { XRefXlsx.sku(snapCache) }) }
                if (w == 1 || w == 2) { if (stock.isEmpty()) problems.add("Data Stock masih kosong") else jobs.add(Triple("Data Stock", "stock_enquiry_$stamp.xlsx") { XRefXlsx.stock(snapStock, s) }) }
                lifecycleScope.launch(Safe.handler) {
                    val saved = ArrayList<String>()
                    if (smb) appendLog("Mengirim Excel ke PC (SMB)…")
                    for ((label, name, build) in jobs) {
                        try {
                            saved.add(withContext(Dispatchers.IO) {
                                val bytes = build()
                                if (smb) XRefShare.saveToSmb(this@XRefActivity, name, bytes)
                                else XRefShare.saveToDevice(this@XRefActivity, name, bytes, XRefShare.XLSX)
                            })
                        } catch (e: Exception) { problems.add("$label gagal: ${e.message}") }
                    }
                    val msg = buildString {
                        if (saved.isNotEmpty()) append((if (smb) "Terkirim ke PC:\n" else "Tersimpan di penyimpanan HP:\n") + saved.joinToString("\n") { "• $it" })
                        if (problems.isNotEmpty()) { if (isNotEmpty()) append("\n\n"); append(problems.joinToString("\n") { "⚠ $it" }) }
                    }
                    appendLog(msg.replace("\n", " | "))
                    AlertDialog.Builder(this@XRefActivity)
                        .setTitle(if (saved.isNotEmpty()) (if (smb) "Excel terkirim" else "Excel tersimpan") else "Tidak ada yang disimpan")
                        .setMessage(msg).setPositiveButton("OK", null).show()
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun refreshStatus() {
        val refs = cache.map { XRef.refOf(it.optString("Label")) }.toSet().size
        tvStatus.text = "Ref di daftar: ${items.size} (baru ${items.count { !it.cached }})  ·  Cache: ${cache.size} SKU dari $refs Ref"
    }

    private fun runJob(block: suspend () -> Unit) {
        if (job?.isActive == true) { Toast.makeText(this, "Proses masih berjalan", Toast.LENGTH_SHORT).show(); return }
        setBusy(true)
        job = lifecycleScope.launch(Safe.handler) {
            try {
                block()
            } catch (e: CancellationException) {
                appendLog("Dihentikan.")
                throw e
            } catch (e: Exception) {
                appendLog("ERROR: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                setBusy(false)
                refreshStatus()
            }
        }
    }

    // ── langkah 1: buka + login ──────────────────────────────────────────
    private suspend fun doOpen() {
        val hasCred = s.userId.isNotBlank() && s.password.isNotBlank()
        if (opened) {
            if (hasCred && browser.loginFormVisible() && browser.login(s)) { appendLog("Login otomatis dikirim."); delay(3000) }
            else appendLog("Browser sudah terbuka.")
            return
        }
        opened = true
        appendLog("Membuka ${XRef.LOGIN_URL}")
        browser.open(browser.main, XRef.LOGIN_URL)
        delay(2500)
        if (hasCred) {
            if (browser.login(s)) {
                appendLog("Login otomatis dikirim.")
                delay(3000)
                if (browser.loginFormVisible()) appendLog("Peringatan: form login masih tampil, cek Store Code / User ID / Password (atau login manual lewat tombol Browser).")
            } else appendLog("Form login tidak terlihat (mungkin sudah login).")
        } else appendLog("Data login belum lengkap. Isi di Pengaturan, atau login manual lewat tombol Browser.")
    }

    // ── langkah 2: filter + pindai daftar Ref No ─────────────────────────
    private suspend fun doScan(): Boolean {
        if (!opened) { appendLog("Buka browser dulu (tombol 1)."); return false }
        if (s.listUrl.isNotBlank()) { browser.open(browser.main, s.listUrl); delay(2000) }
        val wv: WebView?
        if (s.autoFilter) {
            appendLog("Mengisi filter...")
            val order = listOf(
                Triple("txtType", "Report Type", s.reportType), Triple("txtStartDate", "Start Date", s.startDate),
                Triple("txtEndDate", "End Date", s.endDate), Triple("txtStatus", "Status", s.status),
                Triple("txttransit", "Transit", s.transit))
            for ((id, name, v) in order) {
                val msg = try { browser.fillField(id, name, v) }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) { "  gagal isi $name: ${(e.message ?: "").take(100)}" }
                if (msg != null) appendLog(msg)
                if (id == "txtType" && v.isNotBlank()) delay(2000)   // perubahan Report Type memicu pemuatan ulang pilihan lain
            }
            if (!browser.clickSearch()) appendLog("  (tombol Search tidak ditemukan)")
            else { appendLog("Search diklik, menunggu hasil..."); delay(3000) }
            wv = browser.findList(40)
        } else wv = browser.findList(5)

        if (wv == null) {
            appendLog("Daftar Ref No tidak ditemukan. Ringkasan halaman:")
            browser.diagnose()
            appendLog("Buka halaman daftar manual lewat tombol Browser, lalu tekan 2 lagi (matikan 'Isi filter otomatis' di Pengaturan bila filter sudah diisi manual).")
            return false
        }
        listWv = wv
        listUrl = wv.url ?: ""
        appendLog("Memindai semua halaman daftar...")
        val found = browser.scanAll(wv)
        val done = cache.map { XRef.refOf(it.optString("Label")) }.toSet()
        found.forEach { it.cached = it.ref in done }
        items = found
        val total = found.sumOf { it.sku.replace(Regex("\\D"), "").toIntOrNull() ?: 0 }
        appendLog("Ditemukan ${found.size} Ref No, total SKU sekitar $total.")
        refreshStatus()
        return true
    }

    // ── langkah 3: ambil detail SKU ──────────────────────────────────────
    private suspend fun cmdFetch() {
        if (items.isEmpty()) { appendLog("Belum ada daftar Ref. Pindai dulu (tombol 2)."); return }
        val targets = pickTargets() ?: run { appendLog("Dibatalkan oleh user."); return }
        if (targets.isEmpty()) { appendLog("Tidak ada Ref No baru untuk diambil."); return }
        doFetch(targets)
    }

    private suspend fun cmdAuto() {
        doOpen()
        if (!doScan()) return
        val targets = pickTargets() ?: run { appendLog("Dibatalkan oleh user."); return }
        if (targets.isEmpty()) { appendLog("Tidak ada Ref No baru untuk diambil."); return }
        appendLog("Mode otomatis: mengambil ${targets.size} Ref No (${s.autoPick}).")
        doFetch(targets)
    }

    private suspend fun pickTargets(): List<XRef.RefItem>? {
        if (!s.confirmPick) return if (s.autoPick == "semua") items else items.filter { !it.cached }
        appendLog("Pilih Ref No yang diambil, lalu tekan Lanjutkan.")
        return chooseRefs(items, s.autoPick)
    }

    private suspend fun chooseRefs(list: List<XRef.RefItem>, pick: String): List<XRef.RefItem>? =
        suspendCancellableCoroutine { c ->
            val checked = BooleanArray(list.size) { if (pick == "semua") true else !list[it].cached }
            val labels = Array(list.size) { i ->
                val t = list[i]
                (if (t.cached) "✓ " else "") + "${t.ref}  ·  ${t.remark}  ·  ${t.created}  ·  ${t.sku} SKU"
            }
            val dlg = AlertDialog.Builder(this)
                .setTitle("Pilih Ref No (${list.size})  ✓ = sudah ada di cache")
                .setMultiChoiceItems(labels, checked) { _, i, v -> checked[i] = v }
                .setPositiveButton("Lanjutkan") { _, _ -> if (c.isActive) c.resume(list.filterIndexed { i, _ -> checked[i] }) }
                .setNegativeButton("Batal") { _, _ -> if (c.isActive) c.resume(null) }
                .setOnCancelListener { if (c.isActive) c.resume(null) }
                .create()
            dlg.show()
            c.invokeOnCancellation { dlg.dismiss() }
        }

    private suspend fun doFetch(targets: List<XRef.RefItem>) {
        var lw = listWv ?: run { appendLog("Pindai dulu (tombol 2)."); return }
        setProgress(0, targets.size)
        for ((i, t) in targets.withIndex()) {
            val n = i + 1
            val label = "${t.ref} | ${t.remark}"
            val before = browser.snapshot()
            try {
                val w = browser.ensureList(lw, listUrl)
                if (w == null) { appendLog("Daftar tidak bisa dibuka lagi, berhenti."); break }
                lw = w; listWv = w
                browser.goPage(w, t.page)
                if (!browser.openRef(w, t.ref)) throw IllegalStateException("baris ${t.ref} tidak ditemukan di halaman ${t.page}")
                val rows = browser.grabPage(label, 20)
                val (add, old) = XRef.merge(cache, rows)
                appendLog("[$n/${targets.size}] ${if (rows.isNotEmpty()) "OK    " else "KOSONG"} ${t.ref} (${t.remark}): $add SKU disimpan" +
                        (if (old > 0) ", $old data lama diganti" else ""))
                XRef.saveCache(this, cache)
                browser.closeExtras(before, lw)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                appendLog("[$n/${targets.size}] GAGAL  ${t.ref}: ${e.javaClass.simpleName}: ${(e.message ?: "").take(100)}")
                try { browser.closeExtras(before, lw) } catch (e2: Exception) { }
            }
            setProgress(n, targets.size)
            refreshStatus()
        }
        XRef.saveCache(this, cache)
        appendLog("Selesai. ${cache.size} baris tersimpan di cache. Lihat di 'Data SKU', ekspor lewat Excel / CSV.")
        if (s.gsheetAuto && s.gsheetUrl.isNotBlank()) gsSend(true)
    }

    // ── komponen form bersama ────────────────────────────────────────────
    /** Kolom tanggal: ketik (dd-mm-yyyy / today) ATAU pilih lewat kalender / tombol "Hari ini". */
    private fun addDateField(box: LinearLayout, label: String, value: String): EditText {
        val pad = (16 * resources.displayMetrics.density).toInt()
        box.addView(TextView(this).apply { text = label; textSize = 12f; setPadding(0, pad / 2, 0, 0) })
        val e = EditText(this).apply { setText(value); setSingleLine(true); hint = "today atau dd-mm-yyyy" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        row.addView(e, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "📅"
            setOnClickListener {
                val c = Calendar.getInstance()
                val m = Regex("^(\\d{1,2})[-/](\\d{1,2})[-/](\\d{4})$").find(e.text.toString().trim())
                if (m != null) c.set(m.groupValues[3].toInt(), m.groupValues[2].toInt() - 1, m.groupValues[1].toInt())
                DatePickerDialog(this@XRefActivity, { _, y, mo, d -> e.setText(String.format(Locale.US, "%02d-%02d-%04d", d, mo + 1, y)) },
                    c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }
        })
        row.addView(Button(this).apply { text = "Hari ini"; textSize = 11f; setOnClickListener { e.setText("today") } })
        box.addView(row)
        return e
    }

    /** Dropdown dengan pilihan kosong di awal; nilai tersimpan yang tidak ada di daftar tetap ditampilkan. */
    private fun addCombo(box: LinearLayout, label: String, value: String, key: String): () -> String {
        val pad = (16 * resources.displayMetrics.density).toInt()
        box.addView(TextView(this).apply { text = label; textSize = 12f; setPadding(0, pad / 2, 0, 0) })
        val items = ArrayList<String>(); items.add("")
        // buang item kosong / penanda "-- Select --" dari hasil muat web (pilihan kosong sudah disediakan di atas)
        val placeholder = Regex("^[-\\u2013\\u2014\\s]*(select|pilih)[-\\u2013\\u2014\\s]*$", RegexOption.IGNORE_CASE)
        items.addAll(s.optionsFor(key).filter { it.isNotBlank() && !placeholder.matches(it.trim()) })
        if (value.isNotBlank() && value !in items) items.add(value)
        val shown = items.map { if (it.isEmpty()) "— kosong —" else it }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@XRefActivity, android.R.layout.simple_spinner_dropdown_item, shown)
            setSelection(items.indexOf(value).coerceAtLeast(0))
        }
        box.addView(sp)
        return { items.getOrElse(sp.selectedItemPosition) { "" } }
    }

    // ── Stock Enquiry ────────────────────────────────────────────────────
    private fun showStockDialog() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        box.addView(TextView(this).apply { text = "SKU / Product Code (satu per baris atau pisah koma)"; textSize = 12f })
        val eSku = EditText(this).apply { setText(s.stockSkus); minLines = 4; maxLines = 8; setHorizontallyScrolling(false) }
        box.addView(eSku)
        val eStart = addDateField(box, "Start Date", s.stockStart)
        val eEnd = addDateField(box, "End Date", s.stockEnd)
        AlertDialog.Builder(this).setTitle("Stock Enquiry").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Ambil") { _, _ ->
                s.stockSkus = eSku.text.toString().trim()
                s.stockStart = eStart.text.toString().trim().ifBlank { "today" }
                s.stockEnd = eEnd.text.toString().trim().ifBlank { "today" }
                s.save(this)
                val skus = s.stockSkus.split(Regex("[\\s,;]+")).filter { it.isNotBlank() }.distinct()
                if (skus.isEmpty()) Toast.makeText(this, "Isi SKU / Product Code dulu", Toast.LENGTH_SHORT).show()
                else runJob { doStock(skus) }
            }.setNegativeButton("Batal", null).show()
    }

    private suspend fun doStock(skus: List<String>) {
        val hasCred = s.userId.isNotBlank() && s.password.isNotBlank()
        if (!opened) doOpen()
        val url = s.stockUrl.ifBlank { XRef.STOCK_URL }
        browser.open(browser.main, url); delay(2000)
        if (hasCred && browser.loginFormVisible()) {
            appendLog("Sesi habis, login ulang…")
            browser.login(s); delay(3000)
            browser.open(browser.main, url); delay(2000)
        }
        appendLog("Stock Enquiry: ${skus.size} SKU, ${s.stockStart} s/d ${s.stockEnd}")
        var dumped = false; var announced = false
        setProgress(0, skus.size)
        for ((i, sku) in skus.withIndex()) {
            val n = i + 1
            try {
                for ((id, name, v) in listOf(Triple("txtStartDate", "Start Date", s.stockStart),
                        Triple("txtEndDate", "End Date", s.stockEnd), Triple("productCode", "Product Code", sku))) {
                    val msg = browser.fillField(id, name, v, quiet = true)
                    if (msg != null && !announced) appendLog(msg)
                }
                val prev = browser.peekSig()
                if (!browser.clickSearchText(s.searchText)) {
                    appendLog("[$n/${skus.size}] $sku: tombol Search tidak ditemukan")
                    if (!dumped) { browser.diagnose(); dumped = true }
                    setProgress(n, skus.size); continue
                }
                delay(2500)                                  // pengganti "networkidle" di Playwright
                var found: Pair<List<String>, List<List<String>>>? = null
                for (t in 0 until 30) {
                    found = browser.findTable(prev)
                    if (found != null) break
                    delay(700)
                }
                if (found == null) {
                    appendLog("[$n/${skus.size}] KOSONG $sku: tidak ada data. ${browser.readErrors()}".trim())
                    if (!dumped) { browser.diagnose(); dumped = true }
                    setProgress(n, skus.size); continue
                }
                val (heads, trows) = found
                val recs = trows.map { row ->
                    val rec = JSONObject().put("SKU", sku)
                    row.forEachIndexed { ci, v ->
                        val nm = heads.getOrNull(ci)?.takeIf { it.isNotBlank() } ?: "Kolom ${ci + 1}"
                        rec.put(nm, v)
                    }
                    rec
                }
                val sc = XRef.findStockCols(XRef.stockCols(recs), s)
                val (merged, removed) = XRef.mergeStock(stock, recs, sku, sc.ref)
                stock = merged
                XRef.saveStock(this, stock)
                appendLog("[$n/${skus.size}] OK     $sku: ${recs.size} baris" + (if (removed > 0) ", $removed data lama (Ref sama) diganti" else ""))
                if (!announced) {
                    announced = true
                    appendLog("Kolom terdeteksi: Ref=${sc.ref ?: "-"}, Balance=${sc.bal ?: "-"}, Transit In=${sc.tin ?: "-"}")
                    if (sc.ref == null || sc.bal == null)
                        appendLog("  Kolom Ref/Balance belum ketemu. Isi nama kolom di Pengaturan > Kolom Stock Enquiry. Kolom tersedia: " + XRef.stockCols(recs).joinToString(", "))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                appendLog("[$n/${skus.size}] GAGAL  $sku: ${e.javaClass.simpleName}: ${(e.message ?: "").take(100)}")
            }
            setProgress(n, skus.size)
        }
        XRef.saveStock(this, stock)
        appendLog("Selesai. ${stock.size} baris Stock Enquiry tersimpan. Lihat di 'Data Stock'.")
        if (s.gsheetAuto && s.gsheetUrl.isNotBlank()) gsSend(false)
    }

    // ── Google Sheet ─────────────────────────────────────────────────────
    private suspend fun gsSend(sku: Boolean) {
        if (s.gsheetUrl.isBlank() || s.gsheetCred.isBlank()) { appendLog("Google Sheet: isi Link Sheet dan file kredensial di Pengaturan."); return }
        appendLog("Mengirim ke Google Sheet…")
        val values = if (sku) XRef.tableValues(cache) else XRef.stockValues(XRef.stockRowsWithSum(stock, s))
        val tab = if (sku) s.gsheetTab else s.gsheetStockTab
        appendLog(withContext(Dispatchers.IO) { XRefGSheet.send(s, tab, values) })
    }

    private fun showGsheetMenu() {
        AlertDialog.Builder(this).setTitle("Google Sheet")
            .setItems(arrayOf("Kirim Data SKU", "Kirim Stock Enquiry", "Tes koneksi", "Tutorial aktifkan Google Sheet")) { _, w ->
                when (w) {
                    0 -> runJob { gsSend(true) }
                    1 -> runJob { gsSend(false) }
                    2 -> runJob { appendLog("Menguji koneksi…"); appendLog(withContext(Dispatchers.IO) { XRefGSheet.test(s) }) }
                    else -> showGsTutorial()
                }
            }.show()
    }

    private fun showGsTutorial() {
        val steps = listOf(
            "Buat project Google Cloud" to "Buka console.cloud.google.com/projectcreate (login akun Google), buat project baru, nama bebas.",
            "Aktifkan Google Sheets API" to "Di project itu buka APIs & Services > Library, cari 'Google Sheets API', klik ENABLE. (Drive API tidak wajib di aplikasi HP.)",
            "Buat Service Account" to "IAM & Admin > Service Accounts > Create service account. Isi nama (mis. ambil-ref) lalu Done. Role tidak wajib.",
            "Unduh kunci JSON" to "Klik service account itu > Keys > Add key > Create new key > JSON > Create. File .json terunduh ke HP/PC; pindahkan ke HP bila perlu. Boleh memakai file yang sama dengan versi PC.",
            "Pilih file JSON di aplikasi" to "X-Ref > Pengaturan > Google Sheet > 'Pilih file kredensial (.json)'. Isi file disimpan terenkripsi di HP.",
            "Bagikan Google Sheet" to "Buka Google Sheet tujuan > Share > tempel email service account (tombol 'Salin email' ada di Pengaturan) > Editor > Send.",
            "Isi link & nama tab" to "Salin link Sheet ke 'Link Google Sheet', isi nama tab, centang 'Kirim hasil otomatis' bila mau, lalu Simpan.",
            "Tes koneksi" to "Tombol G-Sheet > Tes koneksi. Log menulis 'Koneksi Google Sheet OK' bila berhasil. Catatan: pada akun Google Workspace kantor, pembuatan kunci JSON kadang diblokir admin."
        )
        val txt = steps.mapIndexed { i, (t, b) -> "${i + 1}. $t\n$b" }.joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("Tutorial Google Sheet").setMessage(txt).setPositiveButton("Tutup", null).show()
    }

    // ── pengaturan ───────────────────────────────────────────────────────
    private fun sha256(x: String): String =
        MessageDigest.getInstance("SHA-256").digest(x.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    /** Pengaturan terkunci password (sama dengan versi PC); terbuka selama layar ini aktif. */
    private fun openSettings() {
        if (settingsUnlocked) { showSettings(); return }
        val e = EditText(this).apply { hint = "Password pengaturan"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(e, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle("Pengaturan terkunci").setView(box)
            .setPositiveButton("Buka") { _, _ ->
                if (sha256(e.text.toString()) == "2491da899ee8a70b610aee60b0b3a0f818ab2d683d47709fbe2237bb5ab1c835") { settingsUnlocked = true; showSettings() }
                else Toast.makeText(this, "Password salah", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun showSettings() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        fun section(t: String) = box.addView(TextView(this).apply {
            text = t; textSize = 14f; setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, pad, 0, 0) })
        fun field(label: String, value: String, pw: Boolean = false, hintText: String = ""): EditText {
            box.addView(TextView(this).apply { text = label; textSize = 12f; setPadding(0, pad / 2, 0, 0) })
            val e = EditText(this).apply {
                setText(value); setSingleLine(true); hint = hintText
                if (pw) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            box.addView(e)
            return e
        }
        fun check(text: String, v: Boolean): CheckBox {
            val c = CheckBox(this).apply { this.text = text; isChecked = v }
            box.addView(c)
            return c
        }
        section("Login")
        val eStore = field("Store Code", s.storeCode)
        val eUser = field("User ID", s.userId)
        val ePass = field("Password (disimpan terenkripsi)", s.password, pw = true)
        section("Filter Ref No")
        val eUrl = field("URL halaman daftar Ref (opsional)", s.listUrl, hintText = "https://iderp.mrdiy.com/...")
        val cFilter = check("Isi filter otomatis", s.autoFilter)
        val getType = addCombo(box, "Report Type", s.reportType, "report_type")
        val eStart = addDateField(box, "Start Date", s.startDate)
        val eEnd = addDateField(box, "End Date", s.endDate)
        val getStatus = addCombo(box, "Status", s.status, "status")
        val getTransit = addCombo(box, "Transit", s.transit, "transit")
        val btnLoadOpts = Button(this).apply { text = "↻ Muat pilihan dropdown dari web" }
        box.addView(btnLoadOpts)
        val eSearch = field("Teks tombol Search", s.searchText)
        val cAll = check("Ambil semua Ref (bukan hanya yang belum ada di cache)", s.autoPick == "semua")
        val cConfirm = check("Konfirmasi pilihan Ref sebelum mengambil", s.confirmPick)
        section("Stock Enquiry")
        val eStockUrl = field("URL Stock Enquiry", s.stockUrl)
        val eRefCol = field("Nama kolom Ref", s.stockRefCol, hintText = "kosong = otomatis")
        val eBalCol = field("Nama kolom Balance", s.stockBalanceCol, hintText = "kosong = otomatis")
        val eTinCol = field("Nama kolom Transit In", s.stockTransitCol, hintText = "kosong = otomatis")
        section("Google Sheet")
        val eGsUrl = field("Link Google Sheet", s.gsheetUrl, hintText = "https://docs.google.com/spreadsheets/d/...")
        val eGsTab = field("Nama tab Data SKU", s.gsheetTab)
        val eGsStockTab = field("Nama tab Stock Enquiry", s.gsheetStockTab)
        var credJson = s.gsheetCred
        val tvCred = TextView(this).apply { textSize = 12f; setPadding(0, pad / 2, 0, 0) }
        fun showCred() {
            val em = XRefGSheet.emailOf(credJson)
            tvCred.text = if (credJson.isBlank()) "Kredensial: belum dipilih" else "Kredensial terpasang: " + (if (em.isNotBlank()) em else "(email tidak terbaca)")
        }
        showCred()
        box.addView(tvCred)
        box.addView(Button(this).apply {
            text = "Pilih file kredensial (.json)"
            setOnClickListener {
                credTarget = { txt ->
                    val em = XRefGSheet.emailOf(txt)
                    if (em.isBlank() || !txt.contains("private_key")) Toast.makeText(this@XRefActivity, "Bukan file kredensial service account yang valid", Toast.LENGTH_LONG).show()
                    else { credJson = txt; showCred() }
                }
                pickCred.launch(arrayOf("application/json", "application/octet-stream", "text/plain", "*/*"))
            }
        })
        box.addView(Button(this).apply {
            text = "Salin email service account"
            setOnClickListener {
                val em = XRefGSheet.emailOf(credJson)
                if (em.isBlank()) Toast.makeText(this@XRefActivity, "Pilih file kredensial dulu", Toast.LENGTH_SHORT).show()
                else {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("email", em))
                    Toast.makeText(this@XRefActivity, "Disalin: $em — tempel di Share Google Sheet sebagai Editor", Toast.LENGTH_LONG).show()
                }
            }
        })
        val cGsAuto = check("Kirim hasil ke Google Sheet otomatis", s.gsheetAuto)

        val dlg = AlertDialog.Builder(this).setTitle("Pengaturan X-Ref").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Simpan") { _, _ ->
                s.storeCode = eStore.text.toString().trim(); s.userId = eUser.text.toString().trim()
                s.password = ePass.text.toString(); s.listUrl = eUrl.text.toString().trim()
                s.autoFilter = cFilter.isChecked
                s.reportType = getType(); s.startDate = eStart.text.toString().trim()
                s.endDate = eEnd.text.toString().trim(); s.status = getStatus()
                s.transit = getTransit()
                s.searchText = eSearch.text.toString().trim().ifBlank { "Search" }
                s.autoPick = if (cAll.isChecked) "semua" else "baru"
                s.confirmPick = cConfirm.isChecked
                s.stockUrl = eStockUrl.text.toString().trim().ifBlank { XRef.STOCK_URL }
                s.stockRefCol = eRefCol.text.toString().trim(); s.stockBalanceCol = eBalCol.text.toString().trim()
                s.stockTransitCol = eTinCol.text.toString().trim()
                s.gsheetUrl = eGsUrl.text.toString().trim()
                s.gsheetTab = eGsTab.text.toString().trim().ifBlank { "Data SKU" }
                s.gsheetStockTab = eGsStockTab.text.toString().trim().ifBlank { "Stock Enquiry" }
                s.gsheetCred = credJson; s.gsheetAuto = cGsAuto.isChecked
                s.save(this)
                Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null).create()
        btnLoadOpts.setOnClickListener {
            val url = eUrl.text.toString().trim()
            if (url.isBlank()) { Toast.makeText(this, "Isi URL halaman daftar Ref dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            s.listUrl = url; s.save(this)            // simpan URL agar dipakai saat memuat
            dlg.dismiss()
            runJob { doOptions() }
        }
        dlg.show()
    }

    /** Baca isi dropdown dari halaman Report Enquiry lalu simpan sebagai pilihan (padanan do_options di Python). */
    private suspend fun doOptions() {
        if (!opened) doOpen()
        browser.open(browser.main, s.listUrl); delay(2500)
        val out = browser.readOptions()
        if (out.isEmpty()) { appendLog("Dropdown tidak ditemukan di halaman itu (cek URL / login)."); return }
        s.options = s.options + out
        s.save(this)
        appendLog("Pilihan dimuat: " + out.entries.joinToString(", ") { "${it.key} (${it.value.size})" } + ". Buka Pengaturan lagi untuk memakainya.")
    }
}
