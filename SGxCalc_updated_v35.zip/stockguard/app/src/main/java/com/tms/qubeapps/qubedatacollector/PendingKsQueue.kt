package com.tms.qubeapps.qubedatacollector

import android.content.Context
import com.tms.qubeapps.qubedatacollector.KsUploadLogic.Group
import com.tms.qubeapps.qubedatacollector.KsUploadLogic.Item
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * ★ FIX (baru): antrean offline untuk upload Add Box → Google Sheets. Mirip PendingSmbQueue:
 * kalau jaringan putus saat upload, payload disimpan di penyimpanan internal (folder "pending_ks")
 * — TIDAK di-reset/dibatalkan — lalu dikirim otomatis begitu jaringan stabil (lihat KsQueueWatcher).
 * Token/URL Web App TIDAK disimpan di file; dipakai nilai terbaru dari Setting saat kirim ulang.
 * Aman bila aplikasi ditutup: file tetap ada dan dilanjutkan saat layar Data Collector/Keep Stock dibuka lagi.
 */
object PendingKsQueue {

    const val SRC_DC = "DC"   // Data Collector (Add Box)
    const val SRC_KS = "KS"   // Keep Stock → View Data → ADD

    data class FlushResult(val sentItems: Int, val remaining: Int, val lastError: String?, val failures: List<String>)

    private val lock = Any()
    @Volatile private var flushing = false

    private fun dir(ctx: Context): File = File(ctx.filesDir, "pending_ks").apply { mkdirs() }
    private fun files(ctx: Context): List<File> =
        (dir(ctx).listFiles { f -> f.name.endsWith(".json") } ?: emptyArray()).sortedBy { it.name }

    fun count(ctx: Context): Int = files(ctx).size

    /** ★ Batalkan/hapus semua antrean upload Keep Stock. Reservasi ledger dilepas supaya data boleh dikirim lagi nanti. */
    fun clearAll(ctx: Context): Int = synchronized(lock) {
        var n = 0
        for (f in files(ctx)) {
            try {
                val j = JSONObject(f.readText(Charsets.UTF_8))
                val groups = j.getJSONArray("groups")
                val fps = ArrayList<String>()
                for (i in 0 until groups.length()) {
                    val x = groups.getJSONObject(i).optJSONArray("fps") ?: continue
                    for (k in 0 until x.length()) fps.add(x.getString(k))
                }
                KsUploadLedger.removeAll(ctx, fps)
            } catch (_: Exception) { }
            if (f.delete()) n++
        }
        n
    }

    // ── serialisasi ────────────────────────────────────────────────────
    private fun groupToJson(g: Group) = JSONObject().apply {
        put("noCtn", g.noCtn)
        put("items", JSONArray().also { a -> g.items.forEach { a.put(JSONObject().put("sku", it.sku).put("qty", it.qty)) } })
        put("fps", JSONArray(g.fps))
        put("attempted", g.attempted)
        put("base", JSONObject().also { o -> g.base.forEach { (k, v) -> o.put(k, v) } })
    }

    private fun groupFromJson(o: JSONObject): Group {
        val items = o.getJSONArray("items").let { a -> (0 until a.length()).map { Item(a.getJSONObject(it).getString("sku"), a.getJSONObject(it).getString("qty")) } }
        val fps = o.optJSONArray("fps")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
        val base = HashMap<String, Double>()
        o.optJSONObject("base")?.let { b -> b.keys().forEach { k -> base[k] = b.getDouble(k) } }
        return Group(o.getString("noCtn"), items, fps, o.optBoolean("attempted", false), base)
    }

    private fun write(f: File, store: String, source: String, groups: List<Group>, hist: KsUploadCoordinator.Hist?) {
        val j = JSONObject().put("store", store).put("source", source)
            .put("groups", JSONArray().also { a -> groups.forEach { a.put(groupToJson(it)) } })
        if (hist != null) j.put("hist", JSONObject().put("pic", hist.pic).put("noCtn", hist.noCtn).put("skus", hist.skus).put("qtys", hist.qtys))
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(j.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(f)) { f.writeText(j.toString(), Charsets.UTF_8); tmp.delete() }   // tulis atomik
    }

    fun enqueue(ctx: Context, store: String, source: String, groups: List<Group>, hist: KsUploadCoordinator.Hist?) {
        if (groups.isEmpty()) return
        synchronized(lock) {
            val id = "${System.currentTimeMillis()}_${Integer.toHexString(groups.first().noCtn.hashCode())}"
            write(File(dir(ctx), "$id.json"), store, source, groups, hist)
            KsUploadLedger.putAll(ctx, groups.flatMap { it.fps }, KsUploadLedger.QUEUED)
        }
    }

    /**
     * Kirim semua item antrean (terlama dulu). Berhenti di gangguan jaringan pertama (sisa tetap tersimpan).
     * Panggil dari Dispatchers.IO. Panggilan bersamaan: yang kedua dilewati.
     */
    fun flush(ctx: Context, onProgress: ((Int, Int, String) -> Unit)? = null): FlushResult {
        synchronized(lock) { if (flushing) return FlushResult(0, count(ctx), null, emptyList()); flushing = true }
        var sentItems = 0; var lastError: String? = null; val failures = ArrayList<String>()
        val db = AppDatabase(ctx.applicationContext)
        try {
            val all = files(ctx)
            for ((i, f) in all.withIndex()) {
                try {
                    val j = JSONObject(f.readText(Charsets.UTF_8))
                    val store = j.getString("store"); val source = j.optString("source", SRC_DC)
                    val groups = j.getJSONArray("groups").let { a -> (0 until a.length()).map { groupFromJson(a.getJSONObject(it)) } }
                    val hist = j.optJSONObject("hist")?.let {
                        KsUploadCoordinator.Hist(it.optString("pic"), it.optString("noCtn"), it.optString("skus"), it.optString("qtys"))
                    }
                    val out = KsUploadEngine.run(ctx, store, groups) { d, t, m ->
                        onProgress?.invoke(i * 100 + KsUploadLogic.percent(d, t), all.size * 100, "Antrean ${i + 1}/${all.size}: $m")
                    }
                    val sum = KsUploadCoordinator.complete(ctx, db, store, source, out, hist, enqueueRetry = false)
                    failures.addAll(sum.failureLines)
                    if (out.retry.isEmpty()) { f.delete(); sentItems++ }
                    else { write(f, store, source, out.retry, hist); lastError = out.retryMessage; break }   // jaringan masih bermasalah
                } catch (e: Exception) {
                    lastError = e.message ?: e.javaClass.simpleName
                    break
                }
            }
        } finally { try { db.close() } catch (_: Exception) {}; flushing = false }
        return FlushResult(sentItems, count(ctx), lastError, failures)
    }
}
