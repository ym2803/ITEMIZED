package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.view.animation.AnimationUtils
import com.tms.qubeapps.qubedatacollector.Prefs.catalogUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.dataUpdateMode
import com.tms.qubeapps.qubedatacollector.Prefs.autoUpdateDoneDate
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedCount
import com.tms.qubeapps.qubedatacollector.Prefs.qtyAddUpdatedTime
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedCount
import com.tms.qubeapps.qubedatacollector.Prefs.qtySubtractUpdatedTime
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * ★ FIX (baru — tampilan menu "B · Aksi Cepat"):
 *  • Kolom pencarian: ketik untuk menyaring menu; scan/ketik SKU lalu Enter → langsung dicek di
 *    Shelf Price Enquiry (Data Collector) tanpa membuka menu dulu.
 *  • Quick actions: Price Enquiry / Shelf Record / Stock Take / Add Box langsung membuka Data Collector
 *    di mode itu (lihat DataCollectorActivity.EXTRA_START_MODE).
 *  • Daftar semua menu dengan penjelasan singkat. Setting dipindah ke ikon di header.
 *
 * Catatan lama: Shelf Price Enquiry, Shelf Record, Stock Take & Add Box ada DI DALAM Data Collector;
 * Stock Comparison diakses dari layar Stock Balance Check.
 */
/** Update otomatis dicoba paling banyak sekali per proses aplikasi (bukan tiap layar menu dibuat ulang). */
private var autoDailyTriedThisLaunch = false

class MenuModuleActivity : BaseActivity() {

    data class MenuEntry(
        val title: String,
        val subtitle: String,
        val iconRes: Int,
        val chipColor: Int,          // warna latar chip ikon (pastel)
        val iconColor: Int,          // warna ikon
        val target: Class<*>,
        val modeExtra: String? = null,
        val keywords: String = ""    // kata kunci tambahan untuk pencarian
    )

    private val menuItems = listOf(
        MenuEntry("Stock Balance Check", "Scan SKU, history & stock comparison",
            R.drawable.ic_m_balance, 0xFFE0F2FE.toInt(), 0xFF0369A1.toInt(),
            ShelfPriceEnquireActivity::class.java, ShelfPriceEnquireActivity.MODE_BALANCE,
            "balance history comparison qty system"),
        MenuEntry("Product Master", "Product data, prices & discounts",
            R.drawable.ic_m_tag, 0xFFFFEDD5.toInt(), 0xFFC2410C.toInt(),
            ProductMasterActivity::class.java, null, "product price discount expired discount"),
        MenuEntry("Keep Stock", "Manage regular and receiving keep stock",
            R.drawable.ic_m_box, 0xFFD1FAE5.toInt(), 0xFF047857.toInt(),
            KeepStockLoginActivity::class.java, null, "carton box ctn layout keep stock regular receiving"),
        MenuEntry("Data Collector", "Price Enquiry, Shelf Record, Stock Take & Add Box",
            R.drawable.ic_m_scan, 0xFFFCE7F3.toInt(), 0xFFBE185D.toInt(),
            DataCollectorActivity::class.java, null, "shelf record stock take add box enquiry price"),
        MenuEntry("Itemize", "Scan check per session, synced to Google Sheet",
            R.drawable.ic_m_itemize, 0xFFFEF9C3.toInt(), 0xFF854D0E.toInt(),
            ItemizeMenuActivity::class.java, null, "itemize itemized opname gsheet google sheet setting tutorial apps script"),
        MenuEntry("X-Ref", "Ambil Ref No & SKU dari QubeERP (X-Ref by YM)",
            R.drawable.ic_m_box, 0xFFE0F2FE.toInt(), 0xFF075985.toInt(),
            XRefActivity::class.java, null, "xref x-ref ref no sku qubeerp mrdiy erp stock enquiry ambil")
    )

    private lateinit var adapter: MenuRowAdapter
    private lateinit var etSearch: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_module)

        // FIX: tampilkan setiap kali aplikasi dibuka
        Toast.makeText(this, "© 2026 Yayang Mardiansyah", Toast.LENGTH_SHORT).show()

        etSearch = findViewById(R.id.etMenuSearch)
        val rv = findViewById<RecyclerView>(R.id.rvMenu)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = MenuRowAdapter(menuItems.toMutableList()) { openEntry(it) }
        rv.adapter = adapter
        // transisi masuk lembut: baris menu muncul berurutan (fade + naik tipis)
        rv.layoutAnimation = AnimationUtils.loadLayoutAnimation(this, R.anim.layout_fade_up)

        setupData02Card()
        setupQtyAdjustCard()

        setupQuickActions()
        setupSearch()
        maybeAutoDailyUpdate()

        findViewById<View>(R.id.btnHeaderSetting).setOnClickListener {
            startActivity(Intent(this, SettingActivity::class.java))
        }
        findViewById<View>(R.id.tabFeedback).setOnClickListener {
            FeedbackHelper.showFeedbackDialog(this)
        }
        findViewById<View>(R.id.tabCredits).setOnClickListener {
            startActivity(Intent(this, CreditsActivity::class.java))
        }
    }

    /** ★ FIX (baru): mode Auto — saat aplikasi pertama dibuka dalam sehari, update Data Master (02) + Qty System sekaligus. */
    private fun maybeAutoDailyUpdate() {
        if (dataUpdateMode != "AUTO" || autoDailyTriedThisLaunch) return
        autoDailyTriedThisLaunch = true
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        if (autoUpdateDoneDate == today) return
        window.decorView.post {
            if (isFinishing || isDestroyed) return@post
            startActivity(Intent(this, ShelfPriceEnquireActivity::class.java).apply {
                putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, ShelfPriceEnquireActivity.MODE_ENQUIRE)
                putExtra(ShelfPriceEnquireActivity.EXTRA_AUTO_DOWNLOAD, true)
                putExtra(ShelfPriceEnquireActivity.EXTRA_AUTO_DAILY, true)
            })
        }
    }

    // ── Pintasan Download Data 02 + update terakhir ───────────────────────────
    private fun setupData02Card() {
        findViewById<ImageView>(R.id.ivData02).setColorFilter(0xFF4834D4.toInt())
        // Konfirmasi dulu supaya tidak ter-update karena tersentuh tidak sengaja.
        findViewById<View>(R.id.cardData02).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Update Data Master")
                .setMessage("Download the latest master data (02) from the PC now?\n\n" + data02Summary())
                .setPositiveButton("Update Data") { _, _ ->
                    // proses download yang sama dengan menu ⋮ "Download Latest Data From PC"
                    startActivity(Intent(this, ShelfPriceEnquireActivity::class.java).apply {
                        putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, ShelfPriceEnquireActivity.MODE_ENQUIRE)
                        putExtra(ShelfPriceEnquireActivity.EXTRA_AUTO_DOWNLOAD, true)
                    })
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        refreshData02Updated()
    }

    // ── ★ FIX (baru): pintasan Subtract/Add Qty System + update terakhir ────
    private lateinit var qtyFlow: QtyAdjustFlow

    private fun setupQtyAdjustCard() {
        // harus dibuat di onCreate (registerForActivityResult) — setupQtyAdjustCard() dipanggil dari onCreate
        qtyFlow = QtyAdjustFlow(this) { refreshQtyAdjustUpdated() }
        findViewById<ImageView>(R.id.ivQtyAdjust).setColorFilter(0xFF4834D4.toInt())
        findViewById<View>(R.id.cardQtyAdjust).setOnClickListener {
            // setMessage() + setItems() tidak bisa dipakai bersamaan (daftar pilihan tidak tampil),
            // jadi keterangan update terakhir ditaruh di dalam label pilihan.
            val opts = arrayOf(
                "Subtract Qty System (sales)\nLast: " + fmtAdjust(qtySubtractUpdatedTime, qtySubtractUpdatedCount, "dd MMM yyyy, HH:mm"),
                "Add Qty System\nLast: " + fmtAdjust(qtyAddUpdatedTime, qtyAddUpdatedCount, "dd MMM yyyy, HH:mm"))
            AlertDialog.Builder(this)
                .setTitle("Change Qty System")
                .setItems(opts) { _, which -> qtyFlow.start(if (which == 0) -1 else +1) }
                .setNegativeButton("Cancel", null)
                .show()
        }
        refreshQtyAdjustUpdated()
    }

    private fun fmtAdjust(ts: Long, count: Int, pattern: String): String =
        if (ts > 0L) SimpleDateFormat(pattern, Locale.ENGLISH).format(Date(ts)) +
            (if (count > 0) "  •  %,d SKU".format(Locale.ENGLISH, count) else "")
        else "never"

    private fun refreshQtyAdjustUpdated() {
        fun short(ts: Long) =
            if (ts > 0L) SimpleDateFormat("dd MMM, HH:mm", Locale.ENGLISH).format(Date(ts)) else "-"
        findViewById<TextView>(R.id.tvQtyAdjustUpdated).text =
            "Subtract: ${short(qtySubtractUpdatedTime)}\nAdd: ${short(qtyAddUpdatedTime)}"
    }

    private var data02Count = -1

    private fun data02Summary(): String {
        val ts = catalogUpdatedTime
        val date = if (ts > 0L) SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.ENGLISH).format(Date(ts)) else "never downloaded"
        val cnt = if (data02Count >= 0) "%,d SKU".format(Locale.ENGLISH, data02Count) else "-"
        return "Last update: $date\nUpdated SKUs: $cnt"
    }

    private fun refreshData02Updated() {
        val tv = findViewById<TextView>(R.id.tvData02Updated)
        val ts = catalogUpdatedTime
        fun render() {
            val date = if (ts > 0L) SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.ENGLISH).format(Date(ts)) else "never"
            tv.text = if (ts > 0L && data02Count >= 0)
                "$date  •  " + "%,d SKU".format(Locale.ENGLISH, data02Count)
            else date
        }
        render()
        // jumlah SKU hasil download terakhir = jumlah item katalog 02 (hitung di thread background)
        if (ts > 0L) Thread {
            val n = try { AppDatabase(this).countCatalog() } catch (e: Exception) { -1 }
            runOnUiThread { if (!isFinishing && !isDestroyed) { data02Count = n; render() } }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refreshData02Updated()   // segarkan setelah kembali dari proses download
        refreshQtyAdjustUpdated()
    }

    private fun openEntry(entry: MenuEntry) {
        startActivity(Intent(this, entry.target).apply {
            if (entry.modeExtra != null) putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, entry.modeExtra)
        })
    }

    // ── Quick actions → Data Collector langsung di mode tertentu ─────────────────
    private fun setupQuickActions() {
        fun qa(id: Int, chipId: Int, iconId: Int, chipColor: Int, iconColor: Int, mode: String) {
            (findViewById<View>(chipId).background.mutate() as GradientDrawable).setColor(chipColor)
            findViewById<ImageView>(iconId).setColorFilter(iconColor)
            findViewById<View>(id).setOnClickListener { openDataCollector(mode) }
        }
        qa(R.id.qaEnquiry, R.id.qaEnquiryChip, R.id.qaEnquiryIcon, 0xFFEDE9FE.toInt(), 0xFF4834D4.toInt(), DataCollectorActivity.START_ENQUIRE)
        qa(R.id.qaShelf, R.id.qaShelfChip, R.id.qaShelfIcon, 0xFFE0F2FE.toInt(), 0xFF0369A1.toInt(), "SHELF_RECORD")
        qa(R.id.qaStockTake, R.id.qaStockTakeChip, R.id.qaStockTakeIcon, 0xFFFFEDD5.toInt(), 0xFFC2410C.toInt(), "STOCK_TAKE")
        qa(R.id.qaAddBox, R.id.qaAddBoxChip, R.id.qaAddBoxIcon, 0xFFD1FAE5.toInt(), 0xFF047857.toInt(), "ADD_BOX")
    }

    private fun openDataCollector(mode: String, sku: String? = null) {
        startActivity(Intent(this, DataCollectorActivity::class.java).apply {
            putExtra(DataCollectorActivity.EXTRA_START_MODE, mode)
            if (!sku.isNullOrBlank()) putExtra(DataCollectorActivity.EXTRA_SKU, sku)
        })
    }

    // ── Pencarian menu / scan SKU ─────────────────────────────────────────────
    private fun setupSearch() {
        val clear = findViewById<View>(R.id.btnMenuSearchClear)
        val blockQuick = findViewById<View>(R.id.blockQuick)
        val tvAll = findViewById<TextView>(R.id.tvAllMenu)
        val tvEmpty = findViewById<View>(R.id.tvMenuEmpty)
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim().orEmpty()
                clear.visibility = if (q.isEmpty()) View.GONE else View.VISIBLE
                blockQuick.visibility = if (q.isEmpty()) View.VISIBLE else View.GONE
                tvAll.text = if (q.isEmpty()) "All menus" else "Search results"
                adapter.setItems(filter(q))
                tvEmpty.visibility = if (q.isNotEmpty() && adapter.itemCount == 0) View.VISIBLE else View.GONE
            }
        })
        clear.setOnClickListener { etSearch.setText("") }

        // Enter / Done (juga dari scanner HID): ada menu cocok (teks bukan SKU) → buka menu pertama;
        // selain itu dianggap SKU → cek harga di Shelf Price Enquiry.
        fun submit(): Boolean {
            val q = etSearch.text.toString().trim()
            if (q.isEmpty()) return true
            val hits = filter(q)
            if (hits.isNotEmpty() && !q.any { it.isDigit() }) openEntry(hits.first())
            else { openDataCollector(DataCollectorActivity.START_ENQUIRE, q); etSearch.setText("") }
            return true
        }
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) submit() else false
        }
        etSearch.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) submit()
            else keyCode == KeyEvent.KEYCODE_ENTER   // konsumsi ACTION_UP supaya tidak diproses dua kali
        }
    }

    private fun filter(q: String): List<MenuEntry> {
        if (q.isBlank()) return menuItems
        val k = q.lowercase()
        return menuItems.filter { (it.title + " " + it.subtitle + " " + it.keywords).lowercase().contains(k) }
    }

    private class MenuRowAdapter(
        private var items: MutableList<MenuEntry>,
        private val onClick: (MenuEntry) -> Unit
    ) : RecyclerView.Adapter<MenuRowAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val chip: FrameLayout = view.findViewById(R.id.chipMenu)
            val icon: ImageView = view.findViewById(R.id.ivMenuIcon)
            val title: TextView = view.findViewById(R.id.tvMenuTitle)
            val sub: TextView = view.findViewById(R.id.tvMenuSub)
        }

        fun setItems(newItems: List<MenuEntry>) {
            items = newItems.toMutableList()
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_menu_row, parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val e = items[position]
            (holder.chip.background.mutate() as GradientDrawable).setColor(e.chipColor)
            holder.icon.setImageResource(e.iconRes)
            holder.icon.setColorFilter(e.iconColor)
            holder.title.text = e.title
            holder.sub.text = e.subtitle
            holder.itemView.setOnClickListener { onClick(e) }
        }

        override fun getItemCount() = items.size
    }
}
