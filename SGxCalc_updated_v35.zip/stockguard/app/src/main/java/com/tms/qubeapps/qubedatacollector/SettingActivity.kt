package com.tms.qubeapps.qubedatacollector

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import com.tms.qubeapps.qubedatacollector.Prefs.fileFormat
import com.tms.qubeapps.qubedatacollector.Prefs.lastKnownIp
import com.tms.qubeapps.qubedatacollector.Prefs.localFolderPath
import com.tms.qubeapps.qubedatacollector.Prefs.localUploadFolderPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbPass
import com.tms.qubeapps.qubedatacollector.Prefs.dataUpdateMode
import com.tms.qubeapps.qubedatacollector.Prefs.autoQtyType
import com.tms.qubeapps.qubedatacollector.Prefs.smbDomain
import com.tms.qubeapps.qubedatacollector.Prefs.smbPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathDataCollector
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathExpiredDiscount
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathScanProcess
import com.tms.qubeapps.qubedatacollector.Prefs.smbUser
import com.tms.qubeapps.qubedatacollector.Prefs.uploadMode

class SettingActivity : BaseActivity() {

    // FIX: (removed) nomor WA feedback dipindah ke FeedbackHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        val rgUploadMode  = findViewById<RadioGroup>(R.id.rgUploadMode)
        val rbSmb         = findViewById<RadioButton>(R.id.rbSmb)
        val rbHttp        = findViewById<RadioButton>(R.id.rbHttp)
        val rbLocal       = findViewById<RadioButton>(R.id.rbLocal)
        val layoutSmb     = findViewById<View>(R.id.layoutSmbFields)
        val layoutHttp    = findViewById<View>(R.id.layoutHttpFields)
        val layoutLocal   = findViewById<View>(R.id.layoutLocalFolder)
        val etLocalFolder = findViewById<EditText>(R.id.etLocalFolder)
        val etLocalUploadFolder = findViewById<EditText>(R.id.etLocalUploadFolder)
        val btnGrantStorage = findViewById<Button>(R.id.btnGrantStorage)
        val tvServerStatus  = findViewById<TextView>(R.id.tvServerStatus)
        val tvServerAddress = findViewById<TextView>(R.id.tvServerAddress)
        val btnToggleServer = findViewById<Button>(R.id.btnToggleServer)
        val tvIpWarning      = findViewById<TextView>(R.id.tvIpWarning)
        val btnWifiSettings  = findViewById<Button>(R.id.btnWifiSettings)

        val etPath   = findViewById<EditText>(R.id.etSmbPath)
        val etSmbUploadPath = findViewById<EditText>(R.id.etSmbUploadPath)
        val etUser   = findViewById<EditText>(R.id.etUsername)
        val etPass   = findViewById<EditText>(R.id.etPassword)
        val etDomain = findViewById<EditText>(R.id.etSmbDomain)
        val etFormat = findViewById<EditText>(R.id.etFileFormat)

        // ── Load saved values ─────────────────────────────────────────
        etPath.setText(smbPath)
        etSmbUploadPath.setText(smbUploadPath)
        // ★ FIX (baru): folder output SMB per layar — satu tempat untuk lihat/ubah ketiganya
        val etSmbOutScanProcess = findViewById<EditText>(R.id.etSmbOutScanProcess)
        val etSmbOutDataCollector = findViewById<EditText>(R.id.etSmbOutDataCollector)
        val etSmbOutExpired = findViewById<EditText>(R.id.etSmbOutExpired)
        etSmbOutScanProcess.setText(smbUploadPathScanProcess)
        etSmbOutDataCollector.setText(smbUploadPathDataCollector)
        etSmbOutExpired.setText(smbUploadPathExpiredDiscount)
        etUser.setText(smbUser)
        etPass.setText(smbPass)
        etDomain.setText(smbDomain)
        etFormat.setText(fileFormat)
        etLocalFolder.setText(localFolderPath)
        etLocalUploadFolder.setText(localUploadFolderPath)

        // ── Terapkan visibility berdasarkan mode ──────────────────────
        // ★ FIX: folder penyimpanan dipakai bersama oleh mode LOCAL & HTTP
        // (lihat OutputWriter/QubeHttpServer), jadi field-nya harus tampil
        // untuk KEDUA mode itu — sebelumnya cuma muncul untuk LOCAL saja,
        // sehingga di mode HTTP folder-nya "tersembunyi" dan seolah tidak
        // bisa di-custom padahal sebenarnya dipakai juga.
        fun applyMode(mode: String) {
            layoutSmb.visibility   = if (mode == "SMB")  View.VISIBLE else View.GONE
            layoutHttp.visibility  = if (mode == "HTTP") View.VISIBLE else View.GONE
            layoutLocal.visibility = if (mode == "LOCAL" || mode == "HTTP") View.VISIBLE else View.GONE
        }

        val saved = uploadMode
        rbSmb.isChecked   = saved == "SMB"
        rbHttp.isChecked  = saved == "HTTP"
        rbLocal.isChecked = saved == "LOCAL"
        if (!rbSmb.isChecked && !rbHttp.isChecked && !rbLocal.isChecked) rbSmb.isChecked = true
        applyMode(saved.ifBlank { "SMB" })

        rgUploadMode.setOnCheckedChangeListener { _, checkedId ->
            applyMode(when (checkedId) {
                R.id.rbHttp  -> "HTTP"
                R.id.rbLocal -> "LOCAL"
                else         -> "SMB"
            })
        }

        // ── Tombol grant storage ──────────────────────────────────────
        btnGrantStorage.setOnClickListener {
            if (StoragePermissionHelper.hasPermission()) {
                Toast.makeText(this, "Storage access already granted", Toast.LENGTH_SHORT).show()
            } else {
                StoragePermissionHelper.requestPermission(this)
            }
        }

        // ── FIX: server HTTP built-in di HP (ganti skrip Python) ─────────
        // ★ FIX: bandingkan IP sekarang dengan IP terakhir yang tercatat —
        // kalau beda, ingatkan user supaya alamat di PC juga disesuaikan,
        // dan tawarkan atur IP statis supaya tidak berubah-ubah lagi.
        fun refreshServerUi() {
            if (QubeHttpServer.isRunning()) {
                tvServerStatus.text = "Server: ON"
                tvServerStatus.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.green_button))
                val ip = QubeHttpServer.getLocalIpAddress(this)
                if (ip != null) {
                    tvServerAddress.text = "http://$ip:${QubeHttpServer.PORT}"
                    val prevIp = lastKnownIp
                    if (prevIp.isNotBlank() && prevIp != ip) {
                        tvIpWarning.text = "⚠ IP changed from $prevIp to $ip. Update the address on the PC. Set a Static IP to prevent this from changing again."
                        tvIpWarning.visibility = View.VISIBLE
                    } else {
                        tvIpWarning.visibility = View.GONE
                    }
                    lastKnownIp = ip
                } else {
                    tvServerAddress.text = "Unable to detect IP. Make sure the device is connected to the same WiFi as the PC."
                    tvIpWarning.visibility = View.GONE
                }
                btnToggleServer.text = "STOP SERVER"
            } else {
                tvServerStatus.text = "Server: OFF"
                tvServerStatus.setTextColor(android.graphics.Color.parseColor("#D32F2F"))
                tvServerAddress.text = ""
                tvIpWarning.visibility = View.GONE
                btnToggleServer.text = "START SERVER"
            }
        }
        refreshServerUi()

        // ★ FIX: shortcut ke Pengaturan WiFi HP supaya user bisa set IP Statis
        // langsung dari sini, tanpa harus cari-cari menu di HP.
        btnWifiSettings.setOnClickListener {
            try {
                startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Unable to open WiFi Settings on this device", Toast.LENGTH_SHORT).show()
            }
        }

        btnToggleServer.setOnClickListener {
            if (QubeHttpServer.isRunning()) {
                QubeHttpServer.stop()
                Toast.makeText(this, "Server stopped", Toast.LENGTH_SHORT).show()
            } else {
                val ip = QubeHttpServer.getLocalIpAddress(this)
                if (ip == null) {
                    Toast.makeText(this,
                        "Device is not connected to WiFi. Connect to the same WiFi as the PC first.",
                        Toast.LENGTH_LONG).show()
                } else {
                    try {
                        QubeHttpServer.start(this)
                        Toast.makeText(this,
                            "Server started. Open http://$ip:${QubeHttpServer.PORT} in the PC browser",
                            Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Failed to start server: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            refreshServerUi()
        }

        // ★ FIX (baru): mode update Data Master & Qty System (Manual / Auto)
        val rbUpdAuto     = findViewById<RadioButton>(R.id.rbUpdAuto)
        val rbUpdManual   = findViewById<RadioButton>(R.id.rbUpdManual)
        val layoutAutoQty = findViewById<View>(R.id.layoutAutoQty)
        val tvUpdModeInfo = findViewById<TextView>(R.id.tvUpdModeInfo)
        fun applyUpdMode(auto: Boolean) {
            layoutAutoQty.visibility = if (auto) View.VISIBLE else View.GONE
            tvUpdModeInfo.text = if (auto)
                "Auto: sekali per hari, saat aplikasi pertama dibuka, Data Master (02.txt) di-download lalu file Qty bertanggal hari ini di folder yang sama (jika ada) langsung diterapkan dalam satu proses."
            else "Manual: update lewat tombol di menu utama seperti biasa."
        }
        val autoOn = dataUpdateMode == "AUTO"
        rbUpdAuto.isChecked = autoOn; rbUpdManual.isChecked = !autoOn
        applyUpdMode(autoOn)
        findViewById<RadioGroup>(R.id.rgUpdateMode).setOnCheckedChangeListener { _, id -> applyUpdMode(id == R.id.rbUpdAuto) }
        when (autoQtyType) {
            "ADD" -> findViewById<RadioButton>(R.id.rbAutoAdd).isChecked = true
            "OFF" -> findViewById<RadioButton>(R.id.rbAutoQtyOff).isChecked = true
            else  -> findViewById<RadioButton>(R.id.rbAutoSubtract).isChecked = true
        }

        findViewById<View>(R.id.btnSetColumns).setOnClickListener {
            startActivity(Intent(this, ShelfPriceEnquireActivity::class.java).apply {
                putExtra(ShelfPriceEnquireActivity.EXTRA_MODE, ShelfPriceEnquireActivity.MODE_ENQUIRE)
                putExtra(ShelfPriceEnquireActivity.EXTRA_OPEN_COLUMNS, true)
            })
        }
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        // ── Save ──────────────────────────────────────────────────────
        findViewById<View>(R.id.btnSave).setOnClickListener {
            uploadMode = when {
                rbHttp.isChecked  -> "HTTP"
                rbLocal.isChecked -> "LOCAL"
                else              -> "SMB"
            }
            smbPath       = etPath.text.toString().trim()
            smbUploadPath = etSmbUploadPath.text.toString().trim()
            smbUploadPathScanProcess = etSmbOutScanProcess.text.toString().trim()
            smbUploadPathDataCollector = etSmbOutDataCollector.text.toString().trim()
            smbUploadPathExpiredDiscount = etSmbOutExpired.text.toString().trim()
            smbUser       = etUser.text.toString().trim()
            smbPass       = etPass.text.toString().trim()
            smbDomain     = etDomain.text.toString().trim()
            localFolderPath = etLocalFolder.text.toString().trim()
            localUploadFolderPath = etLocalUploadFolder.text.toString().trim()
            fileFormat    = etFormat.text.toString().trim().ifEmpty { "YM" }
            dataUpdateMode = if (rbUpdAuto.isChecked) "AUTO" else "MANUAL"
            autoQtyType = when (findViewById<RadioGroup>(R.id.rgAutoQty).checkedRadioButtonId) {
                R.id.rbAutoAdd -> "ADD"
                R.id.rbAutoQtyOff -> "OFF"
                else -> "SUBTRACT"
            }

            if (rbLocal.isChecked && !StoragePermissionHelper.hasPermission()) {
                Toast.makeText(this,
                    "Settings saved.\nNote: storage permission not yet granted — tap \"Allow storage access\"",
                    Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
    }

}
