package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.annotation.RequiresApi
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.spec.GCMParameterSpec

/**
 * ★ X-Ref (tahap 1) — padanan Android untuk xref.py (X-Ref by YM): data, cache, pengaturan.
 * Logika merge/cache sengaja SAMA dengan versi Python (kunci JSON sama: "Label", "Plucode", "Stock Pack", dst.)
 * sehingga file sku_cache.json dari PC bisa dipakai bersama.
 */
object XRef {
    const val LOGIN_URL = "https://iderp.mrdiy.com/Default.aspx?country=id_diy"
    val COLS = listOf("Label", "Plucode", "Desc", "Stock Pack", "Barcode", "Link Code", "PLU Link ID", "Unit Cost", "Qty")

    /** atribut data-cell di grid situs -> nama kolom */
    val FIELDS = linkedMapOf(
        "Plucode" to "Plucode", "Desc" to "Desc", "M_STOCKPACK" to "Stock Pack",
        "Barcode" to "Barcode", "M_LINKCODE" to "Link Code", "M_PLULINKID" to "PLU Link ID",
        "M_UNITCOST" to "Unit Cost", "Qty" to "Qty"
    )

    data class RefItem(val ref: String, val created: String, val remark: String, val sku: String,
                       var page: Int = 1, var cached: Boolean = false)

    fun toFloat(v: Any?): Double = v?.toString()?.replace(",", "")?.trim()?.toDoubleOrNull() ?: 0.0

    /** Label 'RefNo | remark' -> 'RefNo' */
    fun refOf(label: String): String = label.split("|")[0].trim()

    /** Tanggal di situs berformat dd-mm-yyyy. 'today' = hari ini; 01/10/2026 otomatis jadi 01-10-2026. */
    fun resolveDate(v: String): String {
        val t = v.trim()
        if (t.equals("today", true) || t.equals("hari ini", true))
            return SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
        return t.replace(Regex("^(\\d{1,2})/(\\d{1,2})/(\\d{4})$"), "\$1-\$2-\$3")
    }

    // ── cache ────────────────────────────────────────────────────────────
    private fun cacheFile(ctx: Context) = File(ctx.filesDir, "xref_sku_cache.json")
    private fun backupFile(ctx: Context) = File(ctx.filesDir, "xref_sku_cache.backup.json")

    fun loadCache(ctx: Context): MutableList<JSONObject> {
        for (f in listOf(cacheFile(ctx), backupFile(ctx))) {
            if (!f.exists()) continue
            try {
                val a = JSONArray(f.readText(Charsets.UTF_8))
                return MutableList(a.length()) { a.getJSONObject(it) }
            } catch (e: Exception) { /* rusak: coba cadangan */ }
        }
        return mutableListOf()
    }

    fun saveCache(ctx: Context, cache: List<JSONObject>) {
        val arr = JSONArray()
        cache.forEach { arr.put(it) }
        val tmp = File(ctx.filesDir, "xref_sku_cache.tmp")
        tmp.writeText(arr.toString(), Charsets.UTF_8)
        val f = cacheFile(ctx)
        if (f.exists()) f.copyTo(backupFile(ctx), overwrite = true)
        tmp.copyTo(f, overwrite = true)
        tmp.delete()
    }

    fun clearCache(ctx: Context) { cacheFile(ctx).delete(); backupFile(ctx).delete() }

    /** Ref No yang diproses ulang: data SKU lama milik Ref itu diganti data baru. Return (SKU baru disimpan, baris lama dihapus). */
    fun merge(cache: MutableList<JSONObject>, rows: List<JSONObject>): Pair<Int, Int> {
        if (rows.isEmpty()) return Pair(0, 0)           // hasil kosong: data lama jangan dihapus
        val refs = rows.map { refOf(it.optString("Label")) }.toSet()
        val keep = cache.filter { refOf(it.optString("Label")) !in refs }
        val removed = cache.size - keep.size
        val fresh = ArrayList<JSONObject>()
        val pos = HashMap<String, Int>()
        for (r in rows) {                                // satu Plucode satu baris per Ref (yang terakhir menang)
            val k = r.optString("Plucode")
            val i = pos[k]
            if (i != null) fresh[i] = r else { pos[k] = fresh.size; fresh.add(r) }
        }
        cache.clear(); cache.addAll(keep); cache.addAll(fresh)
        return Pair(fresh.size, removed)
    }

    /** CSV: kolom asli + Total Cost (Unit Cost x Qty) + Sum (total Qty untuk Plucode yang sama di semua Ref). */
    fun toCsv(cache: List<JSONObject>): String {
        val tot = HashMap<String, Double>()
        cache.forEach { tot[it.optString("Plucode").trim()] = (tot[it.optString("Plucode").trim()] ?: 0.0) + toFloat(it.opt("Qty")) }
        fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        fun n(d: Double) = if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
        val sb = StringBuilder()
        sb.append((COLS + listOf("Total Cost", "Sum")).joinToString(",") { q(it) }).append("\n")
        for (r in cache) {
            val k = r.optString("Plucode").trim()
            val cells = COLS.map { c ->
                if (c == "Unit Cost" || c == "Qty") n(toFloat(r.opt(c))) else q(r.optString(c))
            }
            val total = toFloat(r.opt("Unit Cost")) * toFloat(r.opt("Qty"))
            val sum = if (k.isNotEmpty()) tot[k] ?: 0.0 else toFloat(r.opt("Qty"))
            sb.append((cells + listOf(n(Math.round(total * 10000) / 10000.0), n(Math.round(sum * 10000) / 10000.0))).joinToString(",")).append("\n")
        }
        return sb.toString()
    }

    // ═════════════ tahap 2/3: Data SKU, Stock Enquiry ═════════════
    const val STOCK_URL = "https://iderp.mrdiy.com/Pages/StockEnquiry.aspx?country=id_diy"
    /** Pilihan dropdown bawaan (dapat diganti lewat "Muat pilihan dari web"). */
    val STATIC_OPTS: Map<String, List<String>> = mapOf(
        "report_type" to listOf("Internal Billing", "Delivery Order", "Inter-State", "Return Order", "Supplier Return",
            "Adjustment", "Transfer Out", "Transfer In", "Stock Receive", "Purchase Order"),
        "status" to listOf("H", "P", "T"),
        "transit" to listOf("T", "Without T")
    )

    val NUM_COLS = setOf("Plucode", "Stock Pack", "Barcode", "Link Code", "PLU Link ID")

    /** '123' -> 123 (angka asli). Kode berawalan 0 (00123) atau lebih dari 15 digit tetap teks agar tidak rusak. */
    fun num(v: Any?): Any? {
        if (v is Number) return v
        val s = (v?.toString() ?: "").trim().replace(",", "")
        if (Regex("-?\\d+(\\.\\d+)?").matches(s) && !Regex("-?0\\d+").matches(s) && s.count { it.isDigit() } <= 15)
            return if (s.contains(".")) s.toDouble() else s.toLong()
        return v
    }

    /** Tampilan angka di tabel: 12.50 -> "12.5", 3.0 -> "3". */
    fun fmt(v: Any?): String = when (v) {
        null -> ""
        is Double -> String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
        is Float -> String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
        else -> v.toString()
    }

    fun skuKey(r: JSONObject): String = r.optString("Plucode").trim()

    /** Plucode yang muncul di 2 Ref No berbeda atau lebih. */
    fun skuDups(cache: List<JSONObject>): Set<String> {
        val refs = HashMap<String, MutableSet<String>>()
        for (r in cache) refs.getOrPut(skuKey(r)) { HashSet() }.add(refOf(r.optString("Label")))
        return refs.filter { it.key.isNotEmpty() && it.value.size >= 2 }.keys
    }

    /** Salinan baris + kolom Sum (total Qty untuk Plucode yang sama di semua Ref) + penanda _dup. */
    fun skuRowsWithSum(cache: List<JSONObject>): List<JSONObject> {
        val tot = HashMap<String, Double>()
        for (r in cache) { val k = skuKey(r); tot[k] = (tot[k] ?: 0.0) + toFloat(r.opt("Qty")) }
        val dups = skuDups(cache)
        return cache.map { r ->
            val k = skuKey(r)
            val d = JSONObject()
            for (c in COLS) if (r.has(c)) d.put(c, r.opt(c))
            d.put("Sum", if (k.isNotEmpty()) Math.round((tot[k] ?: 0.0) * 10000) / 10000.0 else toFloat(r.opt("Qty")))
            d.put("_dup", k in dups)
            d
        }
    }

    /** Ringkasan satu kelompok baris: jumlah baris, jumlah SKU unik, total Qty baris, Σ Sum (unik per SKU), total Rp (Unit Cost × Qty). */
    data class SumGroup(val rows: Int = 0, val skus: Int = 0, val qty: Double = 0.0, val sumUnique: Double = 0.0, val rp: Double = 0.0)

    /** Hasil hitung: [bigPlus] Sum > batas, [bigMinus] Sum < -batas, [allPlus] semua Sum > 0, [allMinus] semua Sum < 0. */
    data class SumReport(val threshold: Double, val total: SumGroup, val bigPlus: SumGroup, val bigMinus: SumGroup,
                         val allPlus: SumGroup, val allMinus: SumGroup)

    /**
     * ★ Hitung data SKU (baris sudah memuat kolom "Sum" dari [skuRowsWithSum]).
     * Rp = Unit Cost × Qty tiap baris (sama dengan kolom Total Cost di Excel). Σ Sum dihitung SEKALI per SKU
     * supaya SKU yang muncul di beberapa Ref tidak terhitung dobel.
     */
    fun sumReport(rows: List<JSONObject>, threshold: Double): SumReport {
        data class Acc(var n: Int = 0, val skus: HashSet<String> = HashSet(), var qty: Double = 0.0, var sum: Double = 0.0, var rp: Double = 0.0)
        fun grp(pred: (Double) -> Boolean): SumGroup {
            val a = Acc()
            for (r in rows) {
                val sm = toFloat(r.opt("Sum"))
                if (!pred(sm)) continue
                val q = toFloat(r.opt("Qty"))
                a.n++; a.qty += q; a.rp += toFloat(r.opt("Unit Cost")) * q
                val k = skuKey(r).ifEmpty { "#" + a.n }
                if (a.skus.add(k)) a.sum += sm
            }
            return SumGroup(a.n, a.skus.size, a.qty, a.sum, a.rp)
        }
        val t = Math.abs(threshold)
        return SumReport(t, grp { true }, grp { it > t }, grp { it < -t }, grp { it > 0.0 }, grp { it < 0.0 })
    }

    /** Header + data untuk Google Sheet (angka bertipe angka, Total Cost & Sum berupa rumus). */
    fun tableValues(cache: List<JSONObject>): List<List<Any?>> {
        val rows = ArrayList<List<Any?>>()
        rows.add(COLS + listOf("Total Cost", "Sum"))
        val n = cache.size + 1
        cache.forEachIndexed { idx, r ->
            val i = idx + 2
            val vals: List<Any?> = COLS.map { c -> if (c in NUM_COLS) num(r.opt(c)) else r.opt(c) }
            rows.add(vals + listOf<Any?>("=H" + i + "*I" + i,
                "=IF(B" + i + "=\"\",I" + i + ",SUMIF(\$B\$2:\$B\$" + n + ",B" + i + ",\$I\$2:\$I\$" + n + "))"))
        }
        return rows
    }

    // ── Stock Enquiry ────────────────────────────────────────────────────
    data class StockCols(val ref: String?, val bal: String?, val tin: String?)

    private fun norm(x: String) = x.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]"), "")

    /** Cari kolom Ref, Balance, Transit In. Nama manual di Pengaturan didahulukan; kosong = deteksi otomatis. */
    fun findStockCols(cols: List<String>, st: XRefSettings?): StockCols {
        fun pick(override: String?, tests: List<(String) -> Boolean>): String? {
            val o = norm(override ?: "")
            if (o.isNotEmpty()) for (c in cols) if (norm(c) == o) return c
            for (t in tests) for (c in cols) if (t(norm(c))) return c
            return null
        }
        val refNames = setOf("refno", "ref", "reference", "referenceno", "refnumber", "refnum")
        val ref = pick(st?.stockRefCol, listOf(
            { n: String -> n in refNames },
            { n: String -> n.startsWith("ref") || n.endsWith("ref") || n.contains("refno") }))
        val bal = pick(st?.stockBalanceCol, listOf(
            { n: String -> n == "balance" }, { n: String -> n.startsWith("balance") },
            { n: String -> n.endsWith("balance") && !n.startsWith("open") }, { n: String -> n.contains("balance") }))
        val tin = pick(st?.stockTransitCol, listOf(
            { n: String -> n.contains("transitin") }, { n: String -> n.startsWith("transit") && !n.contains("out") }))
        return StockCols(ref, bal, tin)
    }

    fun stockCols(rows: List<JSONObject>): List<String> {
        val cols = mutableListOf("SKU")
        for (r in rows) for (k in r.keys()) if (k !in cols && !k.startsWith("_")) cols.add(k)
        if ("Sum" in cols) { cols.remove("Sum"); cols.add("Sum") }
        return cols
    }

    /** Sum = (Balance + Transit In) dijumlahkan per SKU di semua Ref. _dup = SKU sama muncul di 2 Ref berbeda atau lebih. */
    fun stockRowsWithSum(rows: List<JSONObject>, st: XRefSettings?): List<JSONObject> {
        val base = rows.map { r ->
            val d = JSONObject()
            for (k in r.keys()) if (k != "Sum" && !k.startsWith("_")) d.put(k, r.opt(k))
            d
        }
        val sc = findStockCols(stockCols(base), st)
        val balCol = sc.bal; val tinCol = sc.tin; val refCol = sc.ref
        if (balCol == null && tinCol == null) return base
        val tot = HashMap<String, Double>()
        val refs = HashMap<String, MutableList<String>>()
        for (r in base) {
            val k = r.optString("SKU").trim()
            tot[k] = (tot[k] ?: 0.0) + (if (balCol != null) toFloat(r.opt(balCol)) else 0.0) +
                    (if (tinCol != null) toFloat(r.opt(tinCol)) else 0.0)
            val lst = refs.getOrPut(k) { mutableListOf() }
            lst.add(if (refCol != null) r.optString(refCol).trim() else lst.size.toString())
        }
        for (r in base) {
            val k = r.optString("SKU").trim()
            r.put("Sum", Math.round((tot[k] ?: 0.0) * 10000) / 10000.0)
            r.put("_dup", (refs[k] ?: emptyList<String>()).toSet().size >= 2)
        }
        return base
    }

    /** Baris lama dengan SKU + Ref yang sama dihapus, lalu baris baru ditambahkan. Tanpa kolom Ref: semua baris lama SKU itu diganti. */
    fun mergeStock(stock: List<JSONObject>, recs: List<JSONObject>, sku: String, refCol: String?): Pair<MutableList<JSONObject>, Int> {
        val keep: List<JSONObject> = if (refCol != null) {
            val newRefs = recs.map { it.optString(refCol).trim() }.toSet()
            stock.filter { !(it.optString("SKU").trim() == sku && it.optString(refCol).trim() in newRefs) }
        } else stock.filter { it.optString("SKU").trim() != sku }
        val out = ArrayList<JSONObject>(keep); out.addAll(recs)
        return Pair(out, stock.size - keep.size)
    }

    fun stockValues(rows: List<JSONObject>): List<List<Any?>> {
        val cols = stockCols(rows)
        val out = ArrayList<List<Any?>>()
        out.add(cols)
        for (r in rows) out.add(cols.map { c -> num(r.opt(c) ?: "") })
        return out
    }

    private fun stockFile(ctx: Context) = File(ctx.filesDir, "xref_stock_cache.json")

    fun loadStock(ctx: Context): MutableList<JSONObject> {
        val f = stockFile(ctx)
        if (!f.exists()) return mutableListOf()
        return try {
            val a = JSONArray(f.readText(Charsets.UTF_8))
            MutableList(a.length()) { a.getJSONObject(it) }
        } catch (e: Exception) { mutableListOf() }
    }

    fun saveStock(ctx: Context, rows: List<JSONObject>) {
        val arr = JSONArray(); rows.forEach { arr.put(it) }
        val tmp = File(ctx.filesDir, "xref_stock_cache.tmp")
        tmp.writeText(arr.toString(), Charsets.UTF_8)
        tmp.copyTo(stockFile(ctx), overwrite = true)
        tmp.delete()
    }

    fun clearStock(ctx: Context) { stockFile(ctx).delete() }
}

/** Pengaturan X-Ref. Password disimpan terenkripsi (Android Keystore, API 23+). */
class XRefSettings(
    var storeCode: String = "", var userId: String = "", var password: String = "",
    var listUrl: String = "",
    var autoFilter: Boolean = true,
    var reportType: String = "", var startDate: String = "", var endDate: String = "",
    var status: String = "", var transit: String = "",
    var autoPick: String = "baru",        // "baru" | "semua"
    var confirmPick: Boolean = true,
    var searchText: String = "Search",
    var stockUrl: String = XRef.STOCK_URL, var stockStart: String = "today", var stockEnd: String = "today",
    var stockSkus: String = "",
    var stockRefCol: String = "", var stockBalanceCol: String = "", var stockTransitCol: String = "",
    var gsheetAuto: Boolean = false, var gsheetUrl: String = "",
    var gsheetTab: String = "Data SKU", var gsheetStockTab: String = "Stock Enquiry",
    var gsheetCred: String = "",          // isi file JSON service account (disimpan terenkripsi)
    var options: Map<String, List<String>> = emptyMap()   // pilihan dropdown hasil "Muat dari web"
) {
    /** Pilihan dropdown untuk [key]: hasil muat dari web bila ada, jika tidak daftar bawaan. */
    fun optionsFor(key: String): List<String> = options[key]?.takeIf { it.isNotEmpty() } ?: XRef.STATIC_OPTS[key] ?: emptyList()

    companion object {
        private const val SP = "xref_prefs"
        fun load(ctx: Context): XRefSettings {
            val raw = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).getString("settings", null) ?: return XRefSettings()
            return try {
                val j = JSONObject(raw)
                fun str(k: String, d: String) = j.optString(k, d).ifBlank { d }
                XRefSettings(
                    storeCode = j.optString("store_code"), userId = j.optString("user_id"),
                    password = XRefSecret.dec(j.optString("password")),
                    listUrl = j.optString("list_url"), autoFilter = j.optBoolean("auto_filter", true),
                    reportType = j.optString("report_type"), startDate = j.optString("start_date"),
                    endDate = j.optString("end_date"), status = j.optString("status"), transit = j.optString("transit"),
                    autoPick = str("auto_pick", "baru"), confirmPick = j.optBoolean("confirm_pick", true),
                    searchText = str("search_text", "Search"),
                    stockUrl = str("stock_url", XRef.STOCK_URL), stockStart = str("stock_start", "today"),
                    stockEnd = str("stock_end", "today"), stockSkus = j.optString("stock_skus"),
                    stockRefCol = j.optString("stock_ref_col"), stockBalanceCol = j.optString("stock_balance_col"),
                    stockTransitCol = j.optString("stock_transit_col"),
                    gsheetAuto = j.optBoolean("gsheet_auto", false), gsheetUrl = j.optString("gsheet_url"),
                    gsheetTab = str("gsheet_tab", "Data SKU"), gsheetStockTab = str("gsheet_stock_tab", "Stock Enquiry"),
                    gsheetCred = XRefSecret.dec(j.optString("gsheet_cred")),
                    options = j.optJSONObject("options")?.let { o ->
                        val m = LinkedHashMap<String, List<String>>()
                        for (k in o.keys()) { val a = o.optJSONArray(k) ?: continue; m[k] = List(a.length()) { i -> a.optString(i) } }
                        m
                    } ?: emptyMap()
                )
            } catch (e: Exception) { XRefSettings() }
        }
    }

    fun save(ctx: Context) {
        val j = JSONObject()
            .put("store_code", storeCode).put("user_id", userId).put("password", XRefSecret.enc(password))
            .put("list_url", listUrl).put("auto_filter", autoFilter)
            .put("report_type", reportType).put("start_date", startDate).put("end_date", endDate)
            .put("status", status).put("transit", transit)
            .put("auto_pick", autoPick).put("confirm_pick", confirmPick)
            .put("search_text", searchText)
            .put("stock_url", stockUrl).put("stock_start", stockStart).put("stock_end", stockEnd)
            .put("stock_skus", stockSkus)
            .put("stock_ref_col", stockRefCol).put("stock_balance_col", stockBalanceCol).put("stock_transit_col", stockTransitCol)
            .put("gsheet_auto", gsheetAuto).put("gsheet_url", gsheetUrl)
            .put("gsheet_tab", gsheetTab).put("gsheet_stock_tab", gsheetStockTab)
            .put("gsheet_cred", XRefSecret.enc(gsheetCred))
            .put("options", JSONObject().also { o -> options.forEach { (k, v) -> o.put(k, JSONArray().also { a -> v.forEach { x -> a.put(x) } }) } })
        ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).edit().putString("settings", j.toString()).apply()
    }
}

object XRefSecret {
    private const val ALIAS = "xref_secret_key"

    fun enc(s: String): String {
        if (s.isEmpty()) return ""
        if (Build.VERSION.SDK_INT >= 23) {
            try { return "e:" + encrypt(s) } catch (e: Exception) { /* jatuh ke teks biasa */ }
        }
        return "p:" + s
    }

    fun dec(s: String): String {
        if (s.startsWith("p:")) return s.substring(2)
        if (s.startsWith("e:") && Build.VERSION.SDK_INT >= 23) {
            try { return decrypt(s.substring(2)) } catch (e: Exception) { return "" }
        }
        return ""
    }

    @RequiresApi(23)
    private fun key(): javax.crypto.SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            kg.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build())
            kg.generateKey()
        }
        return (ks.getEntry(ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    @RequiresApi(23)
    private fun encrypt(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(s.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    }

    @RequiresApi(23)
    private fun decrypt(b64: String): String {
        val all = Base64.decode(b64, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
    }
}
