package com.tms.qubeapps.qubedatacollector

import android.content.Context

/**
 * ★ FIX (baru): pasca-kirim yang SAMA untuk Data Collector, Keep Stock & antrean:
 * update ledger anti-duplikat, tandai baris Data Collector yang sudah terupload, tulis riwayat Keep Stock,
 * dan (bila jaringan putus) simpan sisa payload ke antrean offline.
 */
object KsUploadCoordinator {

    /** Data riwayat Keep Stock (aksi ADD) — ditulis setelah kiriman benar-benar sukses, termasuk dari antrean. */
    data class Hist(val pic: String, val noCtn: String, val skus: String, val qtys: String)

    data class Summary(
        val state: UploadProgressDialog.State,
        val sentGroups: Int,
        val queuedGroups: Int,
        val failedGroups: Int,
        val failureLines: List<String>,
        val retryMessage: String?
    )

    fun complete(
        ctx: Context, db: AppDatabase, store: String, source: String,
        out: KsUploadEngine.Outcome, hist: Hist?, enqueueRetry: Boolean = true
    ): Summary {
        val sentFps = out.sent.flatMap { it.fps }
        if (sentFps.isNotEmpty()) {
            KsUploadLedger.putAll(ctx, sentFps, KsUploadLedger.SENT)
            if (source == PendingKsQueue.SRC_DC) db.markDataCollectUploadedByFingerprints("ADD_BOX", store, sentFps.toSet())
        }
        if (hist != null && out.sent.isNotEmpty() && out.retry.isEmpty() && out.failed.isEmpty()) {
            try {
                db.insertKsHistory(store, hist.pic, "ADD",
                    noCtnBefore = "", skuBefore = "", qtyBefore = "",
                    noCtnAfter = hist.noCtn, skuAfter = hist.skus, qtyAfter = hist.qtys)
            } catch (_: Exception) { /* riwayat bersifat pelengkap */ }
        }
        // gagal permanen → lepas reservasi supaya user boleh mencoba lagi
        KsUploadLedger.removeAll(ctx, out.failed.flatMap { it.first.fps })
        if (out.retry.isNotEmpty() && enqueueRetry) PendingKsQueue.enqueue(ctx, store, source, out.retry, hist)

        val state = when {
            out.failed.isNotEmpty() -> UploadProgressDialog.State.FAILED
            out.retry.isNotEmpty() -> UploadProgressDialog.State.QUEUED
            else -> UploadProgressDialog.State.SUCCESS
        }
        return Summary(state, out.sent.size, out.retry.size, out.failed.size, out.failed.map { it.second }, out.retryMessage)
    }
}
