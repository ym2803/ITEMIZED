package com.tms.qubeapps.qubedatacollector

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ★ FIX (baru): buku catatan (ledger) upload Add Box → Google Sheets, supaya data yang SAMA
 * tidak terkirim lebih dari 1x (tap ganda, upload ulang, kirim ulang dari antrean).
 * Kunci = fingerprint (lihat KsUploadLogic), nilai = STATE|waktu. Disimpan di SharedPreferences
 * sehingga tetap ada setelah aplikasi ditutup.
 *  - SENDING : sedang dikirim sekarang (dianggap basi setelah 2 menit, mis. aplikasi ditutup paksa)
 *  - QUEUED  : tersimpan di antrean offline, menunggu jaringan
 *  - SENT    : sudah berhasil terkirim
 */
object KsUploadLedger {
    const val SENDING = "SENDING"
    const val QUEUED = "QUEUED"
    const val SENT = "SENT"

    /** Add manual di Keep Stock tidak punya cap waktu scan → blokir duplikat hanya dalam jendela ini. */
    const val MANUAL_TTL_MS = 24L * 3600 * 1000

    private const val PREF = "ks_upload_ledger"
    private const val SENDING_STALE_MS = 2L * 60 * 1000
    private const val KEEP_MS = 90L * 24 * 3600 * 1000

    data class Entry(val state: String, val time: Long) {
        fun describe(): String {
            val t = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(time))
            return when (state) {
                SENT -> "sudah terupload ke Google Sheets ($t)"
                QUEUED -> "sudah ada di antrean upload, menunggu jaringan ($t)"
                else -> "sedang dalam proses upload"
            }
        }
    }

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun parse(v: String?): Entry? {
        if (v == null) return null
        val i = v.indexOf('|'); if (i < 0) return null
        return Entry(v.substring(0, i), v.substring(i + 1).toLongOrNull() ?: 0L)
    }

    /** Entri duplikat yang masih berlaku untuk [fp], atau null kalau data ini boleh dikirim. */
    @Synchronized
    fun find(ctx: Context, fp: String, ttlMs: Long = 0L): Entry? {
        val e = parse(sp(ctx).getString(fp, null)) ?: return null
        val age = System.currentTimeMillis() - e.time
        if (e.state == SENDING && age > SENDING_STALE_MS) return null
        if (e.state == SENT && ttlMs > 0 && age > ttlMs) return null
        return e
    }

    /** Atomik: kalau [fp] duplikat → kembalikan entrinya; kalau bukan → tandai SENDING dan kembalikan null. */
    @Synchronized
    fun reserve(ctx: Context, fp: String, ttlMs: Long = 0L): Entry? {
        find(ctx, fp, ttlMs)?.let { return it }
        put(ctx, fp, SENDING)
        return null
    }

    @Synchronized
    fun put(ctx: Context, fp: String, state: String) {
        sp(ctx).edit().putString(fp, "$state|${System.currentTimeMillis()}").apply()
    }

    @Synchronized
    fun putAll(ctx: Context, fps: Collection<String>, state: String) {
        if (fps.isEmpty()) return
        val ed = sp(ctx).edit(); val v = "$state|${System.currentTimeMillis()}"
        fps.forEach { ed.putString(it, v) }; ed.apply()
    }

    /** Lepas reservasi (kirim GAGAL permanen) supaya user boleh mencoba lagi. */
    @Synchronized
    fun removeAll(ctx: Context, fps: Collection<String>) {
        if (fps.isEmpty()) return
        val ed = sp(ctx).edit(); fps.forEach { ed.remove(it) }; ed.apply()
    }

    @Synchronized
    fun prune(ctx: Context) {
        val now = System.currentTimeMillis(); val ed = sp(ctx).edit()
        sp(ctx).all.forEach { (k, v) -> val e = parse(v as? String); if (e == null || now - e.time > KEEP_MS) ed.remove(k) }
        ed.apply()
    }
}
