package com.tms.qubeapps.qubedatacollector

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * ★ X-Ref (tahap 2): penulis .xlsx tanpa pustaka tambahan (XML mentah + ZIP), padanan write_excel() / write_stock_excel() di xref.py.
 * Rumus (Total Cost, Sum) ditulis bersama nilai hitungannya, jadi tampil benar juga di aplikasi viewer yang tidak menghitung ulang.
 */
object XRefXlsx {

    private class C(val v: Any?, val s: Int, val f: String? = null)

    // indeks gaya (lihat STYLES)
    private const val HEAD = 1; private const val TEXT = 2; private const val CODE = 3; private const val MONEY = 4
    private const val INT = 5; private const val T_LABEL = 6; private const val T_MONEY = 7; private const val T_INT = 8
    private const val DUP_INT = 9; private const val GEN = 10; private const val DUP_GEN = 11

    /** Data SKU: kolom A..K (9 kolom data + Total Cost + Sum) + baris TOTAL, sama dengan versi PC. */
    fun sku(cache: List<JSONObject>): ByteArray {
        val n = cache.size + 1
        val dups = XRef.skuDups(cache)
        val tot = HashMap<String, Double>()
        for (r in cache) { val k = XRef.skuKey(r); tot[k] = (tot[k] ?: 0.0) + XRef.toFloat(r.opt("Qty")) }
        val rows = ArrayList<List<C>>()
        rows.add((XRef.COLS + listOf("Total Cost", "Sum")).map { C(it, HEAD) })
        var sumQty = 0.0; var sumCost = 0.0
        cache.forEachIndexed { idx, r ->
            val i = idx + 2
            val unit = XRef.toFloat(r.opt("Unit Cost")); val qty = XRef.toFloat(r.opt("Qty"))
            val k = XRef.skuKey(r)
            val sum = if (k.isNotEmpty()) tot[k] ?: 0.0 else qty
            sumQty += qty; sumCost += unit * qty
            val cells = ArrayList<C>()
            XRef.COLS.forEachIndexed { ci, c ->
                when (c) {
                    "Unit Cost" -> cells.add(C(unit, MONEY))
                    "Qty" -> cells.add(C(qty, INT))
                    in XRef.NUM_COLS -> {
                        val v = XRef.num(r.opt(c))
                        // kolom 1,4,5,6 (Plucode, Barcode, Link Code, PLU Link ID) berformat angka utuh "0"
                        cells.add(if (v is Number) C(v, if (ci == 1 || ci == 4 || ci == 5 || ci == 6) CODE else GEN) else C(v?.toString() ?: "", TEXT))
                    }
                    else -> cells.add(C(r.optString(c), TEXT))
                }
            }
            cells.add(C(unit * qty, MONEY, "H$i*I$i"))
            cells.add(C(sum, if (k in dups) DUP_INT else INT,
                "IF(B" + i + "=\"\",I" + i + ",SUMIF(\$B\$2:\$B\$" + n + ",B" + i + ",\$I\$2:\$I\$" + n + "))"))
            rows.add(cells)
        }
        val total = ArrayList<C>()
        total.add(C("TOTAL", T_LABEL))
        repeat(7) { total.add(C("", T_LABEL)) }
        total.add(C(sumQty, T_INT, "SUM(I2:I$n)"))
        total.add(C(sumCost, T_MONEY, "SUM(J2:J$n)"))
        total.add(C("", T_LABEL))
        rows.add(total)
        return workbook("Data SKU", rows, listOf(14.0, 12.0, 46.0, 11.0, 14.0, 12.0, 12.0, 14.0, 8.0, 16.0, 10.0), "A1:K$n")
    }

    /** Stock Enquiry: kolom dinamis sesuai hasil situs, Sum di ujung, sel Sum SKU dobel diberi warna biru. */
    fun stock(rows: List<JSONObject>, st: XRefSettings?): ByteArray {
        val data = XRef.stockRowsWithSum(rows, st)
        val cols = XRef.stockCols(data)
        val out = ArrayList<List<C>>()
        out.add(cols.map { C(it, HEAD) })
        for (r in data) {
            out.add(cols.map { c ->
                val v = XRef.num(r.opt(c) ?: "")
                val dup = c == "Sum" && r.optBoolean("_dup")
                if (v is Number) C(v, if (dup) DUP_GEN else GEN) else C(v?.toString() ?: "", TEXT)
            })
        }
        val last = colName(maxOf(cols.size, 1) - 1) + maxOf(data.size + 1, 1)
        return workbook("Stock Enquiry", out, cols.map { 16.0 }, "A1:$last")
    }

    // ── penulisan XML ────────────────────────────────────────────────────
    private fun colName(i: Int): String {
        var n = i; val sb = StringBuilder()
        do { sb.insert(0, ('A' + n % 26)); n = n / 26 - 1 } while (n >= 0)
        return sb.toString()
    }

    private fun esc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) when {
            ch == '&' -> sb.append("&amp;"); ch == '<' -> sb.append("&lt;"); ch == '>' -> sb.append("&gt;")
            ch == '"' -> sb.append("&quot;")
            ch.code < 32 && ch != '\n' && ch != '\r' && ch != '\t' -> { /* karakter kontrol tidak valid di XML: dibuang */ }
            else -> sb.append(ch)
        }
        return sb.toString()
    }

    private fun num(d: Double): String = if (d.isNaN() || d.isInfinite()) "0" else
        if (d == Math.rint(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()

    private fun workbook(sheetName: String, rows: List<List<C>>, widths: List<Double>, filterRef: String): ByteArray {
        val sb = StringBuilder(64 * 1024)
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        sb.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>")
        sb.append("<cols>")
        widths.forEachIndexed { i, w -> sb.append("<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"$w\" customWidth=\"1\"/>") }
        sb.append("</cols><sheetData>")
        rows.forEachIndexed { ri, row ->
            sb.append("<row r=\"${ri + 1}\">")
            row.forEachIndexed { ci, c ->
                val ref = colName(ci) + (ri + 1)
                val v = c.v
                when {
                    c.f != null -> {
                        sb.append("<c r=\"$ref\" s=\"${c.s}\"><f>${esc(c.f)}</f><v>${num((v as? Number)?.toDouble() ?: 0.0)}</v></c>")
                    }
                    v is Number -> sb.append("<c r=\"$ref\" s=\"${c.s}\"><v>${num(v.toDouble()).let { if (v is Long || v is Int) v.toString() else it }}</v></c>")
                    else -> {
                        val t = v?.toString() ?: ""
                        if (t.isEmpty()) sb.append("<c r=\"$ref\" s=\"${c.s}\"/>")
                        else sb.append("<c r=\"$ref\" s=\"${c.s}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(t)}</t></is></c>")
                    }
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData><autoFilter ref=\"$filterRef\"/></worksheet>")

        val name = esc(sheetName.take(31))
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            put(zip, "[Content_Types].xml", CONTENT_TYPES)
            put(zip, "_rels/.rels", RELS)
            put(zip, "xl/workbook.xml", WORKBOOK.replace("@@NAME@@", name))
            put(zip, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS)
            put(zip, "xl/styles.xml", STYLES)
            put(zip, "xl/worksheets/sheet1.xml", sb.toString())
        }
        return out.toByteArray()
    }

    private fun put(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
    }

    private const val HDR = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val CONTENT_TYPES = HDR +
        "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
        "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
        "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
        "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>"
    private const val RELS = HDR +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
    private const val WORKBOOK = HDR +
        "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
        "<sheets><sheet name=\"@@NAME@@\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
    private const val WORKBOOK_RELS = HDR +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>"

    // fonts: 0 normal, 1 putih tebal (header), 2 tebal | fills: 2 biru tua (header), 3 biru muda (SKU dobel) | border 1 = garis tipis
    private const val STYLES = HDR +
        "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
        "<fonts count=\"3\"><font><sz val=\"10\"/><name val=\"Arial\"/></font>" +
        "<font><b/><sz val=\"10\"/><color rgb=\"FFFFFFFF\"/><name val=\"Arial\"/></font>" +
        "<font><b/><sz val=\"10\"/><name val=\"Arial\"/></font></fonts>" +
        "<fills count=\"4\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>" +
        "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF1F4E78\"/><bgColor indexed=\"64\"/></patternFill></fill>" +
        "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFDCEBFA\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
        "<borders count=\"2\"><border><left/><right/><top/><bottom/><diagonal/></border>" +
        "<border><left style=\"thin\"><color rgb=\"FFBFBFBF\"/></left><right style=\"thin\"><color rgb=\"FFBFBFBF\"/></right>" +
        "<top style=\"thin\"><color rgb=\"FFBFBFBF\"/></top><bottom style=\"thin\"><color rgb=\"FFBFBFBF\"/></bottom><diagonal/></border></borders>" +
        "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"12\">" +
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +                                                        // 0
        "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\" applyAlignment=\"1\"><alignment horizontal=\"center\"/></xf>" + // 1 header
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +                                       // 2 teks
        "<xf numFmtId=\"1\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\"/>" +              // 3 "0"
        "<xf numFmtId=\"4\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\"/>" +              // 4 #,##0.00
        "<xf numFmtId=\"3\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyBorder=\"1\"/>" +              // 5 #,##0
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyBorder=\"1\"/>" +                      // 6 total teks
        "<xf numFmtId=\"4\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\"/>" + // 7 total uang
        "<xf numFmtId=\"3\" fontId=\"2\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyBorder=\"1\"/>" + // 8 total int
        "<xf numFmtId=\"3\" fontId=\"2\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyNumberFormat=\"1\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"/>" + // 9 sum dobel
        "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"1\" xfId=\"0\" applyBorder=\"1\"/>" +                                       // 10 angka umum
        "<xf numFmtId=\"0\" fontId=\"2\" fillId=\"3\" borderId=\"1\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\" applyBorder=\"1\"/>" +      // 11 sum dobel umum
        "</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"
}
