package com.tms.qubeapps.qubedatacollector

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.tms.qubeapps.qubedatacollector.Prefs.smbDomain
import com.tms.qubeapps.qubedatacollector.Prefs.smbPass
import com.tms.qubeapps.qubedatacollector.Prefs.smbPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUser
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** ★ X-Ref: buka / bagikan file biner (mis. .xlsx) lewat FileProvider yang sudah ada (cache-path "."). */
object XRefShare {
    const val XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    fun file(activity: Activity, name: String, bytes: ByteArray, mime: String, open: Boolean) {
        try {
            val dir = File(activity.cacheDir, "shared_exports").apply { mkdirs() }
            val f = File(dir, name)
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", f)
            if (open) {
                val i = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                activity.startActivity(i)
            } else {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, name)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                activity.startActivity(Intent.createChooser(i, "Bagikan $name"))
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(activity, "Tidak ada aplikasi Excel di HP ini. Gunakan 'Bagikan'.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * ★ Simpan file ke penyimpanan internal HP, folder Download/XRef (mudah dicari lewat aplikasi File/Files).
     * Android 10+ lewat MediaStore (tanpa izin tambahan); Android 9 ke bawah langsung ke folder Download,
     * dan bila gagal (izin ditolak) jatuh ke folder khusus aplikasi. Return keterangan lokasi file.
     */
    fun saveToDevice(ctx: Context, name: String, bytes: ByteArray, mime: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/XRef")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file di folder Download")
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw IllegalStateException("Tidak bisa menulis file")
            } catch (e: Exception) {
                try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                throw e
            }
            return "Download/XRef/$name"
        }
        return try {
            val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "XRef")
            dir.mkdirs()
            val f = java.io.File(dir, name)
            f.writeBytes(bytes)
            f.absolutePath
        } catch (e: Exception) {
            val dir = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "XRef").apply { mkdirs() }
            val f = java.io.File(dir, name)
            f.writeBytes(bytes)
            f.absolutePath
        }
    }

    /** ★ Tujuan SMB untuk export Excel: SMB Path upload (Setting) — kalau kosong, SMB Path utama. Kosong = belum diatur. */
    fun smbTarget(ctx: Context): String = ctx.smbUploadPath.ifBlank { ctx.smbPath }

    /** ★ Kirim file ke PC lewat SMB (login bertingkat akun → Guest → Anonymous, sama seperti upload lain).
     *  BLOKIR: panggil dari Dispatchers.IO. Melempar Exception bila gagal. Return alamat tujuan. */
    fun saveToSmb(ctx: Context, name: String, bytes: ByteArray): String {
        val target = smbTarget(ctx)
        if (target.isBlank()) throw IllegalStateException("SMB Path belum diisi (menu Setting → SMB Path)")
        SmbUploader.uploadBytes(target, ctx.smbUser, ctx.smbPass, name, bytes, ctx.smbDomain)
        return target.trimEnd('/') + "/" + name
    }
}
