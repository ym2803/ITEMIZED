package com.tms.qubeapps.qubedatacollector

/**
 * ★ FIX (baru — upload Google Sheets Add Box, modul Data Collector & Keep Stock):
 * logika MURNI (tanpa Android) untuk fingerprint duplikat, klasifikasi error jaringan,
 * persentase progress, dan deteksi "sudah terapply" saat kirim ulang. Dites di KsUploadLogicTest.
 */
object KsUploadLogic {

    data class Item(val sku: String, val qty: String)

    /**
     * Satu No Ctn yang akan dikirim.
     * [fps]      fingerprint data sumber (dipakai ledger anti-duplikat & penanda baris Data Collector).
     * [attempted]+[base]: diisi bila pengiriman grup ini sempat terputus di tengah jalan (hasil tidak pasti);
     *                     base = qty SKU di sheet SEBELUM dikirim, supaya kirim ulang tidak menambah dobel.
     */
    data class Group(
        val noCtn: String,
        val items: List<Item>,
        val fps: List<String> = emptyList(),
        val attempted: Boolean = false,
        val base: Map<String, Double> = emptyMap()
    )

    private fun norm(s: String) = s.trim().uppercase()

    /** Fingerprint 1 baris scan Data Collector (waktu scan ikut → scan ulang yang sah tidak ikut terblokir). */
    fun rowFingerprint(store: String, shelf: String, code: String, qty: String, time: String): String =
        "R|${norm(store)}|${norm(shelf)}|${code.trim()}|${qty.trim()}|${time.trim()}"

    /** Fingerprint 1 batch Add manual (Keep Stock): store + No Ctn + himpunan (SKU, qty) tanpa peduli urutan. */
    fun batchFingerprint(store: String, noCtn: String, items: List<Item>): String =
        "B|${norm(store)}|${norm(noCtn)}|" +
            items.map { "${it.sku.trim()}:${it.qty.trim()}" }.sorted().joinToString(",")

    /** Gabungkan SKU yang sama dalam satu No Ctn (qty dijumlah), urutan kemunculan dijaga. */
    fun aggregate(items: List<Item>): LinkedHashMap<String, Double> {
        val out = LinkedHashMap<String, Double>()
        items.forEach { out[it.sku.trim()] = (out[it.sku.trim()] ?: 0.0) + (it.qty.trim().ifBlank { "1" }.toDoubleOrNull() ?: 0.0) }
        return out
    }

    /** Error yang bersifat jaringan / sementara → simpan di antrean & kirim ulang otomatis. */
    fun isRetryable(e: Throwable): Boolean {
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth < 6) {
            if (t is java.io.IOException) return true      // UnknownHost, Socket*, Connect, SSL, EOF, dll.
            t = t.cause; depth++
        }
        return isRetryableMessage(e.message)
    }

    /** Respons kosong dengan HTTP 408/429/5xx dari Web App (dikembalikan KeepStockGasClient sebagai ok=false). */
    fun isRetryableMessage(msg: String?): Boolean =
        msg != null && Regex("""Empty response \(HTTP (408|429|5\d\d)\)""").containsMatchIn(msg)

    fun percent(done: Int, total: Int): Int =
        if (total <= 0) 0 else (done.coerceIn(0, total) * 100 / total)

    /** Kirim ulang: kalau qty sekarang di sheet = qty awal + qty kiriman, berarti kiriman sebelumnya SUDAH masuk. */
    fun alreadyApplied(attempted: Boolean, base: Double?, add: Double, current: Double): Boolean =
        attempted && add > 0.0 && Math.abs(current - ((base ?: 0.0) + add)) < 1e-9
}
