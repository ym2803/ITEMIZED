package com.tms.qubeapps.qubedatacollector

import android.annotation.SuppressLint
import android.content.Context
import android.os.Message
import android.view.MotionEvent
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

/** WebView "hantu": ikut dirender (alpha hampir 0) tetapi tidak menangkap sentuhan. Dipakai untuk jendela popup situs. */
private class GhostWebView(ctx: Context) : WebView(ctx) {
    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean = false
}

/**
 * ★ X-Ref (tahap 1): pengganti Playwright/Chrome di xref.py dengan WebView + JavaScript.
 * Semua pencarian elemen menelusuri dokumen utama + iframe SAMA-ORIGIN. Popup (window.open / target=_blank)
 * ditampung sebagai WebView anak; "halaman terbaru dulu" seperti ctx.pages terbalik di Python.
 * Semua fungsi suspend dipanggil dari thread utama (lifecycleScope).
 */
class XRefBrowser(private val ctx: Context, private val host: FrameLayout, private val log: (String) -> Unit) {

    val main: WebView = WebView(ctx)
    private val children = ArrayList<WebView>()

    init {
        configure(main)
        install(main)
        host.addView(main, FrameLayout.LayoutParams(-1, -1))
    }

    fun views(): List<WebView> = children.asReversed() + main
    fun snapshot(): Set<WebView> = (children + main).toSet()

    // ── WebView setup ────────────────────────────────────────────────────
    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(wv: WebView) {
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        // Tampilan desktop: struktur halaman sama dengan Chrome PC yang dipakai xref.py
        s.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
    }

    private fun install(wv: WebView) {
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                if (resultMsg == null) return false
                val child = GhostWebView(ctx)
                configure(child)
                install(child)
                child.alpha = 0.01f
                host.addView(child, FrameLayout.LayoutParams(-1, -1))
                children.add(child)
                val t = resultMsg.obj as WebView.WebViewTransport
                t.webView = child
                resultMsg.sendToTarget()
                log("Situs membuka jendela baru (dibaca di latar belakang).")
                return true
            }
            override fun onCloseWindow(window: WebView?) {
                if (window != null && children.contains(window)) destroyChild(window)
            }
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                log("Pesan situs: ${message ?: ""}"); result?.confirm(); return true
            }
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                log("Konfirmasi situs (dibatalkan): ${message ?: ""}"); result?.cancel(); return true
            }
        }
    }

    private fun destroyChild(w: WebView) {
        children.remove(w)
        try { host.removeView(w); w.stopLoading(); w.destroy() } catch (e: Exception) { }
    }

    /** ★ Mulai dari awal: tutup jendela anak, kosongkan halaman; [logout] = hapus juga sesi login (cookie) situs ERP. */
    fun reset(logout: Boolean) {
        children.toList().forEach { destroyChild(it) }
        try {
            main.stopLoading()
            main.loadUrl("about:blank")
            main.clearHistory()
            if (logout) {
                main.clearCache(true)
                android.webkit.CookieManager.getInstance().removeAllCookies(null)
                android.webkit.CookieManager.getInstance().flush()
                android.webkit.WebStorage.getInstance().deleteAllData()
            }
        } catch (e: Exception) { }
    }

    fun destroy() {
        children.toList().forEach { destroyChild(it) }
        try { host.removeView(main); main.stopLoading(); main.destroy() } catch (e: Exception) { }
    }

    // ── eksekusi JavaScript ──────────────────────────────────────────────
    private suspend fun evalRaw(wv: WebView, src: String): String? = suspendCancellableCoroutine { c ->
        try {
            wv.evaluateJavascript(src) { v -> if (c.isActive) c.resume(v) }
        } catch (e: Exception) { if (c.isActive) c.resume(null) }
    }

    /** Jalankan [body] (isi fungsi JS yang me-return nilai) dan kembalikan JSONObject/JSONArray/Boolean/Number/String atau null. */
    private suspend fun js(wv: WebView, body: String): Any? {
        val src = "(function(){try{" + PRE + "return JSON.stringify((function(){" + body +
                "})());}catch(e){return JSON.stringify({__err:String(e)});}})()"
        val raw = evalRaw(wv, src) ?: return null
        if (raw == "null" || raw == "undefined") return null
        val outer = try { JSONTokener(raw).nextValue() } catch (e: Exception) { return null }
        val s = outer as? String ?: return outer
        val v = try { JSONTokener(s).nextValue() } catch (e: Exception) { s }
        if (v === JSONObject.NULL) return null
        if (v is JSONObject && v.has("__err")) { log("  (JS error: ${v.optString("__err").take(120)})"); return null }
        return v
    }

    private fun objs(a: Any?): List<JSONObject> {
        val arr = a as? JSONArray ?: return emptyList()
        return List(arr.length()) { arr.getJSONObject(it) }
    }

    // ── navigasi ─────────────────────────────────────────────────────────
    suspend fun waitLoaded(wv: WebView, timeoutMs: Int = 15000) {
        delay(600)
        var waited = 0
        while (waited < timeoutMs) {
            if (js(wv, "return document.readyState==='complete';") == true) return
            delay(400); waited += 400
        }
    }

    suspend fun open(wv: WebView, url: String) {
        wv.loadUrl(url)
        waitLoaded(wv)
    }

    // ── login ────────────────────────────────────────────────────────────
    /** true bila form login ditemukan & dikirim. */
    suspend fun login(s: XRefSettings): Boolean {
        val body = """
var ds=docs();
for(var i=0;i<ds.length;i++){var d=ds[i];
 var pws=[].slice.call(d.querySelectorAll('input[type=password]')).filter(vis);
 if(!pws.length)continue;
 var skip=['password','hidden','checkbox','submit','button','radio','image'];
 var texts=[].slice.call(d.querySelectorAll('input')).filter(function(e){var t=(e.type||'text').toLowerCase();return vis(e)&&skip.indexOf(t)<0;});
 if(texts.length>=2){setVal(texts[0],@@STORE@@);setVal(texts[1],@@USER@@);}else if(texts.length===1){setVal(texts[0],@@USER@@);}
 setVal(pws[0],@@PASS@@);
 var btn=null;
 var cands=[].slice.call(d.querySelectorAll('button[type=submit],input[type=submit],button,input[type=button],a.btn'));
 for(var j=0;j<cands.length;j++){var c=cands[j];var t=((c.textContent||'')+' '+(c.value||'')).toLowerCase();
  if((c.type==='submit'||/login|sign in|masuk/.test(t))&&vis(c)){btn=c;break;}}
 if(btn){click(btn);}else{
  var fire=function(n){pws[0].dispatchEvent(new KeyboardEvent(n,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));};
  fire('keydown');fire('keypress');fire('keyup');
  var f=pws[0].form;if(f){try{if(f.requestSubmit){f.requestSubmit();}else{f.submit();}}catch(x){}}}
 return true;}
return false;"""
            .replace("@@STORE@@", JSONObject.quote(s.storeCode))
            .replace("@@USER@@", JSONObject.quote(s.userId))
            .replace("@@PASS@@", JSONObject.quote(s.password))
        for (wv in views()) if (js(wv, body) == true) return true
        return false
    }

    suspend fun loginFormVisible(): Boolean {
        for (wv in views()) if (js(wv, "var ds=docs();for(var i=0;i<ds.length;i++){if([].slice.call(ds[i].querySelectorAll('input[type=password]')).some(vis))return true;}return false;") == true) return true
        return false
    }

    // ── isi filter & Search ──────────────────────────────────────────────
    /** @return null bila OK / tidak ada nilai; selain itu pesan masalah. */
    suspend fun fillField(elemId: String, name: String, rawValue: String, quiet: Boolean = false): String? {
        val value = XRef.resolveDate(rawValue)
        if (value.isEmpty()) return null
        val body = """
var V=@@VALUE@@;var ds=docs();
for(var i=0;i<ds.length;i++){var e=ds[i].getElementById(@@ID@@);if(!e)continue;
 if(e.tagName==='SELECT'){
  var opts=[].slice.call(e.options);var m=null;
  for(var k=0;k<opts.length;k++){if(clean(opts[k])===V.trim()){m=opts[k];break;}}
  if(!m)return {r:'noopt',opts:opts.map(function(o){return clean(o);})};
  setVal(e,m.value);return {r:'ok'};}
 setVal(e,V);
 try{e.blur();}catch(x){}
 try{e.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',keyCode:27,bubbles:true}));}catch(x){}
 return {r:'ok'};}
return {r:'nofield'};"""
            .replace("@@VALUE@@", JSONObject.quote(value)).replace("@@ID@@", JSONObject.quote(elemId))
        for (wv in views()) {
            val r = js(wv, body) as? JSONObject ?: continue
            when (r.optString("r")) {
                "ok" -> { if (!quiet) log("  $name = $value"); return null }
                "noopt" -> return "  $name: pilihan '$value' tidak ada. Pilihan yang ada: ${r.optJSONArray("opts")}"
            }
        }
        return "  (field '$name' tidak ditemukan, dilewati)"
    }

    suspend fun clickSearch(): Boolean {
        for (wv in views()) if (js(wv, "var ds=docs();for(var i=0;i<ds.length;i++){var b=ds[i].getElementById('btnAdd');if(b&&vis(b)){click(b);return true;}}return false;") == true) return true
        return false
    }

    // ── daftar Ref No ────────────────────────────────────────────────────
    private suspend fun listItems(wv: WebView): List<JSONObject> = objs(js(wv, "var r=listDoc();return r?r.l:[];"))

    suspend fun findList(waitS: Int): WebView? {
        repeat(maxOf(1, waitS * 2)) {
            for (wv in views()) if (listItems(wv).isNotEmpty()) return wv
            delay(500)
        }
        return null
    }

    private suspend fun firstRef(wv: WebView): String? = listItems(wv).firstOrNull()?.optString("ref")

    private suspend fun waitListChange(wv: WebView, before: String?, timeoutMs: Int = 4000) {
        var waited = 0
        while (waited < timeoutMs) {
            delay(300); waited += 300
            if (firstRef(wv) != before) return
        }
    }

    private suspend fun curPage(wv: WebView): Int {
        val v = js(wv, "var r=listDoc();if(!r)return 1;var c=r.d.querySelector('.e-currentitem');return c?(parseInt(c.textContent.trim(),10)||1):1;")
        return (v as? Number)?.toInt() ?: 1
    }

    private suspend fun nextState(wv: WebView, mode: String): String {
        val v = js(wv, "var M='" + mode + "';var D=(M==='grid')?gridDoc():(listDoc()||{}).d;if(!D)return ['none'];" +
                "var n=D.querySelector('.e-nextpage, .e-nextpagedisabled');if(!n)return ['none'];var c=n.className;" +
                "return [(c.indexOf('e-disable')>=0||c.indexOf('nextpagedisabled')>=0)?'disabled':'enabled'];") as? JSONArray
        return v?.optString(0) ?: "none"
    }

    private suspend fun clickPager(wv: WebView, mode: String, sel: String): Boolean =
        js(wv, "var M='" + mode + "';var D=(M==='grid')?gridDoc():(listDoc()||{}).d;if(!D)return false;" +
                "var n=D.querySelector('" + sel + "');if(!n)return false;click(n);return true;") == true

    suspend fun goPage(wv: WebView, target: Int) {
        var cur = curPage(wv)
        if (cur > target) {
            val before = firstRef(wv)
            clickPager(wv, "list", ".e-firstpage")
            waitListChange(wv, before)
            cur = curPage(wv)
        }
        while (cur < target) {
            val before = firstRef(wv)
            clickPager(wv, "list", ".e-nextpage")
            waitListChange(wv, before)
            val nw = curPage(wv)
            if (nw == cur) break
            cur = nw
        }
    }

    suspend fun scanAll(wv: WebView): List<XRef.RefItem> {
        goPage(wv, 1)
        val items = ArrayList<XRef.RefItem>()
        var pageNo = 1
        while (true) {
            for (o in listItems(wv)) items.add(XRef.RefItem(o.optString("ref"), o.optString("created"), o.optString("remark"), o.optString("sku"), pageNo))
            if (nextState(wv, "list") != "enabled") break
            val before = firstRef(wv)
            clickPager(wv, "list", ".e-nextpage")
            waitListChange(wv, before)
            pageNo++
            if (pageNo > 500) break
        }
        val seen = HashSet<String>()
        return items.filter { seen.add(it.ref) }
    }

    /** Klik tombol pada baris Ref No tertentu (membuka detail). */
    suspend fun openRef(wv: WebView, ref: String): Boolean = js(wv, """
var R=@@REF@@;var ds=docs();
for(var i=0;i<ds.length;i++){var trs=ds[i].querySelectorAll('tr');
 for(var j=0;j<trs.length;j++){var tds=trs[j].querySelectorAll('td');var hit=false;
  for(var k=0;k<tds.length;k++){if(clean(tds[k])===R){hit=true;break;}}
  if(!hit)continue;
  var el=trs[j].querySelector('a, button, input[type=button], input[type=submit], .btn, [onclick]');
  if(el){click(el);return true;}}}
return false;""".replace("@@REF@@", JSONObject.quote(ref))) == true

    // ── grid SKU (halaman detail) ────────────────────────────────────────
    private suspend fun hasGrid(wv: WebView): Boolean = js(wv, "return !!gridDoc();") == true

    suspend fun findGrid(waitS: Int): WebView? {
        repeat(maxOf(1, waitS * 2)) {
            for (wv in views()) if (hasGrid(wv)) return wv
            delay(500)
        }
        return null
    }

    private suspend fun extractRows(wv: WebView): List<JSONObject> = objs(js(wv, """
var d=gridDoc();if(!d)return [];
return [].slice.call(d.querySelectorAll('tr[data-role="row"]')).map(function(tr){
 var o={};[].slice.call(tr.querySelectorAll('td[data-cell]')).forEach(function(td){o[td.getAttribute('data-cell')]=clean(td);});
 return o;}).filter(function(o){return o.Plucode;});"""))

    /** Ambil semua baris grid SKU termasuk halaman 2, 3, dst. */
    suspend fun grabPage(label: String, waitS: Int): List<JSONObject> {
        val wv = findGrid(waitS) ?: return emptyList()
        val rows = ArrayList<JSONObject>()
        var seenFirst: String? = null
        repeat(200) {
            val raw = extractRows(wv)
            if (raw.isEmpty() || raw[0].optString("Plucode") == seenFirst) return rows
            seenFirst = raw[0].optString("Plucode")
            for (o in raw) {
                val r = JSONObject().put("Label", label)
                for ((attr, col) in XRef.FIELDS) r.put(col, o.optString(attr, ""))
                r.put("Unit Cost", XRef.toFloat(r.optString("Unit Cost")))
                r.put("Qty", XRef.toFloat(r.optString("Qty")))
                rows.add(r)
            }
            if (nextState(wv, "grid") != "enabled") return rows
            clickPager(wv, "grid", ".e-nextpage")
            delay(1200)
        }
        return rows
    }

    // ── bersih-bersih & pemulihan ────────────────────────────────────────
    suspend fun closeExtras(before: Set<WebView>, listWv: WebView) {
        for (c in children.toList()) if (c !in before) destroyChild(c)
        js(listWv, """
try{document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',keyCode:27,bubbles:true}));}catch(x){}
var sels=['.modal .close','[data-dismiss=modal]','.e-dialog .e-close','.e-dialog-close'];var ds=docs();
for(var s=0;s<sels.length;s++){for(var i=0;i<ds.length;i++){var l=ds[i].querySelector(sels[s]);if(l&&vis(l)){click(l);return true;}}}
return false;""")
    }

    suspend fun ensureList(listWv: WebView, listUrl: String): WebView? {
        findList(2)?.let { return it }
        try { if (listWv.canGoBack()) { listWv.goBack(); waitLoaded(listWv) } } catch (e: Exception) { }
        findList(8)?.let { return it }
        if (listUrl.isNotBlank()) { listWv.loadUrl(listUrl); waitLoaded(listWv) }
        return findList(15)
    }

    /** Ringkasan isi halaman untuk diagnosis bila daftar/grid tidak ditemukan. */
    suspend fun diagnose() {
        for ((i, wv) in views().withIndex()) {
            log("  [halaman ${i + 1}] ${(wv.url ?: "").take(90)}")
            val a = js(wv, "var ds=docs();return ds.map(function(d){return {u:((d.location&&d.location.href)||'').slice(0,80),th:[].slice.call(d.querySelectorAll('th')).map(clean).filter(Boolean).slice(0,12),cells:d.querySelectorAll('td[data-cell]').length,tr:d.querySelectorAll('tr').length};});")
            for (o in objs(a)) log("     frame ${o.optString("u")} | th=${o.optJSONArray("th")} | data-cell=${o.optInt("cells")} | tr=${o.optInt("tr")}")
        }
    }

    // ── Stock Enquiry: tabel hasil, tombol Search, pesan error ──────────
    /** Klik tombol Search dengan urutan percobaan sama seperti versi PC (value=teks, tombol bertuliskan teks, #btnAdd, #btnSearch, submit). */
    suspend fun clickSearchText(text: String): Boolean {
        val body = """
var T=@@T@@;var tl=T.toLowerCase();var ds=docs();
var sels=[
 function(d){return [].slice.call(d.querySelectorAll('input[value]')).filter(function(e){return e.value===T;});},
 function(d){return [].slice.call(d.querySelectorAll('button')).filter(function(e){return (e.textContent||'').toLowerCase().indexOf(tl)>=0;});},
 function(d){return [].slice.call(d.querySelectorAll('#btnAdd'));},
 function(d){return [].slice.call(d.querySelectorAll('#btnSearch'));},
 function(d){return [].slice.call(d.querySelectorAll('input[type=submit]'));}];
for(var s=0;s<sels.length;s++){for(var i=0;i<ds.length;i++){var l=sels[s](ds[i]);if(l.length&&vis(l[0])){click(l[0]);return true;}}}
return false;""".replace("@@T@@", JSONObject.quote(text))
        for (wv in views()) if (js(wv, body) == true) return true
        return false
    }

    private suspend fun docCount(wv: WebView): Int = (js(wv, "return docs().length;") as? Number)?.toInt() ?: 0

    private fun strRows(a: JSONArray?): List<List<String>> {
        if (a == null) return emptyList()
        return List(a.length()) { i -> val r = a.getJSONArray(i); List(r.length()) { j -> r.optString(j) } }
    }

    /** Tanda tangan (baris pertama) tabel yang sedang tampil, untuk mendeteksi hasil baru setelah Search. */
    suspend fun peekSig(): String? {
        for (wv in views()) {
            for (k in 0 until docCount(wv)) {
                val res = js(wv, "var D=docs()[" + k + "];if(!D)return null;var t=tableOf(D);return t&&t.rows.length?t.rows[0]:null;") as? JSONArray ?: continue
                if (res.length() > 0) return List(res.length()) { res.optString(it) }.joinToString("\u0001")
            }
        }
        return null
    }

    private suspend fun nextStateDoc(wv: WebView, k: Int): String {
        val v = js(wv, "var D=docs()[" + k + "];if(!D)return ['none'];var n=D.querySelector('.e-nextpage, .e-nextpagedisabled');if(!n)return ['none'];var c=n.className;" +
                "return [(c.indexOf('e-disable')>=0||c.indexOf('nextpagedisabled')>=0)?'disabled':'enabled'];") as? JSONArray
        return v?.optString(0) ?: "none"
    }

    /** Ambil tabel di dokumen ke-[k] termasuk halaman 2, 3, dst. (JS_TABLE + extract_all di Python). */
    private suspend fun tableAll(wv: WebView, k: Int): Pair<List<String>, List<List<String>>> {
        var heads: List<String> = emptyList()
        val out = ArrayList<List<String>>()
        var seen: String? = null
        repeat(200) {
            val res = js(wv, "var D=docs()[" + k + "];if(!D)return null;return tableOf(D);") as? JSONObject
            val rows = strRows(res?.optJSONArray("rows"))
            if (rows.isEmpty()) return Pair(heads, out)
            val first = rows[0].joinToString("\u0001")
            if (first == seen) return Pair(heads, out)
            seen = first
            val h = res?.optJSONArray("heads")
            heads = if (h == null) emptyList() else List(h.length()) { h.optString(it) }
            out.addAll(rows)
            if (nextStateDoc(wv, k) != "enabled") return Pair(heads, out)
            js(wv, "var D=docs()[" + k + "];var n=D&&D.querySelector('.e-nextpage');if(!n)return false;click(n);return true;")
            delay(1200)
        }
        return Pair(heads, out)
    }

    /** Cari tabel hasil yang baris pertamanya BERBEDA dari [prev] (hasil Search sebelumnya). null bila belum ada. */
    suspend fun findTable(prev: String?): Pair<List<String>, List<List<String>>>? {
        for (wv in views()) {
            for (k in 0 until docCount(wv)) {
                val (h, r) = try { tableAll(wv, k) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { continue }
                if (r.isNotEmpty() && r[0].joinToString("\u0001") != prev) return Pair(h, r)
            }
        }
        return null
    }

    /** Baca isi dropdown Report Type, Status, Transit dari halaman Report Enquiry (kunci: report_type, status, transit). */
    suspend fun readOptions(): Map<String, List<String>> {
        val out = LinkedHashMap<String, List<String>>()
        for ((key, id) in listOf("report_type" to "txtType", "status" to "txtStatus", "transit" to "txttransit")) {
            for (wv in views()) {
                val a = js(wv, "var ds=docs();for(var i=0;i<ds.length;i++){var e=ds[i].getElementById(@@ID@@);if(e&&e.options){return [].slice.call(e.options).map(function(o){return clean(o);});}}return null;"
                    .replace("@@ID@@", JSONObject.quote(id))) as? JSONArray ?: continue
                out[key] = List(a.length()) { a.optString(it) }
                break
            }
        }
        return out
    }

    /** Pesan galat di halaman Stock Enquiry (mis. kode produk tidak valid). */
    suspend fun readErrors(): String {
        val sb = StringBuilder()
        for (wv in views()) {
            val a = js(wv, "var ids=['ContentPlaceHolder1_productcodeErrorMsgId','ContentPlaceHolder1_GrlErrorMsgId'];var out=[];var ds=docs();" +
                    "for(var s=0;s<ids.length;s++){for(var i=0;i<ds.length;i++){var e=ds[i].getElementById(ids[s]);if(e&&e.innerText&&e.innerText.trim())out.push(e.innerText.trim());}}return out;") as? JSONArray
            if (a != null) for (i in 0 until a.length()) sb.append(a.optString(i)).append(' ')
        }
        return sb.toString().trim()
    }

    companion object {
        /** Fungsi bantu JS yang disisipkan di setiap eksekusi (tanpa tanda dolar agar aman di string Kotlin). */
        private val PRE = """
var clean=function(t){return (t.textContent||'').replace(/\s+/g,' ').trim();};
var docs=function(){var out=[document];var walk=function(d){var fs=d.querySelectorAll('iframe,frame');for(var i=0;i<fs.length;i++){try{var dd=fs[i].contentDocument;if(dd){out.push(dd);walk(dd);}}catch(e){}}};walk(document);return out;};
var vis=function(e){return !!(e&&(e.offsetWidth||e.offsetHeight||(e.getClientRects&&e.getClientRects().length)));};
var setVal=function(e,v){var w=e.ownerDocument.defaultView;var proto=e.tagName==='SELECT'?w.HTMLSelectElement.prototype:(e.tagName==='TEXTAREA'?w.HTMLTextAreaElement.prototype:w.HTMLInputElement.prototype);var d=Object.getOwnPropertyDescriptor(proto,'value');if(d&&d.set){d.set.call(e,v);}else{e.value=v;}e.dispatchEvent(new w.Event('input',{bubbles:true}));e.dispatchEvent(new w.Event('change',{bubbles:true}));};
var click=function(e){try{e.scrollIntoView({block:'center'});}catch(x){}var w=e.ownerDocument.defaultView;var ev=['pointerdown','mousedown','pointerup','mouseup'];for(var i=0;i<ev.length;i++){try{var C=ev[i].indexOf('pointer')===0?w.PointerEvent:w.MouseEvent;e.dispatchEvent(new C(ev[i],{bubbles:true,cancelable:true,view:w}));}catch(x){}}e.click();};
var gridDoc=function(){var d=docs();for(var i=0;i<d.length;i++){if(d[i].querySelector('td[data-cell="Plucode"]'))return d[i];}return null;};
var listOf=function(d){
 var heads=[].slice.call(d.querySelectorAll('th')).map(clean);
 var ix=function(n){for(var i=0;i<heads.length;i++){if(heads[i].toLowerCase()===n)return i;}return -1;};
 var iRef=ix('ref no');
 var off=function(n,def){return (iRef>=0&&ix(n)>=0)?ix(n)-iRef:def;};
 var oCr=off('created at',1),oRm=off('remark',4),oSku=off('sku count',6);
 var out=[];var trs=d.querySelectorAll('tr');
 for(var k=0;k<trs.length;k++){var tr=trs[k];var td=[].slice.call(tr.querySelectorAll('td'));if(td.length<5)continue;
  var txt=td.map(clean);var p=-1;
  if(iRef>=0&&td.length===heads.length&&/^\d+${'$'}/.test(txt[iRef]))p=iRef;
  if(p<0){for(var j=0;j<txt.length;j++){if(/^0\d{6,}${'$'}/.test(txt[j])){p=j;break;}}}
  if(p<0)continue;
  var v=tr.querySelector('a, button, input[type=button], input[type=submit], .btn, [onclick]');if(!v)continue;
  out.push({ref:txt[p],created:txt[p+oCr]||'',remark:txt[p+oRm]||'',sku:txt[p+oSku]||''});}
 return out;};
var tableOf=function(d){
 var sr=[].slice.call(d.querySelectorAll('tr[data-role="row"]'));
 if(sr.length){
  var heads=[].slice.call(sr[0].querySelectorAll('td[data-cell]')).map(function(td){return td.getAttribute('data-cell');});
  var rows=sr.map(function(tr){return [].slice.call(tr.querySelectorAll('td[data-cell]')).map(clean);});
  return {heads:heads,rows:rows};}
 var best=null;var tbs=d.querySelectorAll('table');
 for(var i=0;i<tbs.length;i++){var tb=tbs[i];
  var hs=[].slice.call(tb.querySelectorAll('th')).map(clean).filter(function(x){return x;});
  var rs=[].slice.call(tb.querySelectorAll('tr')).map(function(tr){return [].slice.call(tr.querySelectorAll('td')).map(clean);}).filter(function(r){return r.length>1&&r.some(function(x){return x;});});
  if(!hs.length||!rs.length)continue;
  if(!best||rs.length>best.rows.length)best={heads:hs.slice(0,rs[0].length),rows:rs};}
 return best;};
var listDoc=function(){var d=docs();for(var i=0;i<d.length;i++){var l=listOf(d[i]);if(l.length)return {d:d[i],l:l};}return null;};
"""
    }
}
