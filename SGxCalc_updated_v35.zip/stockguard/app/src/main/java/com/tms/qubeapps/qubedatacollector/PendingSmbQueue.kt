package com.tms.qubeapps.qubedatacollector

import android.content.Context
import com.tms.qubeapps.qubedatacollector.Prefs.smbDomain
import com.tms.qubeapps.qubedatacollector.Prefs.smbPass
import com.tms.qubeapps.qubedatacollector.Prefs.smbUser
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPath
import com.tms.qubeapps.qubedatacollector.Prefs.smbUploadPathDataCollector
import org.json.JSONObject
import java.io.File

/**
 * ★ FIX (baru): antrean upload SMB yang tahan jaringan putus.
 *
 * Untuk gangguan JARINGAN, file TXT disimpan dulu di penyimpanan internal aplikasi (folder "pending_smb"), lalu dikirim
 * otomatis begitu jaringan/server kembali terjangkau (lihat flush()). Kesalahan KONFIGURASI (user/password salah, share tidak
 * ada, path kosong) tetap langsung ditampilkan.
 *
 * ★ FIX (anti-duplikat): data yang sama tidak boleh menumpuk di antrean dan tidak boleh diantrekan lagi bila sudah ter-upload.
 * Aturan lengkap ada di [PendingDedupe]. Rapikan antrean lama otomatis saat flush().
 *
 * Satu item = <id>.txt (isi, sudah dibersihkan) + <id>.json (tujuan SMB path & nama file). Password TIDAK disimpan.
 */
object PendingSmbQueue {

    data class FlushResult(val sent: Int, val remaining: Int, val lastError: String?, val dropped: Int = 0)

    sealed class EnqueueResult {
        object Added : EnqueueResult()
        class Superseded(val removed: Int) : EnqueueResult()      // file pending lama yang isinya termuat di data baru dibuang
        object DuplicatePending : EnqueueResult()                  // data ini sudah ada di antrean
        class AlreadySent(val ts: Long) : EnqueueResult()          // data ini sama dengan upload sukses sebelumnya
    }

    private val lock = Any()
    @Volatile private var flushing = false
    private const val SP = "pending_smb_sent"

    private fun dir(ctx: Context): File = File(ctx.filesDir, "pending_smb").apply { mkdirs() }

    private fun metaFiles(ctx: Context): List<File> =
        (dir(ctx).listFiles { f -> f.name.endsWith(".json") } ?: emptyArray()).sortedBy { it.name }

    private fun txtOf(meta: File) = File(meta.parentFile, meta.name.removeSuffix(".json") + ".txt")

    fun count(ctx: Context): Int = metaFiles(ctx).size

    private fun tagFor(mode: String) = if (mode == "SHELF_RECORD") "_05_" else "_04_"

    private fun idsForMode(ctx: Context, mode: String): List<String> {
        val tag = tagFor(mode)
        return metaFiles(ctx).filter { m ->
            try { JSONObject(m.readText(Charsets.UTF_8)).optString("name").contains(tag) } catch (e: Exception) { false }
        }.map { it.name.removeSuffix(".json") }
    }

    /** ★ Jumlah file pending untuk SATU mode Data Collector, dibaca dari kode di nama file
     *  (…_05_… = Shelf Record, …_04_… = Stock Take) — supaya notice tidak muncul di menu lain. */
    fun countForMode(ctx: Context, mode: String): Int = idsForMode(ctx, mode).size

    /** ★ Hapus pending milik satu mode saja. Return jumlah yang dihapus. */
    fun clearForMode(ctx: Context, mode: String): Int = synchronized(lock) { remove(ctx, idsForMode(ctx, mode)) }

    /** ★ Batalkan/hapus SEMUA file pending (dibuang dari perangkat, tidak akan dikirim). Return jumlah yang dihapus.
     *  Tidak menunggu flush yang sedang berjalan: file yang sedang dikirim bisa saja tetap terkirim. */
    fun clearAll(ctx: Context): Int = synchronized(lock) {
        remove(ctx, metaFiles(ctx).map { it.name.removeSuffix(".json") }.toSet()).also {
            // sisa file .txt tanpa meta (rusak) ikut dibersihkan
            dir(ctx).listFiles()?.forEach { f -> f.delete() }
        }
    }

    /** Kesalahan yang berarti PENGATURAN salah (bukan jaringan) — jangan di-pending, tampilkan ke user. */
    fun isConfigError(e: Exception): Boolean {
        val m = e.message ?: return false
        return m.startsWith("Authentication failed") ||
               m.startsWith("Unable to access share") ||
               m.contains("SMB Path is not set") || m.contains("SMB Path is empty") ||
               m.contains("Invalid SMB") // salah format path
    }

    // ── catatan upload sukses terakhir per tujuan ────────────────────────
    private fun lastSent(ctx: Context, path: String): PendingDedupe.Sent? = try {
        val raw = ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).getString(path, null)
        raw?.split("|")?.let { PendingDedupe.Sent(it[0], it[1].toLong()) }
    } catch (e: Exception) { null }

    private fun items(ctx: Context): List<Pair<File, PendingDedupe.Item>> {
        val out = ArrayList<Pair<File, PendingDedupe.Item>>()
        for (meta in metaFiles(ctx)) {
            try {
                val txt = txtOf(meta)
                if (!txt.exists()) continue
                val j = JSONObject(meta.readText(Charsets.UTF_8))
                val norm = PendingDedupe.normalize(txt.readText(Charsets.UTF_8))
                out.add(Pair(meta, PendingDedupe.Item(meta.name.removeSuffix(".json"), j.getString("path"),
                    PendingDedupe.counts(norm), PendingDedupe.hash(norm))))
            } catch (e: Exception) { /* item rusak dilewati */ }
        }
        return out
    }

    private fun remove(ctx: Context, ids: Collection<String>): Int {
        var n = 0
        for (id in ids) {
            val m = File(dir(ctx), "$id.json"); val t = File(dir(ctx), "$id.txt")
            if (m.exists() || t.exists()) { m.delete(); t.delete(); n++ }
        }
        return n
    }

    /**
     * Masukkan ke antrean kecuali sudah ada / sudah ter-upload (lihat [PendingDedupe]).
     * [smbPath] = path yang disimpan (untuk path bawaan, isi path bawaan agar host diambil lagi dari Setting saat kirim ulang).
     */
    fun enqueue(ctx: Context, smbPath: String, fileName: String, content: String, fromFallback: Boolean = false): EnqueueResult {
        val norm = PendingDedupe.normalize(content)
        synchronized(lock) {
            val existing = items(ctx)
            val d = PendingDedupe.decide(smbPath, norm, existing.map { it.second }, lastSent(ctx, smbPath), System.currentTimeMillis())
            when (d.kind) {
                PendingDedupe.Kind.ALREADY_SENT -> return EnqueueResult.AlreadySent(d.sentTs)
                PendingDedupe.Kind.DUPLICATE_PENDING -> return EnqueueResult.DuplicatePending
                PendingDedupe.Kind.ADD -> {}
            }
            val removed = remove(ctx, d.removeIds)
            val id = "${System.currentTimeMillis()}_${Integer.toHexString(fileName.hashCode())}"
            File(dir(ctx), "$id.txt").writeText(content, Charsets.UTF_8)
            // meta ditulis terakhir: item baru dianggap ada hanya bila meta sudah lengkap
            File(dir(ctx), "$id.json").writeText(
                JSONObject().put("path", smbPath).put("name", fileName).put("fb", fromFallback).toString(), Charsets.UTF_8)
            return if (removed > 0) EnqueueResult.Superseded(removed) else EnqueueResult.Added
        }
    }

    /**
     * Catat bahwa [content] sudah ter-upload ke [smbPath]; file pending lama yang isinya termuat di dalamnya dibuang
     * (tidak perlu dikirim lagi). Aman dipanggil kapan saja: tidak pernah melempar error. Return jumlah file pending yang dibuang.
     */
    fun markSent(ctx: Context, smbPath: String, content: String, excludeId: String? = null): Int {
        return try {
            val norm = PendingDedupe.normalize(content)
            synchronized(lock) {
                ctx.getSharedPreferences(SP, Context.MODE_PRIVATE).edit()
                    .putString(smbPath, PendingDedupe.hash(norm) + "|" + System.currentTimeMillis()).apply()
                val c = PendingDedupe.counts(norm)
                val drop = items(ctx).filter { it.second.id != excludeId && it.second.path == smbPath && PendingDedupe.covers(c, it.second.counts) }
                remove(ctx, drop.map { it.second.id })
            }
        } catch (e: Exception) { 0 }
    }

    /**
     * Kirim semua item pending (terlama dulu). Berhenti di kegagalan pertama karena jaringan masih bermasalah.
     * Sebelum mengirim, antrean dirapikan dari data ganda. Panggil dari Dispatchers.IO. Aman dipanggil bersamaan.
     */
    fun flush(ctx: Context): FlushResult {
        if (flushing) return FlushResult(0, count(ctx), null)
        synchronized(lock) {
            if (flushing) return FlushResult(0, count(ctx), null)
            flushing = true
        }
        var sent = 0; var dropped = 0; var lastError: String? = null
        try {
            synchronized(lock) { dropped += remove(ctx, PendingDedupe.redundant(items(ctx).map { it.second })) }
            for (meta in metaFiles(ctx)) {
                val txt = txtOf(meta)
                try {
                    if (!meta.exists()) continue                          // sudah dibuang oleh aturan anti-duplikat
                    val j = JSONObject(meta.readText(Charsets.UTF_8))
                    if (!txt.exists()) { meta.delete(); continue }        // sisa rusak: buang
                    val content = txt.readText(Charsets.UTF_8)
                    var path = j.getString("path")
                    val key = path
                    val id = meta.name.removeSuffix(".json")
                    // sudah ter-upload (mis. lewat upload langsung saat jaringan sudah pulih): tidak perlu dikirim lagi
                    val ls = lastSent(ctx, key)
                    val h = PendingDedupe.hash(PendingDedupe.normalize(content))
                    if (ls != null && ls.hash == h && System.currentTimeMillis() - ls.ts in 0..PendingDedupe.SENT_WINDOW_MS) {
                        synchronized(lock) { dropped += remove(ctx, listOf(id)) }
                        continue
                    }
                    // ★ FIX: path tersimpan di antrean bisa USANG (mis. salah ketik IP saat antre). Urutan coba:
                    //   1. SMB Path TERBARU dari Setting (Data Collector → Setting global); bila keduanya kosong,
                    //      path bawaan dengan host dari Setting
                    //   2. path yang tersimpan di antrean (host BACKEND diganti host dari Setting)
                    // Error yang ditampilkan = error percobaan pertama (setingan terbaru), bukan path lama.
                    val name = j.getString("name")
                    val fb = j.optBoolean("fb", false) || SmbUploader.hostOf(path).equals("BACKEND", ignoreCase = true)
                    val stored = if (fb) OutputWriter.withSettingsHost(ctx, path) else path
                    val current = ctx.smbUploadPathDataCollector.ifBlank { ctx.smbUploadPath }.ifBlank { stored }
                    var firstErr: Exception? = null
                    var done = false
                    for (cand in listOf(current, stored).distinct()) {
                        try {
                            SmbUploader.upload(cand, ctx.smbUser, ctx.smbPass, name, content, ctx.smbDomain)
                            done = true; break
                        } catch (e1: Exception) {
                            if (firstErr == null) firstErr = e1
                            if (isConfigError(e1)) break
                        }
                    }
                    if (!done) throw firstErr ?: Exception("Upload failed")
                    sent++
                    dropped += markSent(ctx, key, content, excludeId = id)   // buang pending lain yang termuat di data ini
                    synchronized(lock) { txt.delete(); meta.delete() }
                } catch (e: Exception) {
                    lastError = e.message ?: e.javaClass.simpleName
                    break                                                     // jaringan masih bermasalah: coba lagi nanti
                }
            }
        } finally { flushing = false }
        return FlushResult(sent, count(ctx), lastError, dropped)
    }
}
