package com.tms.qubeapps.qubedatacollector

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ★ X-Ref (tahap 2/3): tab "Data SKU" dan "Data Stock Enquiry" — padanan DataGrid di xref.py.
 * Cari, urutkan, ketuk baris untuk edit, tahan untuk memilih lalu hapus, tambah baris, simpan, Excel, Google Sheet,
 * dan (khusus Stock) Hapus SKU dobel. Baris SKU dobel di Ref berbeda diberi warna biru.
 */
class XRefGridActivity : BaseActivity() {

    companion object {
        const val EXTRA_KIND = "kind"
        const val SKU = "sku"
        const val STOCK = "stock"
    }

    private lateinit var kind: String
    private lateinit var st: XRefSettings
    private var cols: List<String> = emptyList()
    private var rows = mutableListOf<JSONObject>()
    private var shown: List<Int> = emptyList()
    private val selected = HashSet<Int>()
    private var dirty = false
    private val sortRev = HashMap<String, Boolean>()

    private lateinit var etSearch: EditText
    private lateinit var tvInfo: TextView
    private lateinit var spSort: Spinner
    private lateinit var btnDelete: Button
    private lateinit var list: RecyclerView
    private lateinit var adapter: RowAdapter

    private val numCols: Set<String> get() = if (kind == SKU) setOf("Unit Cost", "Qty", "Sum") else emptySet()
    private val derived = setOf("Sum")
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        kind = intent.getStringExtra(EXTRA_KIND) ?: SKU
        st = XRefSettings.load(this)
        buildUi()
        load()
    }

    // ── UI (dibuat lewat kode agar tidak perlu layout XML) ───────────────
    private fun btn(text: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(this, null, 0, if (primary) R.style.Widget_Sg_Button_Primary else R.style.Widget_Sg_Button_Soft)
        b.text = text; b.textSize = 12f
        b.layoutParams = LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        b.minWidth = 0; b.minimumWidth = 0; b.setPadding(dp(4), 0, dp(4), 0)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(10), dp(8), dp(10), dp(4)); gravity = android.view.Gravity.CENTER_VERTICAL }
        head.addView(btn("←") { finish() })
        head.addView(TextView(this).apply {
            text = if (kind == SKU) "Data SKU" else "Data Stock Enquiry"; textSize = 17f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#1F2933")); setPadding(dp(8), 0, 0, 0)
        })
        root.addView(head)

        etSearch = EditText(this).apply {
            hint = "Cari…"; setSingleLine(true); textSize = 14f
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(10), 0, dp(10), 0) }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { refresh() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        root.addView(etSearch)

        // Baris 1: Tambah | Hapus | Simpan | Lainnya ▾   (semua selalu terlihat, tanpa geser)
        val bar1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), 0, dp(6), 0) }
        bar1.addView(btn("Tambah") { addRow() })
        btnDelete = btn("Hapus") { deleteSelected() }
        bar1.addView(btnDelete)
        bar1.addView(btn("Simpan", primary = true) { save() })
        val btnMore = btn("Lainnya ▾") { }
        btnMore.setOnClickListener { v ->
            val items = ArrayList<Pair<String, () -> Unit>>()
            items.add("Muat ulang" to { reload() })
            if (kind == SKU) items.add("Hitung Sum plus / minus" to { showSumReport() })
            if (kind == STOCK) items.add("Hapus dobel" to { dedupeDialog() })
            items.add("Export Excel" to { exportExcel() })
            items.add("Kirim ke Google Sheet" to { sendGSheet() })
            items.add("Hapus semua" to { deleteAll() })
            val pm = android.widget.PopupMenu(this, v)
            items.forEachIndexed { i, e -> pm.menu.add(0, i, i, e.first) }
            pm.setOnMenuItemClickListener { it2 -> items.getOrNull(it2.itemId)?.second?.invoke(); true }
            pm.show()
        }
        bar1.addView(btnMore)
        root.addView(bar1)

        // Baris 2: pilihan kolom urut + Urut (+ Hitung untuk Data SKU)
        val bar2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0) }
        spSort = Spinner(this)
        bar2.addView(spSort, LinearLayout.LayoutParams(0, dp(40), 1.6f).apply { setMargins(dp(2), 0, dp(2), 0) })
        bar2.addView(btn("Urut ⇅") { sortBySelected() })
        if (kind == SKU) bar2.addView(btn("Hitung") { showSumReport() })
        root.addView(bar2)

        tvInfo = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#6B7280")); setPadding(dp(12), dp(4), dp(12), dp(4)) }
        root.addView(tvInfo)

        list = RecyclerView(this).apply { layoutManager = LinearLayoutManager(this@XRefGridActivity) }
        adapter = RowAdapter()
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    // ── data ─────────────────────────────────────────────────────────────
    private fun load() {
        if (kind == SKU) {
            rows = XRef.skuRowsWithSum(XRef.loadCache(this)).toMutableList()
            cols = XRef.COLS + "Sum"
        } else {
            val r = XRef.stockRowsWithSum(XRef.loadStock(this), st)
            rows = r.toMutableList(); cols = XRef.stockCols(r)
        }
        dirty = false; selected.clear()
        spSort.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cols)
        refresh()
    }

    private fun recalc() {
        rows = (if (kind == SKU) XRef.skuRowsWithSum(rows) else XRef.stockRowsWithSum(rows, st)).toMutableList()
        if (kind == STOCK) cols = XRef.stockCols(rows)
    }

    private fun reload() {
        if (dirty) {
            AlertDialog.Builder(this).setTitle("Muat ulang").setMessage("Perubahan yang belum disimpan akan hilang. Lanjut?")
                .setPositiveButton("Lanjut") { _, _ -> load() }.setNegativeButton("Batal", null).show()
        } else load()
    }

    private fun refresh() {
        val q = etSearch.text.toString().trim().lowercase(Locale.ROOT)
        val idx = ArrayList<Int>()
        var dups = 0
        rows.forEachIndexed { i, r ->
            if (q.isNotEmpty() && cols.none { XRef.fmt(r.opt(it)).lowercase(Locale.ROOT).contains(q) }) return@forEachIndexed
            idx.add(i)
            if (r.optBoolean("_dup")) dups++
        }
        shown = idx
        tvInfo.text = "${idx.size} / ${rows.size} baris" + (if (dups > 0) "  •  $dups baris SKU dobel (biru)" else "") +
                (if (dirty) "  •  Belum disimpan" else "") + "  •  ketuk = edit, tahan = pilih"
        btnDelete.text = if (selected.isEmpty()) "Hapus" else "Hapus (${selected.size})"
        adapter.notifyDataSetChanged()
    }

    private fun cmp(a: Any?, b: Any?): Int {
        val an = a is Number; val bn = b is Number
        if (an && bn) return (a as Number).toDouble().compareTo((b as Number).toDouble())
        if (an) return -1
        if (bn) return 1
        return (a?.toString() ?: "").lowercase(Locale.ROOT).compareTo((b?.toString() ?: "").lowercase(Locale.ROOT))
    }

    private fun sortBySelected() {
        val c = spSort.selectedItem as? String ?: return
        val rev = sortRev[c] ?: false
        sortRev[c] = !rev
        val base = Comparator<JSONObject> { x, y -> cmp(x.opt(c), y.opt(c)) }
        rows.sortWith(if (rev) base.reversed() else base)
        selected.clear()
        refresh()
        list.scrollToPosition(0)
    }

    // ── edit / tambah / hapus / simpan ───────────────────────────────────
    private fun editRow(i: Int) {
        val r = rows[i]
        val pad = dp(16)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val fields = LinkedHashMap<String, EditText>()
        for (c in cols) {
            if (c in derived || c.startsWith("_")) continue
            box.addView(TextView(this).apply { text = c; textSize = 12f; setPadding(0, dp(8), 0, 0) })
            val e = EditText(this).apply {
                setText(XRef.fmt(r.opt(c))); setSingleLine(true)
                if (c in numCols) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            }
            box.addView(e); fields[c] = e
        }
        AlertDialog.Builder(this).setTitle("Edit baris").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("OK") { _, _ ->
                for ((c, e) in fields) {
                    val t = e.text.toString().trim()
                    val v: Any? = when {
                        c in numCols -> XRef.toFloat(t)
                        kind == STOCK || c in XRef.NUM_COLS -> XRef.num(t)
                        else -> t
                    }
                    r.put(c, v ?: "")
                }
                dirty = true; recalc(); refresh()
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun addRow() {
        val r = JSONObject()
        for (c in cols) if (c !in derived && !c.startsWith("_")) r.put(c, if (c in numCols) 0 else "")
        rows.add(r); dirty = true
        recalc(); refresh()
        val pos = rows.size - 1
        list.scrollToPosition(shown.size - 1)
        editRow(pos)
    }

    private fun deleteSelected() {
        if (selected.isEmpty()) { Toast.makeText(this, "Tahan sebuah baris untuk memilih, lalu tekan Hapus", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Hapus").setMessage("Hapus ${selected.size} baris terpilih?")
            .setPositiveButton("Hapus") { _, _ ->
                for (i in selected.sortedDescending()) rows.removeAt(i)
                selected.clear(); dirty = true; recalc(); refresh()
            }.setNegativeButton("Batal", null).show()
    }

    /** ★ Hapus SEMUA data (tidak terpengaruh filter cari) dan langsung disimpan — data di situs ERP tidak terpengaruh. */
    private fun deleteAll() {
        if (rows.isEmpty()) { Toast.makeText(this, "Data sudah kosong", Toast.LENGTH_SHORT).show(); return }
        val what = if (kind == SKU) "Data SKU" else "Data Stock Enquiry"
        AlertDialog.Builder(this).setTitle("Hapus semua $what?")
            .setMessage("${rows.size} baris akan dihapus PERMANEN dari HP ini dan langsung tersimpan (tidak bisa dibatalkan). " +
                "Data di situs ERP tidak terpengaruh.\n\nTips: Export Excel dulu bila datanya masih dibutuhkan.")
            .setPositiveButton("Hapus semua") { _, _ ->
                val n = rows.size
                rows.clear(); selected.clear()
                if (kind == SKU) XRef.clearCache(this) else XRef.clearStock(this)
                dirty = false
                recalc(); refresh()
                Toast.makeText(this, "$n baris dihapus", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Batal", null).show()
    }

    /** Baris tanpa kolom hitungan (Sum, _dup) — bentuk yang disimpan ke cache. */
    private fun cleanRows(): List<JSONObject> = rows.map { r ->
        val d = JSONObject()
        if (kind == SKU) { for (c in XRef.COLS) d.put(c, r.opt(c) ?: "") }
        else for (k in r.keys()) if (k != "Sum" && !k.startsWith("_")) d.put(k, r.opt(k))
        d
    }

    private fun save() {
        val clean = cleanRows()
        if (kind == SKU) XRef.saveCache(this, clean) else XRef.saveStock(this, clean)
        dirty = false; refresh()
        Toast.makeText(this, "Tersimpan: ${clean.size} baris", Toast.LENGTH_SHORT).show()
        if (st.gsheetAuto && st.gsheetUrl.isNotBlank() && st.gsheetCred.isNotBlank()) sendGSheet()
    }

    // ── Excel & Google Sheet ─────────────────────────────────────────────
    private fun exportExcel() {
        if (rows.isEmpty()) { Toast.makeText(this, "Data masih kosong", Toast.LENGTH_SHORT).show(); return }
        val clean = cleanRows()
        val bytes = try { if (kind == SKU) XRefXlsx.sku(clean) else XRefXlsx.stock(clean, st) }
        catch (e: Exception) { Toast.makeText(this, "Gagal membuat Excel: ${e.message}", Toast.LENGTH_LONG).show(); return }
        val name = (if (kind == SKU) "data_sku_" else "stock_enquiry_") + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".xlsx"
        AlertDialog.Builder(this).setTitle("Excel (${clean.size} baris)")
            .setItems(arrayOf("Buka di aplikasi Excel", "Bagikan / simpan ke…", "Simpan ke penyimpanan HP (Download/XRef)", "Kirim ke PC lewat SMB")) { _, w ->
                if (w == 3) {
                    Toast.makeText(this, "Mengirim ke PC (SMB)…", Toast.LENGTH_SHORT).show()
                    lifecycleScope.launch(Safe.handler) {
                        val msg = try { "Terkirim ke PC:\n" + withContext(Dispatchers.IO) { XRefShare.saveToSmb(this@XRefGridActivity, name, bytes) } }
                        catch (e: Exception) { "Gagal kirim ke PC:\n${e.message}" }
                        AlertDialog.Builder(this@XRefGridActivity).setTitle("Export SMB").setMessage(msg).setPositiveButton("OK", null).show()
                    }
                } else if (w == 2) {
                    try {
                        val where = XRefShare.saveToDevice(this, name, bytes, XRefShare.XLSX)
                        AlertDialog.Builder(this).setTitle("Excel tersimpan").setMessage("Tersimpan di penyimpanan HP:\n$where")
                            .setPositiveButton("OK", null).show()
                    } catch (e: Exception) { Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show() }
                } else XRefShare.file(this, name, bytes, XRefShare.XLSX, open = (w == 0))
            }.show()
    }

    private fun sendGSheet() {
        if (st.gsheetUrl.isBlank() || st.gsheetCred.isBlank()) {
            Toast.makeText(this, "Isi Link Sheet dan file kredensial di Pengaturan X-Ref", Toast.LENGTH_LONG).show(); return
        }
        val clean = cleanRows()
        val values = if (kind == SKU) XRef.tableValues(clean) else XRef.stockValues(XRef.stockRowsWithSum(clean, st))
        val tab = if (kind == SKU) st.gsheetTab else st.gsheetStockTab
        Toast.makeText(this, "Mengirim ke Google Sheet…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(Safe.handler) {
            val msg = withContext(Dispatchers.IO) { XRefGSheet.send(st, tab, values) }
            AlertDialog.Builder(this@XRefGridActivity).setTitle("Google Sheet").setMessage(msg).setPositiveButton("OK", null).show()
        }
    }

    // ── ★ Hitung Sum plus / minus (Data SKU) ─────────────────────────────
    /** Dihitung dari baris yang DIPILIH (tahan = pilih); kalau tidak ada yang dipilih, dari baris yang sedang tampil (hasil cari/filter Ref). */
    private fun showSumReport() {
        val scopeRows: List<JSONObject>; val scopeName: String
        if (selected.isNotEmpty()) { scopeRows = selected.sorted().mapNotNull { rows.getOrNull(it) }; scopeName = "${scopeRows.size} baris dipilih" }
        else { scopeRows = shown.mapNotNull { rows.getOrNull(it) }; scopeName = "${scopeRows.size} baris tampil" + (if (etSearch.text.isNotBlank()) " (filter: \"${etSearch.text}\")" else "") }
        if (scopeRows.isEmpty()) { Toast.makeText(this, "Tidak ada data untuk dihitung", Toast.LENGTH_SHORT).show(); return }

        val money = java.text.DecimalFormat("#,##0.##", java.text.DecimalFormatSymbols(Locale("in", "ID")))
        fun g(x: XRef.SumGroup) = "${x.rows} baris · ${x.skus} SKU\n   Qty ${money.format(x.qty)}  (Σ Sum unik ${money.format(x.sumUnique)})\n   Rp ${money.format(x.rp)}"
        val pad = dp(16)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        box.addView(TextView(this).apply { text = "Cakupan: $scopeName"; textSize = 12f; setTextColor(Color.parseColor("#6B7280")) })
        box.addView(TextView(this).apply { text = "Batas Sum (lebih dari / kurang dari -batas):"; textSize = 13f; setPadding(0, dp(8), 0, 0) })
        val etLim = EditText(this).apply { setText("2"); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setSingleLine(true) }
        box.addView(etLim)
        val tv = TextView(this).apply { textSize = 13f; setPadding(0, dp(8), 0, dp(8)); setTextIsSelectable(true) }
        box.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(330)))
        fun render() {
            val lim = etLim.text.toString().replace(",", ".").toDoubleOrNull() ?: 2.0
            val r = XRef.sumReport(scopeRows, lim)
            val l = money.format(r.threshold)
            tv.text = "① Sum LEBIH dari $l (plus)\n   ${g(r.bigPlus)}\n\n" +
                "   Sum KURANG dari -$l (minus)\n   ${g(r.bigMinus)}\n\n" +
                "② SEMUA Sum plus (> 0)\n   ${g(r.allPlus)}\n\n" +
                "   SEMUA Sum minus (< 0)\n   ${g(r.allMinus)}\n\n" +
                "Total cakupan: ${g(r.total)}"
        }
        etLim.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { render() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        render()
        AlertDialog.Builder(this).setTitle("Hitung Sum plus / minus").setView(box)
            .setPositiveButton("Tutup", null)
            .setNeutralButton("Salin") { _, _ ->
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Hitung Sum", "Cakupan: $scopeName\n\n" + tv.text))
                Toast.makeText(this, "Hasil disalin", Toast.LENGTH_SHORT).show()
            }.show()
    }

    // ── hapus SKU dobel (Stock Enquiry) ──────────────────────────────────
    /** mode "persis": SKU + Ref sama; mode "sku": SKU sama walau Ref beda. Baris pertama selalu dipertahankan. */
    private fun dupIndexes(mode: String): List<Int> {
        val refCol = XRef.findStockCols(XRef.stockCols(rows), st).ref
        val seen = HashSet<String>(); val drop = ArrayList<Int>()
        rows.forEachIndexed { i, r ->
            val sku = r.optString("SKU").trim()
            if (mode == "sku" && sku.isEmpty()) return@forEachIndexed
            val key = when {
                mode == "sku" -> sku
                refCol != null -> sku + "\u0001" + r.optString(refCol).trim()
                else -> r.keys().asSequence().filter { it != "Sum" && !it.startsWith("_") }.joinToString("\u0001") { r.optString(it) }
            }
            if (!seen.add(key)) drop.add(i)
        }
        return drop
    }

    private fun dedupeDialog() {
        if (rows.isEmpty()) { Toast.makeText(this, "Data Stock Enquiry masih kosong", Toast.LENGTH_SHORT).show(); return }
        val nPersis = dupIndexes("persis").size; val nSku = dupIndexes("sku").size
        val pad = dp(16)
        val rg = RadioGroup(this).apply { setPadding(pad, pad / 2, pad, 0) }
        val r1 = RadioButton(this).apply { id = View.generateViewId(); text = "Baris persis sama (SKU + Ref sama) — $nPersis baris dobel"; isChecked = true }
        val r2 = RadioButton(this).apply { id = View.generateViewId(); text = "SKU sama walau Ref beda, sisakan 1 baris per SKU — $nSku baris dobel" }
        rg.addView(r1); rg.addView(r2)
        AlertDialog.Builder(this).setTitle("Hapus SKU dobel").setView(rg)
            .setPositiveButton("Hapus dobel") { _, _ ->
                val drop = dupIndexes(if (r2.isChecked) "sku" else "persis")
                if (drop.isEmpty()) { Toast.makeText(this, "Tidak ada data dobel", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                for (i in drop.sortedDescending()) rows.removeAt(i)
                selected.clear(); dirty = true; recalc(); refresh()
                Toast.makeText(this, "${drop.size} baris dihapus. Tekan Simpan untuk menyimpan.", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Batal", null).show()
    }

    // ── daftar ───────────────────────────────────────────────────────────
    private inner class RowAdapter : RecyclerView.Adapter<RowAdapter.VH>() {
        inner class VH(val box: LinearLayout, val t1: TextView, val t2: TextView) : RecyclerView.ViewHolder(box)

        override fun getItemCount() = shown.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val box = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            val t1 = TextView(parent.context).apply { textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.parseColor("#1F2933")) }
            val t2 = TextView(parent.context).apply { textSize = 12f; setTextColor(Color.parseColor("#4B5563")) }
            box.addView(t1); box.addView(t2)
            return VH(box, t1, t2)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val i = shown[pos]
            val r = rows[i]
            if (kind == SKU) {
                h.t1.text = XRef.fmt(r.opt("Plucode")) + "   " + r.optString("Desc")
                h.t2.text = r.optString("Label") + "\n" +
                        "Stock Pack ${XRef.fmt(r.opt("Stock Pack"))}  ·  Barcode ${XRef.fmt(r.opt("Barcode"))}  ·  Link ${XRef.fmt(r.opt("Link Code"))}  ·  PLU Link ${XRef.fmt(r.opt("PLU Link ID"))}\n" +
                        "Unit Cost ${XRef.fmt(r.opt("Unit Cost"))}  ×  Qty ${XRef.fmt(r.opt("Qty"))}   |   Sum ${XRef.fmt(r.opt("Sum"))}"
            } else {
                h.t1.text = r.optString("SKU") + (if (r.has("Sum")) "      Sum ${XRef.fmt(r.opt("Sum"))}" else "")
                h.t2.text = cols.filter { it != "SKU" && it != "Sum" }.joinToString("  ·  ") { "$it: ${XRef.fmt(r.opt(it))}" }
            }
            h.box.setBackgroundColor(when {
                i in selected -> Color.parseColor("#FFE082")
                r.optBoolean("_dup") -> Color.parseColor("#DCEBFA")
                pos % 2 == 1 -> Color.parseColor("#FAFBFC")
                else -> Color.WHITE
            })
            h.box.setOnClickListener {
                if (selected.isNotEmpty()) toggle(i) else editRow(i)
            }
            h.box.setOnLongClickListener { toggle(i); true }
        }

        private fun toggle(i: Int) {
            if (!selected.add(i)) selected.remove(i)
            refresh()
        }
    }
}
