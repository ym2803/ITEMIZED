package com.tms.qubeapps.qubedatacollector

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec

/**
 * ★ X-Ref (tahap 3): kirim data ke Google Sheet langsung dari HP — padanan gspread.service_account di xref.py.
 * Memakai file kredensial service account (.json) YANG SAMA dengan versi PC: JWT RS256 -> access token -> Sheets API v4.
 * Sheet harus dibagikan ke email service account sebagai Editor. Semua fungsi memblokir: panggil dari Dispatchers.IO.
 */
object XRefGSheet {

    private class Cred(val email: String, val key: PrivateKey, val tokenUri: String)
    private class Err(msg: String) : Exception(msg)

    private var tokenCache: Triple<String, String, Long>? = null   // email, token, kedaluwarsa (ms)

    fun emailOf(json: String): String = try { JSONObject(json).optString("client_email") } catch (e: Exception) { "" }

    private fun parse(json: String): Cred {
        val j = JSONObject(json)
        val pem = j.getString("private_key")
        val body = pem.replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "").replace(Regex("\\s"), "")
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(Base64.decode(body, Base64.DEFAULT)))
        return Cred(j.getString("client_email"), key, j.optString("token_uri").ifBlank { "https://oauth2.googleapis.com/token" })
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    private fun http(method: String, url: String, token: String?, body: String?, ctype: String = "application/json"): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20000; c.readTimeout = 90000
            if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", ctype)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally { c.disconnect() }
    }

    private fun apiMessage(code: Int, text: String): String {
        val m = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
        return "HTTP $code" + if (!m.isNullOrBlank()) ": $m" else ""
    }

    private fun accessToken(c: Cred): String {
        tokenCache?.let { if (it.first == c.email && System.currentTimeMillis() < it.third - 60_000) return it.second }
        val now = System.currentTimeMillis() / 1000
        val header = b64("{\"alg\":\"RS256\",\"typ\":\"JWT\"}".toByteArray())
        val claims = b64(JSONObject().put("iss", c.email).put("scope", "https://www.googleapis.com/auth/spreadsheets")
            .put("aud", c.tokenUri).put("iat", now).put("exp", now + 3600).toString().toByteArray())
        val sig = Signature.getInstance("SHA256withRSA").apply { initSign(c.key); update("$header.$claims".toByteArray()) }.sign()
        val jwt = "$header.$claims.${b64(sig)}"
        val form = "grant_type=" + URLEncoder.encode("urn:ietf:params:oauth:grant-type:jwt-bearer", "UTF-8") + "&assertion=" + jwt
        val (code, text) = http("POST", c.tokenUri, null, form, "application/x-www-form-urlencoded")
        if (code !in 200..299) throw Err("Gagal login service account (" + apiMessage(code, text) + ")" +
                if (text.contains("invalid_grant")) ". Cek jam/tanggal HP dan file kredensial." else "")
        val j = JSONObject(text)
        val tok = j.getString("access_token")
        tokenCache = Triple(c.email, tok, System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000)
        return tok
    }

    private fun sheetId(url: String): String {
        val m = Regex("/spreadsheets/d/([a-zA-Z0-9-_]+)").find(url)
        if (m != null) return m.groupValues[1]
        if (Regex("^[a-zA-Z0-9-_]{20,}$").matches(url.trim())) return url.trim()
        throw Err("Link Google Sheet tidak valid (harus berisi /spreadsheets/d/...)")
    }

    private fun q(tab: String) = "'" + tab.replace("'", "''") + "'"
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
    /** Dapat diganti hanya untuk pengujian (server tiruan). */
    @Volatile internal var BASE = "https://sheets.googleapis.com/v4/spreadsheets/"

    private fun friendly(e: Exception, email: String): String {
        val tail = if (email.isNotBlank()) "\n  Pastikan Sheet dibagikan ke $email sebagai Editor, dan Google Sheets API sudah ENABLE." else ""
        return (if (e is Err) e.message else e.javaClass.simpleName + ": " + (e.message ?: "").take(200)) + tail
    }

    /** Tes koneksi: nama spreadsheet + daftar tab. */
    fun test(s: XRefSettings): String {
        if (s.gsheetUrl.isBlank() || s.gsheetCred.isBlank()) return "Google Sheet: isi Link Sheet dan file kredensial di Pengaturan."
        val email = emailOf(s.gsheetCred)
        return try {
            val c = parse(s.gsheetCred); val tok = accessToken(c)
            val (code, text) = http("GET", BASE + sheetId(s.gsheetUrl) + "?fields=properties.title,sheets.properties.title", tok, null)
            if (code !in 200..299) throw Err(apiMessage(code, text))
            val j = JSONObject(text)
            val tabs = j.optJSONArray("sheets") ?: JSONArray()
            val names = (0 until tabs.length()).map { tabs.getJSONObject(it).getJSONObject("properties").optString("title") }
            "Koneksi Google Sheet OK: '${j.getJSONObject("properties").optString("title")}', tab: $names"
        } catch (e: Exception) { "Koneksi Google Sheet GAGAL: " + friendly(e, email) }
    }

    /** Kirim [values] (baris pertama = header) ke tab [tab]; isi tab lama ditimpa. Return pesan hasil. */
    fun send(s: XRefSettings, tab: String, values: List<List<Any?>>): String {
        if (s.gsheetUrl.isBlank() || s.gsheetCred.isBlank()) return "Google Sheet: isi Link Sheet dan file kredensial di Pengaturan."
        if (values.isEmpty()) return "Google Sheet: tidak ada data untuk dikirim."
        val email = emailOf(s.gsheetCred)
        return try {
            val c = parse(s.gsheetCred); val tok = accessToken(c); val id = sheetId(s.gsheetUrl)
            val rowsNeeded = maxOf(values.size + 20, 100); val colsNeeded = maxOf(values.maxOf { it.size }, 10)

            var (code, text) = http("GET", BASE + id + "?fields=sheets.properties", tok, null)
            if (code !in 200..299) throw Err(apiMessage(code, text))
            val sheets = JSONObject(text).optJSONArray("sheets") ?: JSONArray()
            var sid: Int? = null
            for (i in 0 until sheets.length()) {
                val p = sheets.getJSONObject(i).getJSONObject("properties")
                if (p.optString("title") == tab) sid = p.getInt("sheetId")
            }
            if (sid == null) {
                val add = JSONObject().put("requests", JSONArray().put(JSONObject().put("addSheet", JSONObject().put("properties",
                    JSONObject().put("title", tab).put("gridProperties", JSONObject().put("rowCount", rowsNeeded).put("columnCount", colsNeeded))))))
                val r = http("POST", BASE + id + ":batchUpdate", tok, add.toString())
                if (r.first !in 200..299) throw Err(apiMessage(r.first, r.second))
                sid = JSONObject(r.second).getJSONArray("replies").getJSONObject(0).getJSONObject("addSheet").getJSONObject("properties").getInt("sheetId")
            }
            // kosongkan isi lama
            var r = http("POST", BASE + id + "/values/" + enc(q(tab)) + ":clear", tok, "{}")
            if (r.first !in 200..299) throw Err(apiMessage(r.first, r.second))
            // ukuran grid + bekukan baris judul
            val props = JSONObject().put("requests", JSONArray().put(JSONObject().put("updateSheetProperties", JSONObject()
                .put("properties", JSONObject().put("sheetId", sid).put("gridProperties",
                    JSONObject().put("rowCount", rowsNeeded).put("columnCount", colsNeeded).put("frozenRowCount", 1)))
                .put("fields", "gridProperties(rowCount,columnCount,frozenRowCount)"))))
            r = http("POST", BASE + id + ":batchUpdate", tok, props.toString())
            if (r.first !in 200..299) throw Err(apiMessage(r.first, r.second))
            // tulis data per 2000 baris
            var start = 0
            while (start < values.size) {
                val chunk = values.subList(start, minOf(start + 2000, values.size))
                val arr = JSONArray()
                for (row in chunk) { val ra = JSONArray(); for (v in row) ra.put(cell(v)); arr.put(ra) }
                val body = JSONObject().put("majorDimension", "ROWS").put("values", arr)
                val range = q(tab) + "!A" + (start + 1)
                r = http("PUT", BASE + id + "/values/" + enc(range) + "?valueInputOption=USER_ENTERED", tok, body.toString())
                if (r.first !in 200..299) throw Err(apiMessage(r.first, r.second))
                start += chunk.size
            }
            "Google Sheet: ${values.size - 1} baris dikirim ke tab '$tab'."
        } catch (e: Exception) { "Google Sheet GAGAL: " + friendly(e, email) }
    }

    /** Angka dikirim sebagai angka; teks berupa angka berawalan 0 diberi awalan ' agar nol di depan tidak hilang. */
    private fun cell(v: Any?): Any = when (v) {
        null -> ""
        is Number, is Boolean -> v
        else -> { val t = v.toString(); if (Regex("^0\\d+$").matches(t)) "'" + t else t }
    }
}
