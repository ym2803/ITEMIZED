package com.tms.qubeapps.qubedatacollector

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.CoroutineExceptionHandler

/**
 * Pengaman terpusat untuk coroutine. Dipasang di lifecycleScope.launch(Safe.handler) { ... }:
 * error yang tidak tertangani (mis. SQLiteException, OutOfMemoryError, JSONException) tidak lagi
 * menutup aplikasi, cukup dicatat di log dan ditampilkan sebagai pesan singkat.
 * Dengan begitu tidak perlu try/catch di setiap pemanggilan database di tiap menu.
 */
object Safe {
    @Volatile private var app: Context? = null

    fun init(c: Context) { app = c.applicationContext }

    val handler = CoroutineExceptionHandler { _, e ->
        Log.e("Safe", "Unhandled coroutine error", e)
        val c = app
        if (c != null) Handler(Looper.getMainLooper()).post {
            Toast.makeText(c, "Terjadi kesalahan: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
        }
    }
}
