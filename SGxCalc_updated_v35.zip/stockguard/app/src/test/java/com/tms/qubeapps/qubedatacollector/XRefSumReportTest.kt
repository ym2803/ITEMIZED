package com.tms.qubeapps.qubedatacollector

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test

class XRefSumReportTest {
    private fun row(plu: String, unit: Double, qty: Double, sum: Double) =
        JSONObject().put("Plucode", plu).put("Unit Cost", unit).put("Qty", qty).put("Sum", sum)

    @Test fun splitsPlusAndMinus() {
        val rows = listOf(
            row("A", 10.0, 5.0, 5.0),    // plus > 2
            row("B", 20.0, 1.0, 1.0),    // plus kecil
            row("C", 100.0, -4.0, -4.0), // minus < -2
            row("D", 5.0, -1.0, -1.0)    // minus kecil
        )
        val r = XRef.sumReport(rows, 2.0)
        assertEquals(1, r.bigPlus.rows); assertEquals(5.0, r.bigPlus.qty, 1e-9); assertEquals(50.0, r.bigPlus.rp, 1e-9)
        assertEquals(1, r.bigMinus.rows); assertEquals(-4.0, r.bigMinus.qty, 1e-9); assertEquals(-400.0, r.bigMinus.rp, 1e-9)
        assertEquals(2, r.allPlus.rows); assertEquals(70.0, r.allPlus.rp, 1e-9)
        assertEquals(2, r.allMinus.rows); assertEquals(-405.0, r.allMinus.rp, 1e-9)
    }

    @Test fun sumCountedOncePerSku() {
        val rows = listOf(row("A", 10.0, 3.0, 5.0), row("A", 10.0, 2.0, 5.0))
        val r = XRef.sumReport(rows, 2.0)
        assertEquals(2, r.bigPlus.rows); assertEquals(1, r.bigPlus.skus)
        assertEquals(5.0, r.bigPlus.sumUnique, 1e-9); assertEquals(5.0, r.bigPlus.qty, 1e-9)
    }
}
